#针对舰船、基地相关库表改动的记录说明
一、基地
    1.原基地信息表为：object_base
    2.现基地详情信息表为：object_base_basic_info
    3.上述两表通过object_base_basic_info中bridgeID关联，即此字段为object_base的id。
    4.基地驻军联队详情表为object_troops
    5.基地驻军联队与基地关联关系表为：relation_troops_base，表中troops_id为联队id，base_id为object_base中id

    **针对此次改动，相关接口说明如下：
        查询基地基础信息接口返回id为object_base中id。
        根据基地ID查询基地详情接口：参数为object_base中id，此ID为object_base_basic_info中bridgeID，遂可查到
    基地详细信息，同时可通过此ID查询relation_troops_base获知object_troops的ID，随之查询基地联队信息。

二、舰船
    1.原舰船基础信息表为：object_ship
    2.现舰船信息表为：object_ship_basic_info
    3.上述两表通过object_ship_basic_info中bridgeID关联，即此字段为object_ship的id。

    **针对此次改动，相关接口说明如下：
            查询舰船基础信息接口返回id为object_ship中id。
            根据舰船ID查询舰船详情接口：参数为object_ship中id，此ID为object_ship_basic_info中bridgeID，遂可查到
        舰船详细信息