package com.cetc54.zkb.ky.controller.output.event;

import java.io.Serializable;
import java.util.List;

public class ObjectEventOutputByPage implements Serializable {
    private int totalPage;
    private int currentPage;
    private int totalData;
    private List<ObjectEventOutput> data;

    public int getTotalData() {
        return totalData;
    }

    public void setTotalData(int totalData) {
        this.totalData = totalData;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public List<ObjectEventOutput> getData() {
        return data;
    }

    public void setData(List<ObjectEventOutput> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ObjectEventOutputByPage{" +
                "totalPage=" + totalPage +
                ", currentPage=" + currentPage +
                ", totalData=" + totalData +
                ", data=" + data +
                '}';
    }
}
