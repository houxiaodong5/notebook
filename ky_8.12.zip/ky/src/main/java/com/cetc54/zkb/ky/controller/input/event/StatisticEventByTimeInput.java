package com.cetc54.zkb.ky.controller.input.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("通过时间类型统计事件输入类")
public class StatisticEventByTimeInput {
    @ApiModelProperty("时间类型")
    private String timeType;
    @ApiModelProperty("事件类型")
    private String eventType;

    public String getTimeType() {
        return this.timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public String getEventType() {
        return this.eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
}