package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.EventQueryByIDAndTime;
import com.cetc54.zkb.ky.controller.input.event.ExtraMessageQueryInput;
import com.cetc54.zkb.ky.controller.input.ship.QueryShipAndEventsParam;
import com.cetc54.zkb.ky.controller.output.event.EventAllMsgs;
import com.cetc54.zkb.ky.controller.output.event.HotWord;
import com.cetc54.zkb.ky.controller.output.ship.StatisticsOfShipState;
import com.cetc54.zkb.ky.controller.output.statistics.*;
import com.cetc54.zkb.ky.service.StatisticsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;

@Api("统计相关controller")
@RestController
public class StatisticsController extends BaseController {

    private List<StatisticsOfBaseEventByType> list;
    private List<StatisticsManoeuvreOutput> manoeuvre_by_time;//按时间统计演习事件结果
    private List<StatisticsEventOutput> ship_event_by_time;//按时间统计舰船事件结果
    private List<StatisticsEventOutput> person_event_by_time;//按人物统计事件结果
    private List<StatisticsOfShipState> ship_state_result;//舰船进出港统计结果
    private List<StatisticsManoeuvreOutput> event_type_by_time;//根据类型统计莫某段时间内事件结果
    @Resource
    private StatisticsService statisticsService;

    @ApiOperation("人员查询统计")
    //@ApiImplicitParam(name = "time", value = "时间，格式为yyyy-MM-dd,查询某天传某天时间，当日传当日时间")
    @GetMapping({"/query/hottestPerson"})

    public DataResponse<List<OutputOfStatistics>> queryHottestPerson(){
        return this.success(statisticsService.queryHottestPerson());
    }

    @ApiOperation("舰船查询统计")
    //@ApiImplicitParam(name = "time", value = "时间，格式为yyyy-MM-dd,查询某天传某天时间，当日传当日时间")
    @GetMapping({"/query/hottestShip"})

    public DataResponse<List<OutputOfStatistics>> queryHottestShip(){
        return this.success(statisticsService.queryHottestShip());
    }

    @ApiOperation("基地查询统计")
    //@ApiImplicitParam(name = "time", value = "时间，格式为yyyy-MM-dd,查询某天传某天时间，当日传当日时间")
    @GetMapping({"/query/hottestBase"})

    public DataResponse<List<OutputOfStatistics>> queryHottestBase(){
        return this.success(statisticsService.queryHottestBase());
    }

    @ApiOperation("热词统计")
    //@ApiImplicitParam(name = "time", value = "时间，格式为yyyy-MM-dd,查询某天传某天时间，当日传当日时间")
    @GetMapping({"/query/hottestWords"})

    public DataResponse<List<HotWord>> queryHottestWords(){
        return this.success(statisticsService.queryHottestWords());
    }

    @ApiOperation("昨日接入事件统计")
    @GetMapping({"/statistics/yesterdayEvent"})

    public DataResponse<Integer> statisticsYesterdayEvent(){
        return this.success(statisticsService.statisticsYesterdayEvent());
    }

    @ApiOperation("西太地区：所有基地事件类型统计")
    @GetMapping({"/statistics/event/of/base/by/type"})
    public DataResponse<List<StatisticsOfBaseEventByType>> statisticsEventOfBaseByType(){
        if(list==null){
            return this.success(statisticsService.statisticsEventOfBaseByType());
        }else {
            return this.success(list);
        }
        //return this.success(statisticsService.statisticsEventOfBaseByType());
    }

    @ApiOperation("西太地区：不同基地按时间统计演习事件")
    @GetMapping({"/statistics/manoeuvre/of/base/by/time"})
    public DataResponse<List<StatisticsManoeuvreOutput>> statisticsManoeuvreOfBaseByTime(){
        //return this.success(statisticsService.statisticsManoeuvreOfBaseByTime());
        if(manoeuvre_by_time==null){
            return this.success(statisticsService.statisticsManoeuvreOfBaseByTime());
        }else {
            return this.success(manoeuvre_by_time);
        }
    }

    @ApiOperation("西太地区：演习事件的地点事件统计")
    @GetMapping({"/statistics/location/of/manoeuvre"})
    public DataResponse<StatisticsLocationOfManoeuvreOutput> statisticsLocationOfManoeuvre(){
        return this.success(statisticsService.statisticsLocationOfManoeuvre());
    }

    @ApiOperation("西太地区：按时间统计舰船事件")
    @GetMapping({"/statistics/event/of/ship/by/time"})
    public DataResponse<List<StatisticsEventOutput>> statisticsEventOfShipByTime(){
        if(ship_event_by_time==null){
            return this.success(statisticsService.statisticsEventOfShipByTime());
        }else return  this.success(ship_event_by_time);
    }

    @ApiOperation("西太地区：按时间统计人物事件")
    @GetMapping({"/statistics/event/of/person/by/time"})
    public DataResponse<List<StatisticsEventOutput>> statisticsEventOfPersonByTime(){
        if(person_event_by_time==null){
            statisticsEventOfBaseByTypeTimely();
            return this.success(person_event_by_time);
        }else{
            return this.success(person_event_by_time);
        }

    }

    @ApiOperation("西太地区：按时间统计基地事件：1,3,7天,1月")
    @GetMapping({"/statistics/event/of/base/by/time"})
    public DataResponse<List<StatisticsEventOutput>> statisticsEventOfBaseByTime(){
        return this.success(statisticsService.statisticsEventOfBaseByTime());

    }

    @ApiOperation("西太地区：按时间及基地id查询基地事件详情：1,3,7天,1月")
    @PostMapping("/query/events/by/time/and/baseID")
    public DataResponse<List<EventAllMsgs>> queryEventsByTimeAndBaseID(@RequestBody EventQueryByIDAndTime input){
        List<EventAllMsgs> list=statisticsService.queryEventsByTimeAndBaseID(input);
        return this.success(list==null?"参数有误":(list.size()==0?"暂无数据":list));
    }


    @ApiOperation("西太地区：按事件类型统计一定时间内的事件:1,3月,1年")
    @GetMapping({"/statistics/event/group/by/type/by/time"})
    public DataResponse<List<StatisticsManoeuvreOutput>> statisticsEventGroupByTypeByTime(){
        if(event_type_by_time==null){
            updateShipState();
        }
        return this.success(event_type_by_time);
    }

    @ApiOperation("西太地区：根据事件类型及时间查询对应事件<1,3月,1年>,携带相关人物、舰船、基地")
    @PostMapping("/query/events/by/type/and/time")
    public DataResponse<List<EventAllMsgs>> queryEventsByTypeAndTime(@RequestBody EventQueryByIDAndTime input){
        List<EventAllMsgs> list=statisticsService.queryEventsByTypeAndTime(input);
        return this.success(list==null?"参数有误":(list.size()==0?"暂无数据":list));
    }

    @ApiOperation("西太地区：根据事件类型及基地id查询相关事件")
    @PostMapping("/query/events/by/type/and/baseID")
    public DataResponse<List<EventAllMsgs>> queryEventsByTypeAndBaseID(@RequestBody EventQueryByIDAndTime input){
        try {
            List<EventAllMsgs> list=statisticsService.queryEventsByTypeAndBaseID(input);
            return this.success(list==null?"参数有误":list);
        } catch (Exception e) {
            return this.success("操作失败");
        }

    }









    @ApiOperation("统计西太地区：舰船进出港数量")
    @GetMapping("/statistics/quantity/of/ship/by/state")
    public DataResponse<List<StatisticsOfShipState>> statisticsQuantityOfShipByState(){
        if(ship_state_result==null){
            List<StatisticsOfShipState> stateList=statisticsService.statisticsQuantityOfShipByState();
            if(stateList.size()>0){
                ship_state_result=stateList;
            }
        }
        return this.success(ship_state_result);
    }

    @ApiOperation("西太地区：按时间统计舰船在或不在西太地区情况")
    @GetMapping("/statistics/state/of/ship/by/time")
    public DataResponse<List<StatisticsStateOfShip>> statisticsStateOfShipByTime(){
        return this.success(statisticsService.statisticsStateOfShipByTime());
    }

    @ApiOperation("西太地区：按时间查询舰船在港及不在港情况")
    @PostMapping("/query/ship/and/events/by/time")
    public DataResponse<List<ShipAndEvents>> queryShipAndeventsByTime(@RequestBody QueryShipAndEventsParam param){
        List<ShipAndEvents> list = statisticsService.queryShipAndeventsByTime(param);
        return this.success(list==null?"参数有误":list);
    }

    @ApiOperation("根据事件uuid查询事件对应人物、舰船、基地简要信息")
    @PostMapping("/query/extra/message/briefly/by/uuid")
    public DataResponse<EventAllMsgs> queryExtraMessageBrieflyByUUID(@RequestBody ExtraMessageQueryInput input){
        try {
            EventAllMsgs eventAllMsgs=statisticsService.queryExtraMessageBrieflyByUUID(input);
            return this.success(eventAllMsgs==null?"参数有误":eventAllMsgs);
        } catch (Exception e) {
            return this.success("操作失败");
        }
    }

    @ApiOperation("统计用户查看最多的新闻")
    @GetMapping("/statistics/most/events/of/viewed")
    public DataResponse<List<EventAllMsgs>> statisticsMostEventsOfViewed(){
        return this.success(statisticsService.statisticsMostEventsOfViewed());
    }








        //newsService queryAllSource
    @ApiOperation("数据源来源数据统计")
    @GetMapping({"/statistics/event/by/datasource"})
    public DataResponse<List<StatisticsOfOutputSource>> statisticsEventByDatasource(){
        return this.success(statisticsService.statisticsEventByDatasource());
    }










    //定时查询数据库(30分钟)   事件更新较慢，30分钟更新一次
    @Scheduled(fixedRate = 60 * 1000 * 30)
    public void statisticsEventOfBaseByTypeTimely() {
        list=statisticsService.statisticsEventOfBaseByType();//西太地区基地:按照事件类型统计
        manoeuvre_by_time=statisticsService.statisticsManoeuvreOfBaseByTime();//按时间统计演习事件
        ship_event_by_time=statisticsService.statisticsEventOfShipByTime();//按时间统计舰船事件
        person_event_by_time=statisticsService.statisticsEventOfPersonByTime();//按时间统计人物事件
        List<StatisticsEventOutput> output_1Day=new ArrayList<>();
        List<StatisticsEventOutput> output_3Day=new ArrayList<>();
        List<StatisticsEventOutput> output_7Day=new ArrayList<>();
        List<StatisticsEventOutput> output_1Month=new ArrayList<>();
        for(StatisticsEventOutput output:person_event_by_time){
            if(output.getTimeType().equals("Today")){
                output_1Day.add(output);
                continue;
            }

            if(output.getTimeType().equals("3Day")){
                output_3Day.add(output);
                continue;
            }

            if(output.getTimeType().equals("7Day")){
                output_7Day.add(output);
                continue;
            }

            if(output.getTimeType().equals("1Month")){
                output_1Month.add(output);
                continue;
            }
        }

        Collections.sort(output_1Day);
        Collections.sort(output_3Day);
        Collections.sort(output_7Day);
        Collections.sort(output_1Month);
        person_event_by_time.clear();
        output_1Day=output_1Day.size()>=10?output_1Day.subList(0,10):output_1Day;
        output_3Day=output_3Day.size()>=10?output_3Day.subList(0,10):output_3Day;
        output_7Day=output_7Day.size()>=10?output_7Day.subList(0,10):output_7Day;
        output_1Month=output_1Month.size()>=10?output_1Month.subList(0,10):output_1Month;

        person_event_by_time.addAll(output_1Day);
        person_event_by_time.addAll(output_3Day);
        person_event_by_time.addAll(output_7Day);
        person_event_by_time.addAll(output_1Month);

    }



    @Scheduled(fixedRate = 60 * 1000 * 10)
    public void updateShipState(){
        List<StatisticsOfShipState> stateList=statisticsService.statisticsQuantityOfShipByState();
        List<StatisticsManoeuvreOutput> data_list=statisticsService.statisticsEventGroupByTypeByTime();
        if(stateList.size()>0){
            ship_state_result=stateList;
        }

        if(data_list.size()>0){
            event_type_by_time=data_list;
        }
    }


}
