package com.cetc54.zkb.ky.controller.output.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("事件时间统计输出类")
public class EventTimeStatisticOutput {
    @ApiModelProperty("时间")
    private String time;
    @ApiModelProperty("数量")
    private Integer number;

    public EventTimeStatisticOutput() {
    }

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getNumber() {
        return this.number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}
