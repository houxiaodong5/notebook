package com.cetc54.zkb.ky.service.model;

public class ShipAndEventID {
    private int shipID;
    private String eventID;

    public int getShipID() {
        return shipID;
    }

    public void setShipID(int shipID) {
        this.shipID = shipID;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    @Override
    public String toString() {
        return "ShipAndEventID{" +
                "shipID=" + shipID +
                ", eventID='" + eventID + '\'' +
                '}';
    }
}
