package com.cetc54.zkb.ky.service.model;

public class ShipTrajectoryModel {
    private String time;
    private Integer jcid;

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getJcid() {
        return this.jcid;
    }

    public void setJcid(Integer jcid) {
        this.jcid = jcid;
    }
}
