package com.cetc54.zkb.ky.dao.sql;

import com.cetc54.zkb.ky.controller.input.event.EventQueryByPage;
import com.cetc54.zkb.ky.controller.input.event.EventQueryInput;
import com.cetc54.zkb.ky.controller.input.event.EventTagInput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectEventEntity;
import com.cetc54.zkb.ky.service.model.EventQueryModel;
import com.cetc54.zkb.ky.service.model.SliceOfTime;
import com.cetc54.zkb.ky.service.model.StatisticEventModel;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EventSql {

    /**
     * 查询所有事件
     */
    public String queryAllEvent() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj,t2.person_name personName ,t2.person_id personID,t3.ship_id shipID ,t3.ship_name shipName ,t4.base_id baseID ,t4.base_name  baseName FROM `object_event` t1 ");
        buffer.append("left join  `relation_person_event` t2 on t1. uuid=t2.`event_id`  ");
        buffer.append("LEFT JOIN `relation_ship_event` t3 on t1.`uuid` =t3.`event_id` ");
        buffer.append("LEFT JOIN `relation_base_event` t4 on t1.`uuid` =t4.`event_id`");
        buffer.append("where t1.`uuid` in (  select uuid from ");
        buffer.append("( SELECT  uuid FROM object_event where zbjd is not null and `zbjd` !='' order by fssj desc  limit 1000 ) a)");
        buffer.append("and t1.zbjd is not null and t1.`zbjd` !='' order by t1.fssj desc  limit 1000 ");
        return buffer.toString();
    }

    /**
     * 查询所有事件——分页
     */
    public String queryAllEventByPage() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj  ");
        buffer.append("FROM `object_event` t1   order by t1.fssj desc  ");
        return buffer.toString();
    }

    /**
     * 查询所有事件等级
     */
    public String queryAllEventGrade() {
        return "SELECT DISTINCT(wxdj) FROM object_event  order by wxdj";
    }

    /**
     * 查询所有事件类型
     */
    public String queryAllEventType() {
        return "SELECT distinct tag1 FROM object_event";
    }

    /**
     * queryAllEvent
     * 根据事件类型时间统计
     */
    public String statisticEventByTimeAndWxdjAndTag(StatisticEventModel model) {
        StringBuffer sql = new StringBuffer();
        sql.append("select count(*) FROM object_event where 1=1 ");
        if (StringUtils.isNotBlank(model.getTime())) {
            sql.append("and DATE_FORMAT(fssj, '" + model.getFormat() + "') = #{time} ");
        }

        if (StringUtils.isNotBlank(model.getWxdj())) {
            sql.append("and wxdj = #{wxdj} ");
        }

        if (StringUtils.isNotBlank(model.getTag())) {
            sql.append("and tag1 = #{tag} or tag2 = #{tag} or tag3 = #{tag}");
        }

        return sql.toString();
    }

    /**
     * 查询当天事件
     */
    public String queryEventToday() {
        return "SELECT * FROM object_event WHERE DATE_FORMAT(fssj,'%Y-%m-%d')=DATE_FORMAT(CURDATE(),'%Y-%m-%d')";
    }

    /**
     * 根据不同条件统计事件总数、实时推送、当天事件
     */
    public String statisticEvent() {
        return "SELECT (SELECT count(*)  FROM object_event) eventSum,(SELECT count(*)  FROM object_event WHERE DATE_FORMAT(fssj,'%Y%m%d')=DATE_FORMAT(CURDATE(),'%Y%m%d')) eventSumToday,(SELECT count(*)   FROM object_event WHERE id > (SELECT max(event_start_id) FROM odps_log ORDER BY event_start_id)) eventRealTime";
    }

    /**
     * 通过事件ID查询事件
     */
    public String queryEventById(String eventId) {
        return "select * from object_event where id = #{eventId}";
    }

    /**
     * 查询威胁等级
     */
    public String queryEventWxdj() {
        return "SELECT wxdj FROM object_event GROUP BY wxdj";
    }

    /**
     * 查询当前数据库中所有事件年份
     */
    public String queryEventYear() {
        return "SELECT DATE_FORMAT(fssj,'%Y') as eventYear FROM object_event GROUP BY DATE_FORMAT(fssj,'%Y') \n";
    }

    /**
     * 通过条件查询事件
     */
    public String queryEvent(EventQueryInput input) {
        StringBuffer sql = new StringBuffer();
        //sql.append("SELECT oe.* FROM object_event oe LEFT JOIN object_country oc on oe.gjid = oc.id WHERE 1=1 ");
        sql.append("SELECT oe.id id,oe.uuid uuid,oe.bt label,oe.zbwd zbwd,oe.zbjd zbjd  FROM object_event oe LEFT JOIN object_country oc on oe.gjid = oc.id WHERE 1=1 ");
        if (StringUtils.isNotBlank(input.getCountry())) {
            sql.append("and oc.gj_cn = #{country} ");
        }

        if (StringUtils.isNotBlank(input.getEventDj())) {
            sql.append("and oe.wxdj = #{eventDj} ");
        }

        if (StringUtils.isNotBlank(input.getEventTag())) {
            sql.append("and (oe.tag1 = #{eventTag} or oe.tag2 = #{eventTag} or oe.tag3 = #{eventTag} )");
        }

        if (StringUtils.isNotBlank(input.getStartTime())) {
            sql.append("and oc.gj_cn >= #{startTime} ");
        }

        if (StringUtils.isNotBlank(input.getEndTime())) {
            sql.append("and oc.gj_cn <= #{endTime} ");
        }

        sql.append("ORDER BY fssj DESC");
        return sql.toString();
    }

    /**
     * 通过国家查询所有威胁等级
     */
    public String queryWxdjByCountry(String country) {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT wxdj FROM object_event oe LEFT JOIN object_country oc on oe.gjid = oc.id where wxdj != '' ");
        if (StringUtils.isNotBlank(country)) {
            sql.append("and oc.gj_cn = #{country} ");
        }
        sql.append(" group by wxdj ORDER BY wxdj DESC");
        return sql.toString();
    }

    /**
     * 通过条件查询事件类型
     */
    public String queryTagByCountryAndWxdj(EventQueryModel model) {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT tag1 FROM object_event oe LEFT JOIN object_country oc on oe.gjid = oc.id WHERE (tag1 !='' and tag2 != '' and tag3 != '') ");
        if (StringUtils.isNotBlank(model.getCountry())) {
            sql.append("and oc.gj_cn = #{country} ");
        }
        if (StringUtils.isNotBlank(model.getWxdj())) {
            sql.append("and oe.wxdj = #{wxdj} ");
        }
        sql.append("UNION SELECT tag2 FROM object_event oe LEFT JOIN object_country oc on oe.gjid = oc.id WHERE (tag1 !='' and tag2 != '' and tag3 != '') ");
        if (StringUtils.isNotBlank(model.getCountry())) {
            sql.append("and oc.gj_cn = #{country} ");

        }
        if (StringUtils.isNotBlank(model.getWxdj())) {
            sql.append("and oe.wxdj = #{wxdj} ");
        }
        sql.append("UNION SELECT tag3 FROM object_event oe LEFT JOIN object_country oc on oe.gjid = oc.id WHERE (tag1 !='' and tag2 != '' and tag3 != '') ");
        if (StringUtils.isNotBlank(model.getCountry())) {
            sql.append("and oc.gj_cn = #{country} ");

        }
        if (StringUtils.isNotBlank(model.getWxdj())) {
            sql.append("and oe.wxdj = #{wxdj} ");
        }
        return sql.toString();
    }

    public static String queryAllWxdj() {
        return "SELECT distinct(wxdj) from object_event";
    }

    //按照事件类型统计
    public static String statisticByEventType(String sql) {
      /*  StringBuffer buffer = new StringBuffer();
        for(String str:type){
            buffer.append(" SELECT count(*)  FROM object_event where `tag1` ='"+str+"' or `tag2` ='"+str+"' or `tag3` ='"+str+"' UNION ");
        }

        buffer.append("SELECT count(*)  FROM object_event where `tag1` ='' or `tag2` ='' or `tag3` =''");*/

        return sql;
    }

    //通过事件id查询事件
    public static String queryEventByID(int id) {
        return "SELECT * from object_event WHERE id=" + id;
    }

    //事件自定义标签
    public static String diyTagForEvent(String sql) {

        return sql;
    }

    //根据时间查询事件
    public static String queryEventByTime1(@Param("sql") String sql) {
        return sql;
    }

    //根据时间查询事件
    public static String queryEventByTime(EventQueryByPage input) {
        return "select  distinct  id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj from object_event where fssj between '" + input.getStartTime() + "' and '" + input.getEndTime() + "' order by fssj desc";
    }


    //根据标签查询事件
    public static String queryEventByTag(String tag) {
        return "select distinct id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj  from object_event where tag1 like '%" + tag + "%'";
    }

    public static String queryEventByShipName(String tag) {
        StringBuffer buffer = new StringBuffer();
        buffer.append("select distinct id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj  FROM `object_event` where `uuid` in ( ");
        buffer.append("SELECT   distinct event_id from `relation_ship_event` WHERE `ship_name` ='" + tag + "' ) ");
        return buffer.toString();
    }

    public static String queryLatestEvent(String sql) {
       /* StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT distinct t1.*,t2.person_name personName ,t2.person_id personID,t3.ship_id shipID ,t3.ship_name shipName ,t4.base_id baseID ,t4.base_name  baseName FROM `object_event` t1 ");
        buffer.append("left join  `relation_person_event` t2 on t1. uuid=t2.`event_id`  ");
        buffer.append("LEFT JOIN `relation_ship_event` t3 on t1.`uuid` =t3.`event_id` ");
        buffer.append("LEFT JOIN `relation_base_event` t4 on t1.`uuid` =t4.`event_id`");
        buffer.append("where t1.`uuid` in (  select uuid from ");
        buffer.append("( SELECT  uuid FROM object_event where zbjd is not null and `zbjd` !='' order by fssj desc  limit 1000 ) a)");
        buffer.append("and t1.zbjd is not null and t1.`zbjd` !='' order by t1.fssj desc  limit 5 ");
        return buffer.toString();*/
        return sql;
    }

    public static String queryEventByLocationAndEventType(@Param("input") EventQueryByPage input, @Param("baseIDs") List<Integer> baseIDs) {
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT t1.* FROM `object_event` t1  ");
        buffer.append("left join `relation_base_event` t2  on t1.`uuid` =t2.`event_id` ");
        buffer.append("where t1.tag1 like '%" + input.getEventType() + "%'  and t1.dd='" + input.getLocation() + "'  and t2.`base_id` in ( ");
        for (Integer baseID : baseIDs) {
            buffer.append(baseID + ",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" )");
        return buffer.toString();
    }

    public static String queryEventsByEventIDs(@Param("eventIds") List<String> eventIds) {
        StringBuffer buffer = new StringBuffer();

        buffer.append("SELECT * FROM object_event where uuid in ( ");
        for (String eventID : eventIds) {
            buffer.append("'" + eventID + "',");
        }

        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(")");
        return buffer.toString();
    }

    public static String queryEventByShipIDAndTime(@Param("id") Integer id, @Param("slice") SliceOfTime slice, @Param("baseIDs") List<Integer> baseIDs) {
        StringBuffer buffer = new StringBuffer();
        /*buffer.append("SELECT id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj  FROM object_event where uuid in ( ");
        buffer.append("SELECT distinct event_id from `relation_ship_event` where ship_id=" + id);
        buffer.append(" ) and `fssj` BETWEEN '" + slice.getBeginTime() + "'  and '" + slice.getEndTime() + "' ");*/

        buffer.append(" SELECT id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj  FROM object_event where uuid in ( ");
        buffer.append(" SELECT c.* FROM ( ");
        buffer.append("(SELECT distinct event_id from relation_ship_base where `ship_id` ="+id+"");
        buffer.append(" and `kssj` BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"' ");
        buffer.append(" and base_id in ( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" )) UNION ");
        buffer.append(" (SELECT distinct event_id from relation_ship_location where `ship_id` ="+id);
        buffer.append(" and `kssj` BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"' ");
        buffer.append(" and `qymc`  is not null and `qymc`  !='') ");
        buffer.append(" ) c ");
        buffer.append(" )   and `fssj` BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"' ");
        return buffer.toString();
    }

    public static String queryEventByPersonIDAndTime(@Param("id") Integer id, @Param("slice") SliceOfTime slice, @Param("baseIDs") List<Integer> baseIDs) {
        StringBuffer buffer = new StringBuffer();
       /* buffer.append("SELECT id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj  FROM object_event where uuid in ( ");
        buffer.append("SELECT distinct event_id from `relation_person_event` where person_id="+id);
        buffer.append(" ) and `fssj` BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"' ");*/

        buffer.append(" SELECT id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj  FROM object_event where uuid in ( ");
        buffer.append(" select a.id from ");
        buffer.append(" (SELECT distinct `event_id` id from `relation_person_event` WHERE  ");
        buffer.append(" `person_id` =" + id + " and kssj BETWEEN '" + slice.getBeginTime() + "'  and '" + slice.getEndTime() + "' ) a, ");
        buffer.append(" ( ");
        buffer.append(" SELECT  distinct `event_id` id from `relation_base_event` WHERE  base_id in ( ");
        for (Integer baseID : baseIDs) {
            buffer.append(baseID + ",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" ) and  kssj BETWEEN '" + slice.getBeginTime() + "'  and '" + slice.getEndTime() + "' ");
        buffer.append(" ) b  ");
        buffer.append(" where a.id=b.id ");
        buffer.append(" ) and `fssj` BETWEEN '" + slice.getBeginTime() + "'  and '" + slice.getEndTime() + "'  ");
        return buffer.toString();
    }

    //根据事件类型查询西太地区事件
    public static String queryEventByBaseIdsGroupByType(@Param("baseIDs") List<Integer> baseIDs, @Param("type") String type) {
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT id,uuid,bt,gjc,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj from object_event where tag1 like '%" + type + "%' and uuid in ( ");
        buffer.append("SELECT distinct event_id from `relation_base_event` where `base_id` in ( ");
        for (Integer baseID : baseIDs) {
            buffer.append(baseID + ",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append("))");
        buffer.append(" ORDER BY fssj desc ");
        return buffer.toString();
    }


}






















