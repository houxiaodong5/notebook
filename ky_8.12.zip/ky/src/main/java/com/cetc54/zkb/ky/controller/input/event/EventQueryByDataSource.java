package com.cetc54.zkb.ky.controller.input.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
@ApiModel("根据数据源查询事件输入类")
public class EventQueryByDataSource implements Serializable {
    @ApiModelProperty(value = "数据源中文名")
    private String datasource;
    @ApiModelProperty(value = "每页展示数量")
    private int pageSize;
    @ApiModelProperty(value = "当前页码")
    private int pageNum;

    public String getDatasource() {
        return datasource;
    }

    public void setDatasource(String datasource) {
        this.datasource = datasource;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    @Override
    public String toString() {
        return "EventQueryByDataSource{" +
                "datasource='" + datasource + '\'' +
                ", pageSize=" + pageSize +
                ", pageNum=" + pageNum +
                '}';
    }
}
