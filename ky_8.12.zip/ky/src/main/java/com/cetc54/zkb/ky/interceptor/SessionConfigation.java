/*
package com.cetc54.zkb.ky.interceptor;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
*/
/**
 *      重写 WebMvcConfigurerAdapter 中的 addInterceptors 方法把自定义的拦截器类添加进来
 * *//*

public class SessionConfigation extends WebMvcConfigurerAdapter {
*/
/**
      addPathPatterns("/**")对所有请求都拦截
      excludePathPatterns 排除拦截
   *//*


    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new SessionInterceptor())
                .addPathPatterns("/**");
    }



}
*/
