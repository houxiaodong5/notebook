package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.controller.input.user.UserInput;
import com.cetc54.zkb.ky.controller.input.user.UserViewRecord;
import com.cetc54.zkb.ky.controller.output.user.UserOutput;

import javax.servlet.http.HttpServletRequest;

public interface UserService {
    String registerUser(UserInput input);

    UserOutput login(HttpServletRequest request, UserInput input) throws Exception;

    Boolean logout(HttpServletRequest request);

    String userViewRecord(UserViewRecord userViewRecord)throws Exception;
}