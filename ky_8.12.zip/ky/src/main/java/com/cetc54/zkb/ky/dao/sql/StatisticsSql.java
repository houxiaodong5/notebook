package com.cetc54.zkb.ky.dao.sql;

import com.cetc54.zkb.ky.controller.input.event.EventQueryByIDAndTime;
import com.cetc54.zkb.ky.controller.output.event.EventAllMessageOutput;
import com.cetc54.zkb.ky.controller.output.event.EventAllMsgs;
import com.cetc54.zkb.ky.controller.output.event.SimpleModel;
import com.cetc54.zkb.ky.enums.BaseEnum;
import com.cetc54.zkb.ky.service.model.QueryModel;
import com.cetc54.zkb.ky.service.model.SliceOfTime;
import com.cetc54.zkb.ky.util.TimeUtil;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.Calendar;
import java.util.List;

public class StatisticsSql {
    /**                        ----------人员-----------                                     */
    //人员查询统计(1个月)
    public static String queryHottestPersonOneMonth(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select person_name name,person_id id,count(person_name) num from relation_person_event where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 month))   and now()");
        buffer.append(")  group by person_name order by num desc limit 10");
        return buffer.toString();
    }

    //一周
    public static String queryHottestPersonOneWeek(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select person_name name,person_id id,count(person_name) num from relation_person_event where event_id in (");
        buffer.append("select uuid from object_event where rksj BETWEEN  (select DATE_SUB(now(), interval 1 week))   and now()");
        buffer.append(")  group by person_name order by num desc limit 10");
        return buffer.toString();
    }

    //3天
    public static String queryHottestPersonThreeDay(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select person_name name,person_id id,count(person_name) num from relation_person_event where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 3 day))   and now()");
        buffer.append(")  group by person_name order by num desc limit 10");
        return buffer.toString();
    }

    /***-----------------------------舰船--------------------------*****/
    //舰船查询统计(1个月)
    public static String queryHottestShipOneMonth(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select ship_name name,ship_id id,count(ship_name) num from `relation_ship_event`  where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 month))   and now()");
        buffer.append(")  group by ship_name order by num desc limit 10");
        return buffer.toString();
    }

    //一周
    public static String queryHottestShipOneWeek(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select ship_name name,ship_id id,count(ship_name) num from `relation_ship_event`  where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 week))   and now()");
        buffer.append(")  group by ship_name order by num desc limit 10");
        return buffer.toString();
    }

    //3天
    public static String queryHottestShipThreeDay(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select ship_name name,ship_id id,count(ship_name) num from `relation_ship_event`  where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 3 day))   and now()");
        buffer.append(")  group by ship_name order by num desc limit 10");
        return buffer.toString();
    }


    /***-----------------------------基地--------------------------*****/
    //基地查询统计(1个月)
    public static String queryHottestBaseOneMonth(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select base_name name,base_id id,count(base_name) num from `relation_base_event`  where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 month))   and now()");
        buffer.append(")  group by base_name order by num desc limit 10");
        return buffer.toString();
    }

    //一周
    public static String queryHottestBaseOneWeek(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select base_name name,base_id id,count(base_name) num from `relation_base_event`  where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 week))   and now()");
        buffer.append(")  group by base_name order by num desc limit 10");
        return buffer.toString();
    }

    //3天
    public static String queryHottestBaseThreeDay(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select base_name name,base_id id,count(base_name) num from `relation_base_event`  where event_id in (");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 3 day))   and now()");
        buffer.append(")  group by base_name order by num desc limit 10");
        return buffer.toString();
    }

    public static String queryHottestWords(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select tag1 tag from object_event WHERE tag1!='' and tag1 is NOT null ");
        /*buffer.append("(");
        buffer.append(" select a.tag tag,a.num num from ");
        buffer.append(" (SELECT tag1 tag,count(tag1) num from `object_event`  where `tag1` !=''  GROUP BY `tag1` ORDER BY num desc) a ");
        buffer.append("   UNION ");
        buffer.append("select b.tag tag,b.num num from ");
        buffer.append("(SELECT tag2 tag,count(tag2) num from `object_event`  where `tag2` !=''  GROUP BY `tag2` ORDER BY num desc) b ");
        buffer.append("     UNION  ");
        buffer.append("select c.tag tag,c.num num from ");
        buffer.append("(SELECT tag3 tag,count(tag3) num from `object_event`  where `tag3` !=''  GROUP BY `tag3` ORDER BY num desc) c ");
        buffer.append(")d ");
        buffer.append(" GROUP BY tag ORDER BY num desc LIMIT 10 ");*/
        return buffer.toString();
    }

    //昨日事件统计
    public static String statisticsYesterdayEvent(String time){
        String sql="SELECT COUNT(*)  FROM `object_event`   WHERE `fssj` BETWEEN '"+time+" 00:00:00' and '"+time+" 23:59:59'";
        return  sql;
    }

    public static String selectHottestShip(int num){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select ship_name tag,count(ship_name) num from `relation_ship_event` ");
        buffer.append("where event_id in ( ");
        buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 month))   and now() ");
        buffer.append(" )  group by ship_name order by num desc limit"+num);
        return buffer.toString();
    }

    /*public static String queryTypesOfWestPacificBase(List<Integer> baseIDs){
        StringBuffer buffer=new StringBuffer();

    }*/

    public static String StatisticOfWestPacificBaseEvent(int baseID,String type){
        StringBuffer buffer=new StringBuffer();
        buffer.append("SELECT t1.tag1 tag,t1.uuid uuid,t2.`base_id` baseId,t3.`jdzwm` jdzwm ,t3.`jdywm` jdywm  ");
        buffer.append("FROM object_event t1,relation_base_event t2 ");
        buffer.append("LEFT JOIN object_base_basic_info t3 on  t3.`jdid` =t2.`base_id`  ");
        buffer.append("where t2.`base_id`="+baseID);
        if(type.equals("其他")){
            buffer.append("  and t1.tag1 is null and t1.`uuid` =t2.event_id  order by t3.`jdzwm`  ");
        }else {
            buffer.append("  and t1.tag1 like '%"+type+"%' and t1.`uuid` =t2.event_id  order by t3.`jdzwm`  ");
        }
        return buffer.toString();
    }

    public static String queryBaseByID(@Param("baseIDs") List<Integer> baseIDs){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT jdid,jdzwm,jdywm from object_base_basic_info where jdid in (");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(")");
        return buffer.toString();
    }

    public static String statisticsManoeuvreOfBaseByTime(@Param("baseID") int baseID,@Param("slice") SliceOfTime slice){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT count(*) from object_event  where uuid in ( ");
        buffer.append("SELECT `event_id`  FROM `relation_base_event` ");
        buffer.append("WHERE `base_id` ="+baseID+" and kssj BETWEEN '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"' ");
        buffer.append(") ");
        buffer.append("and tag1 like '%演习%'");
        return buffer.toString();
    }

    public static String  queryBasicShipMsg(@Param("baseIDs") List<Integer> baseIDs){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT t1.mc,t1.ywmc,t3.`ship_id` id FROM object_ship_basic_info t1,( ");
        buffer.append("SELECT  distinct t2.ship_id  FROM relation_ship_base t2 where t2.base_id in ( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(") ORDER BY t2.ship_id ");
        buffer.append(") t3   ");
        buffer.append("where t1.id=t3.ship_id ");
        return buffer.toString();
    }

    public static String queryBasicShipMsgExtra(){
        return " SELECT id,mc,ywmc FROM object_ship_basic_info where id in ( select distinct ship_id  FROM `relation_ship_location` where  qymc is not null and `qymc` !='' ) ";
    }



    public static String statisticsEventByTime(@Param("shipID") int shipID,@Param("slice")SliceOfTime slice,
                                               @Param("baseIDs") List<Integer> baseIDs){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT event_id from relation_ship_base where `ship_id` ="+shipID);
        buffer.append(" and `kssj` BETWEEN '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"' ");
        buffer.append("and base_id in (");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" )");
        return buffer.toString();
//    SELECT event_id from relation_ship_base where `ship_id` =5  and `kssj` BETWEEN '2019-01-01 00:00:00' and '2019-07-18 12:11:44' and base_id in (9,10,34)
      //  return "SELECT count(*) from relation_ship_base where `ship_id` ="+shipID+"  and `kssj` BETWEEN '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"'";
    }

    public static String statisticsEventByTime_Extra(@Param("shipID") int shipID,@Param("slice")SliceOfTime slice){
        //SQL：    SELECT `event_id`  FROM relation_ship_location where `ship_id` =1  and  `kssj` BETWEEN '2019-01-01 00:00:00' and '2019-07-18 12:11:44' and `qymc`  is not null and `qymc`  !=''
        StringBuffer buffer = new StringBuffer();
        buffer.append(" SELECT event_id from relation_ship_location where `ship_id` ="+shipID);
        buffer.append(" and `kssj` BETWEEN '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"' ");
        buffer.append(" and `qymc`  is not null and `qymc`  !=''");
        return buffer.toString();
    }


    public static String queryPersonByBase(@Param("baseIDs") List<Integer> baseIDs,@Param("time")String time){
        /*StringBuffer buffer = new StringBuffer();
        buffer.append("select distinct a.`person_id` id ,c.zwxm  mc ,c.`ywxm` ywmc   from relation_person_event a ");
        buffer.append("left join relation_base_event b on a.event_id = b.event_id ");
        buffer.append("LEFT JOIN `object_person` c on a.`person_id` =c.`renwuid` ");
        buffer.append("where b.base_id IN ( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(") ");
        buffer.append("and c.zwxm is not null  or c.`ywxm` is not null ");
        buffer.append("ORDER BY id ");*/


        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT a.`person_id` id ,COUNT(a.`event_id`) number , c.zwxm  mc ,c.`ywxm` ywmc    from relation_person_event a ");
        buffer.append("LEFT JOIN relation_base_event b on a.event_id = b.event_id ");
        buffer.append("LEFT JOIN `object_person` c on a.`person_id` =c.`renwuid` ");
        buffer.append("where b.base_id IN ( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(") ");
        if(time.equals("1Month")){
            buffer.append(" and a.`kssj` > '"+ TimeUtil.getBeginTimeOfMonth() +"'");//本月
        }else {//7Day,3Day,1Day
            //Calendar instance = Calendar.getInstance();
            //instance.add();
            buffer.append(" and a.`kssj` > (select DATE_SUB(now(), interval "+time.charAt(0)+" day))");
        }

        buffer.append(" GROUP BY a.`person_id` ORDER BY number desc LIMIT 10");
        return buffer.toString();
    }

    //统计人物事件
    public static String  statisticsEventByTimeOfPerson(@Param("personID") int personID,@Param("slice") SliceOfTime slice){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT `event_id` from `relation_person_event` WHERE  ");
        buffer.append("`person_id` ="+personID+" and kssj BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"'");
        return buffer.toString();
    }
    //统计人物事件
    public static String statisticsEventByTimeOfPerson_extra(@Param("baseIDs") List<Integer> baseIDs, @Param("slice") SliceOfTime slice){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT `event_id` from `relation_base_event` WHERE  base_id in ( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" ) and  kssj BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"'");
        return buffer.toString();
    }

    public static String statisticsQuantityOfShipByState(@Param("baseIDs")List<Integer> baseIDs){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT t1.gxlx state,count(t1.event_id) number from relation_ship_location t1 ");
        buffer.append("LEFT JOIN `relation_base_event` t2 on t1.`event_id` =t2.`event_id`  ");
        buffer.append("where t1.gxlx in  ");
        buffer.append("(SELECT distinct gxlx from `relation_ship_location` )  and t2.`base_id` in ( ");
        for(Integer baseID :baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" ) GROUP BY t1.`gxlx` ORDER BY number desc");
        return buffer.toString();
    }

    public static String queryMostEventOfBaseByTime(@Param("slice") SliceOfTime slice,@Param("baseIDs") List<Integer> baseIDs){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select t1.jdid id,t1.jdzwm mc,t1.jdywm ywmc from object_base_basic_info t1 where t1.`jdid` in ");
        buffer.append(" ( ");
        buffer.append("select t2.base_id from ( ");
        buffer.append("SELECT  base_id,COUNT(event_id) number  FROM `relation_base_event`where base_id in ( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" )  and  kssj BETWEEN '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"' GROUP BY base_id order by number desc limit 5) t2 ");
        buffer.append(") ");
        return buffer.toString();
    }

    public static String statisticsEventCountByBaseIDInSliceOfTime(@Param("baseID") Integer baseID,@Param("slice") SliceOfTime slice){
        return "SELECT COUNT(event_id) number  from `relation_base_event` WHERE base_id="+baseID+" and kssj BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"'";
    }

    public static String statisticsEventByTimeAndType(@Param("baseIDs")List<Integer> baseIDs,@Param("slice") SliceOfTime slice,@Param("type") String type){
        StringBuffer buffer = new StringBuffer();
        buffer.append("select COUNT(uuid) from object_event where uuid in ( ");
        //buffer.append("SELECT DISTINCT(event_id) FROM `relation_base_event` where kssj >= ");
        buffer.append("SELECT DISTINCT(event_id) FROM `relation_base_event` where kssj >='"+slice.getBeginTime()+"' and kssj<'"+slice.getEndTime()+"' ");
        buffer.append("and `base_id` in( ");
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(")) and tag1 like '%"+type+"%'");
        return buffer.toString();
    }

    //根据时间段统计西太地区舰船在港、离港数量   //list[0]-在港,list[1]不在港
    public static String  statisticsShipByStateAndSliceOfTime(@Param("slice") SliceOfTime slice){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT count(distinct ship_id)  FROM `relation_ship_location` where qymc is not null and qymc !='' ");
        buffer.append("and kssj between '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"' " );
        buffer.append(" and (gxlx='in' or gxlx='goto') ");
        buffer.append(" UNION  ");
        buffer.append(" SELECT count(distinct ship_id)  FROM `relation_ship_location` where qymc is not null and qymc !='' and gxlx='leave' ");
        buffer.append("and kssj between '"+slice.getBeginTime()+"' and '"+slice.getEndTime()+"' " );
        return buffer.toString();
    }

    //根据时间及舰船状态查询对应舰船
    public static String  queryShipsByStateAndTime(QueryModel model){
        StringBuffer buffer = new StringBuffer();
        SliceOfTime slice = model.getQueryTime();
        String state = model.getState();
        buffer.append("SELECT * FROM object_ship_basic_info where  id in ( ");
        if(model.getFlag().equals("时")){
            buffer.append("SELECT distinct ship_id FROM `relation_ship_location` where kssj BETWEEN '"+slice.getBeginTime()+"' and  '"+slice.getEndTime()+"' ");
        }else if(model.getFlag().equals("日")){
            buffer.append("SELECT distinct ship_id FROM `relation_ship_location` where kssj >= '"+slice.getBeginTime()+"' and kssj< '"+slice.getEndTime()+"' ");
        }

        if(state.equals("在港")){
            buffer.append("and  qymc is not null and qymc !='' and( gxlx ='in' or gxlx='goto') ");
        }else if(state.equals("离港")){
            buffer.append("and  qymc is not null and qymc !='' and gxlx='leave' ");
        }
        buffer.append(" )");
        return buffer.toString();
    }

    //根据时间及舰船、舰船状态查询对应事件
    public static String  queryEventsByStateAndTimeAndShipID(QueryModel model){
        StringBuffer buffer = new StringBuffer();
        SliceOfTime slice = model.getQueryTime();
        String state = model.getState();
        int shipID = model.getShipID();
        buffer.append("SELECT * FROM object_event where  uuid in ( ");
        if(model.getFlag().equals("时")){
            buffer.append("SELECT distinct event_id FROM `relation_ship_location` where ship_id="+shipID+" and  kssj BETWEEN '"+slice.getBeginTime()+"' and  '"+slice.getEndTime()+"' ");
        }else if(model.getFlag().equals("日")){
            buffer.append("SELECT distinct event_id FROM `relation_ship_location` where ship_id="+shipID+" and  kssj >= '"+slice.getBeginTime()+"' and kssj< '"+slice.getEndTime()+"' ");
        }

        if(state.equals("在港")){
            buffer.append("and  qymc is not null and qymc !='' and( gxlx ='in' or gxlx='goto') ");
        }else if(state.equals("离港")){
            buffer.append("and  qymc is not null and qymc !='' and gxlx='leave' ");
        }
        buffer.append(" )");
        return buffer.toString();
    }

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>,携带相关人物、舰船、基地
    public static String queryEventsByTypeAndTime(@Param("type") String type, @Param("slice") SliceOfTime slice, @Param("flag") String flag){
        StringBuffer buffer = new StringBuffer();
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj ");
        buffer.append(" FROM `object_event` t1 ");
        buffer.append("where t1.`uuid` in (  ");
        if(flag.equals("MONTH")){ //2019-07
            buffer.append(" SELECT DISTINCT(event_id) FROM `relation_base_event` where kssj >='"+slice.getBeginTime()+"' and kssj<'"+slice.getEndTime()+"' and base_id in (");
        }else if(flag.equals("DAY")){//7-25
            buffer.append(" SELECT DISTINCT(event_id) FROM `relation_base_event` where kssj BETWEEN  '"+slice.getBeginTime()+"' and  '"+slice.getEndTime()+"' and base_id in (");
        }
        for(Integer baseID:baseIDs){
            buffer.append(baseID+",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" ))  and t1.tag1 like '%"+type+"%'   order by t1.fssj desc");
        return buffer.toString();
    }

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关人物  填充127数据
    public static String querySimplePersonByUUID(String uuid){
        return " SELECT `person_name`   name ,person_id id from relation_person_event where `event_id` = '"+uuid+"'";
    }

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关舰船  填充127数据
    public static String querySimpleShipByUUID(String uuid){
        return " SELECT `ship_name`  name ,ship_id id from relation_ship_event where `event_id` = '"+uuid+"'";
    }

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关基地  填充127数据
    public static String querySimpleBaseByUUID(String uuid){
        return " SELECT `base_name`   name ,base_id id from relation_base_event where `event_id` = '"+uuid+"'";
    }


    //西太地区：根据基地id及时间查询事件信息
    public static String queryEventsByTimeAndBaseID(@Param("slice") SliceOfTime slice, @Param("id") Integer id){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj ");
        buffer.append(" FROM `object_event` t1 ");
        buffer.append("where t1.`uuid` in (  ");
        buffer.append(" SELECT distinct `event_id`   from `relation_base_event` WHERE base_id="+id+"  and kssj BETWEEN '"+slice.getBeginTime()+"'  and '"+slice.getEndTime()+"'");
        buffer.append(" ) ");
        return buffer.toString();
    }

    //西太地区：根据事件类型及基地id查询相关事件
    public static String queryEventsByTypeAndBaseID(EventQueryByIDAndTime input){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT   distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj ");
        buffer.append("from `object_event` t1 where t1.uuid in ( ");
        buffer.append("SELECT DISTINCT `event_id`  from `relation_base_event` where base_id= "+input.getId());
        buffer.append("  ) and t1.tag1 like '%"+input.getType()+"%'");
        return buffer.toString();
    }

    //统计用户查看最多的新闻(前20条)
    public static String statisticsMostEventsOfViewed(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT t1.uuid uuid,t1.`id` id,t1.`bt` bt,t1.`gjc`,t1.`fssj` ,t1.`tag1` ,t1.`gjmc` ,t1.`dd`,t2.number viewNumber  from `object_event` t1, ");
        buffer.append("(SELECT event_id,SUM(view_number) number from relation_ky_user_event  GROUP BY event_id  order by number desc limit 20) t2 ");
        buffer.append("where t1.`uuid` =t2.event_id  ORDER BY t2.number desc ");
        return buffer.toString();
    }


    public static void main(String[] args) {
        List<Integer> integers = BaseEnum.allOfBaseID();
        for(Integer a:integers){
            System.out.print(a+",");
        }

       // System.out.println(queryPersonByBase(integers, "7Day"));

    }



}
