package com.cetc54.zkb.ky.service.model;

public class StatisticEventModel {
    private String time;
    private String wxdj;
    private String tag;
    private String format;

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getWxdj() {
        return this.wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }

    public String getTag() {
        return this.tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getFormat() {
        return this.format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
