package com.cetc54.zkb.ky.controller.output.statistics;

import java.util.List;

public class OutputHottestWords {
    private List<String> words;
    private List<Long> num;

    public List<String> getWords() {
        return words;
    }

    public void setWords(List<String> words) {
        this.words = words;
    }

    public List<Long> getNum() {
        return num;
    }

    public void setNum(List<Long> num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "OutputHottestWords{" +
                "words=" + words +
                ", num=" + num +
                '}';
    }
}
