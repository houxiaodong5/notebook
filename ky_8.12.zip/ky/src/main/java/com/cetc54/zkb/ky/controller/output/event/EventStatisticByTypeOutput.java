package com.cetc54.zkb.ky.controller.output.event;

import java.util.List;

/**
 * Created by Administrator on 2019/5/26/026.
 */
public class EventStatisticByTypeOutput {
    private List<String> type;
    private List<Long> count;

    public List<String> getType() {
        return type;
    }

    public void setType(List<String> type) {
        this.type = type;
    }

    public List<Long> getCount() {
        return count;
    }

    public void setCount(List<Long> count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "EventStatisticByTypeOutput{" +
                "type=" + type +
                ", count=" + count +
                '}';
    }
}
