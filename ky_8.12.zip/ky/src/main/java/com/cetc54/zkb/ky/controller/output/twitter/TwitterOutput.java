package com.cetc54.zkb.ky.controller.output.twitter;

import com.cetc54.zkb.ky.util.TimeUtil;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.util.*;

/**
 *      twitter
 * */
public class TwitterOutput implements Serializable {
    static final String prefix_image_url="https://shujucaiji.oss-cn-beijing.aliyuncs.com/photos";
    static final String prefix_video_url="https://shujucaiji.oss-cn-beijing.aliyuncs.com/videos";
    private String vc_id="";
    private String vc_nickname="";//用户昵称
    private String vc_username="";//用户名
    private String vc_retweet_username="";//转发自
    private String vc_retweet_userid="";//转发用户id
    private String vc_retweet_nickname="";//转发用户昵称
    private String vc_photo_url="";//头像地址
    private String vc_photo_url_local="";//头像本地地址
    private String vc_tweetid="";//发文id
    private String vc_tweet_url="";//发文url
    private String vc_retweet_title="";//转推发文标题
    private String vc_retweet_content="";//转推发文内容缩略
    private String vc_retweet_web="";//转推发文新闻官网
    private String vc_retweet_url="";//转推发文URL地址
    private String vc_retweet_img="";//转推图片URL地址
    private String vc_retweet_img_local="";//推图片URL本地地址
    private String vc_tweet_type="";
    private String text_tweet_content="";
    private String text_picture_url="";
    private String text_picture_url_local="";
    private String vc_reply_count="";
    private String vc_retweet_count="";
    private String vc_favorites_count="";
    private String vc_video_url="";
    private String vc_video_url_local="";
    private String vc_video_picture_url_local="";  //vc_video_picture_url_local
    private String vc_video_picture_url="";
    private String dt_pubdate="";
    private String dt_gather_time="";
    private String vc_lang="";
    private String vc_task_id="";
    private String vc_task_type="";
    private String vc_post_type="";
    private List<String>  imgs=new ArrayList<>();
    private List<String> videos=new ArrayList<>();

    public List<String> getVideos() {
        return videos;
    }

    public void setVideos(List<String> videos) {
        this.videos = videos;
    }

    public String getVc_id() {
        return vc_id;
    }

    public void setVc_id(String vc_id) {
        this.vc_id = vc_id;
    }

    public String getVc_nickname() {
        return vc_nickname;
    }

    public void setVc_nickname(String vc_nickname) {
        this.vc_nickname = vc_nickname;
    }

    public String getVc_username() {
        return vc_username;
    }

    public void setVc_username(String vc_username) {
        this.vc_username = vc_username;
    }

    public String getVc_retweet_username() {
        return vc_retweet_username;
    }

    public void setVc_retweet_username(String vc_retweet_username) {
        this.vc_retweet_username = vc_retweet_username;
    }

    public String getVc_retweet_userid() {
        return vc_retweet_userid;
    }

    public void setVc_retweet_userid(String vc_retweet_userid) {
        this.vc_retweet_userid = vc_retweet_userid;
    }

    public String getVc_retweet_nickname() {
        return vc_retweet_nickname;
    }

    public void setVc_retweet_nickname(String vc_retweet_nickname) {
        this.vc_retweet_nickname = vc_retweet_nickname;
    }

    public String getVc_photo_url() {
        return vc_photo_url;
    }

    public void setVc_photo_url(String vc_photo_url) {
        this.vc_photo_url = vc_photo_url;
    }

    public String getVc_photo_url_local() {
        return vc_photo_url_local;
    }

    public void setVc_photo_url_local(String vc_photo_url_local) {
        this.vc_photo_url_local=vc_photo_url_local;

    }



    public String getVc_retweet_img() {
        return vc_retweet_img;
    }

    public void setVc_retweet_img(String vc_retweet_img) {
        this.vc_retweet_img = vc_retweet_img;
    }

    public String getVc_retweet_img_local() {
        return vc_retweet_img_local;
    }

    public void setVc_retweet_img_local(String vc_retweet_img_local) {
        this.vc_retweet_img_local = vc_retweet_img_local;
    }

    public String getVc_tweet_type() {
        return vc_tweet_type;
    }

    public void setVc_tweet_type(String vc_tweet_type) {
        this.vc_tweet_type = vc_tweet_type;
    }

    public String getVc_reply_count() {
        return vc_reply_count;
    }

    public void setVc_reply_count(String vc_reply_count) {
        this.vc_reply_count = vc_reply_count;
    }

    public String getVc_retweet_count() {
        return vc_retweet_count;
    }

    public void setVc_retweet_count(String vc_retweet_count) {
        this.vc_retweet_count = vc_retweet_count;
    }

    public String getVc_favorites_count() {
        return vc_favorites_count;
    }

    public void setVc_favorites_count(String vc_favorites_count) {
        this.vc_favorites_count = vc_favorites_count;
    }

    public String getVc_video_url() {
        return vc_video_url;
    }

    public void setVc_video_url(String vc_video_url) {
        this.vc_video_url = vc_video_url;
    }

    public String getVc_video_url_local() {
        return vc_video_url_local;
    }

    public void setVc_video_url_local(String vc_video_url_local) {
        this.vc_video_url_local = vc_video_url_local;
    }

    public String getVc_video_picture_url_local() {
        return vc_video_picture_url_local;
    }

    public void setVc_video_picture_url_local(String vc_video_picture_url_local) {
        this.vc_video_picture_url_local = vc_video_picture_url_local;
    }

    public String getVc_video_picture_url() {
        return vc_video_picture_url;
    }

    public void setVc_video_picture_url(String vc_video_picture_url) {
        this.vc_video_picture_url = vc_video_picture_url;
    }

    public String getDt_gather_time() {
        return dt_gather_time;
    }

    public void setDt_gather_time(String dt_gather_time) {
        this.dt_gather_time = TimeUtil.formateStringTime(dt_gather_time);
    }

    public String getVc_lang() {
        return vc_lang;
    }

    public void setVc_lang(String vc_lang) {
        this.vc_lang = vc_lang;
    }

    public String getVc_task_id() {
        return vc_task_id;
    }

    public void setVc_task_id(String vc_task_id) {
        this.vc_task_id = vc_task_id;
    }

    public String getVc_task_type() {
        return vc_task_type;
    }

    public void setVc_task_type(String vc_task_type) {
        this.vc_task_type = vc_task_type;
    }

    public String getVc_post_type() {
        return vc_post_type;
    }

    public void setVc_post_type(String vc_post_type) {
        this.vc_post_type = vc_post_type;
    }

    public String getVc_tweetid() {
        return vc_tweetid;
    }

    public void setVc_tweetid(String vc_tweetid) {
        this.vc_tweetid = vc_tweetid;
    }

    public String getVc_tweet_url() {
        return vc_tweet_url;
    }

    public void setVc_tweet_url(String vc_tweet_url) {
        this.vc_tweet_url = vc_tweet_url;
    }

    public String getVc_retweet_title() {
        return vc_retweet_title;
    }

    public void setVc_retweet_title(String vc_retweet_title) {
        this.vc_retweet_title = vc_retweet_title;
    }

    public String getVc_retweet_content() {
        return vc_retweet_content;
    }

    public void setVc_retweet_content(String vc_retweet_content) {
        this.vc_retweet_content = vc_retweet_content;
    }

    public String getVc_retweet_web() {
        return vc_retweet_web;
    }

    public void setVc_retweet_web(String vc_retweet_web) {
        this.vc_retweet_web = vc_retweet_web;
    }

    public String getVc_retweet_url() {
        return vc_retweet_url;
    }

    public void setVc_retweet_url(String vc_retweet_url) {
        this.vc_retweet_url = vc_retweet_url;
    }

    public String getText_tweet_content() {
        return text_tweet_content;
    }

    public void setText_tweet_content(String text_tweet_content) {
        this.text_tweet_content = text_tweet_content;
    }

    public String getText_picture_url() {
        return text_picture_url;
    }

    public void setText_picture_url(String text_picture_url) {
        this.text_picture_url = text_picture_url;
    }

    public String getText_picture_url_local() {
        return text_picture_url_local;
    }

    public void setText_picture_url_local(String text_picture_url_local) {
        this.text_picture_url_local = text_picture_url_local;
    }

    public String getDt_pubdate() {
        return dt_pubdate;
    }

    public void setDt_pubdate(String dt_pubdate) {
        this.dt_pubdate = TimeUtil.formateStringTime(dt_pubdate);
    }

    public List<String> getImgs() {
        return imgs;
    }

    public void setImgs(List<String> imgs) {
        this.imgs = imgs;
    }

    public static TwitterOutput standardData(TwitterOutput output){
        List<String> imgs = output.getImgs();
        List<String> videos = output.getVideos();
        String picture_url_local = output.getText_picture_url_local();//推文配图
        String video_url_local = output.getVc_video_url_local();//推文视频

        StringTokenizer imageTokenizer = new StringTokenizer(picture_url_local, ",");
        while (imageTokenizer.hasMoreTokens()){
            String nextToken = imageTokenizer.nextToken();
            if(nextToken.startsWith("/")){
                imgs.add(prefix_image_url+nextToken);
            }else {
                imgs.add(prefix_image_url+"/"+nextToken);
            }

        }

        StringTokenizer imageTokenizer1 = new StringTokenizer(picture_url_local, "，");
        while (imageTokenizer1.hasMoreTokens()){
            String nextToken = imageTokenizer1.nextToken();
            if(nextToken.startsWith("/")){
                imgs.add(prefix_image_url+nextToken);
            }else {
                imgs.add(prefix_image_url+"/"+nextToken);
            }

        }


        StringTokenizer videoTokenizer = new StringTokenizer(video_url_local, ",");
        while (videoTokenizer.hasMoreTokens()){
            String nextToken = videoTokenizer.nextToken();
            if(nextToken.startsWith("/")){
                videos.add(prefix_video_url+nextToken);
            }else {
                videos.add(prefix_video_url+"/"+nextToken);
            }

        }

        StringTokenizer videoTokenizer1 = new StringTokenizer(video_url_local, "，");
        while (videoTokenizer1.hasMoreTokens()){
            String nextToken = videoTokenizer1.nextToken();
            if(nextToken.startsWith("/")){
                videos.add(prefix_video_url+nextToken);
            }else {
                videos.add(prefix_video_url+"/"+nextToken);
            }

        }

        HashSet<String> imgSet = new LinkedHashSet<>(imgs);
        imgs.clear();
        imgs.addAll(imgSet);

        HashSet<String> videoSet = new LinkedHashSet<>(videos);
        videos.clear();
        videos.addAll(videoSet);

        return output;
    }

    public static String getPrefix_image_url() {
        return prefix_image_url;
    }

    public static String getPrefix_video_url() {
        return prefix_video_url;
    }

    @Override
    public String toString() {
        return "TwitterOutput{" +
                "vc_id='" + vc_id + '\'' +
                ", vc_nickname='" + vc_nickname + '\'' +
                ", vc_username='" + vc_username + '\'' +
                ", vc_retweet_username='" + vc_retweet_username + '\'' +
                ", vc_retweet_userid='" + vc_retweet_userid + '\'' +
                ", vc_retweet_nickname='" + vc_retweet_nickname + '\'' +
                ", vc_photo_url='" + vc_photo_url + '\'' +
                ", vc_photo_url_local='" + vc_photo_url_local + '\'' +
                ", vc_tweetid='" + vc_tweetid + '\'' +
                ", vc_tweet_url='" + vc_tweet_url + '\'' +
                ", vc_retweet_title='" + vc_retweet_title + '\'' +
                ", vc_retweet_content='" + vc_retweet_content + '\'' +
                ", vc_retweet_web='" + vc_retweet_web + '\'' +
                ", vc_retweet_url='" + vc_retweet_url + '\'' +
                ", vc_retweet_img='" + vc_retweet_img + '\'' +
                ", vc_retweet_img_local='" + vc_retweet_img_local + '\'' +
                ", vc_tweet_type='" + vc_tweet_type + '\'' +
                ", text_tweet_content='" + text_tweet_content + '\'' +
                ", text_picture_url='" + text_picture_url + '\'' +
                ", text_picture_url_local='" + text_picture_url_local + '\'' +
                ", vc_reply_count='" + vc_reply_count + '\'' +
                ", vc_retweet_count='" + vc_retweet_count + '\'' +
                ", vc_favorites_count='" + vc_favorites_count + '\'' +
                ", vc_video_url='" + vc_video_url + '\'' +
                ", vc_video_url_local='" + vc_video_url_local + '\'' +
                ", vc_video_picture_url_local='" + vc_video_picture_url_local + '\'' +
                ", vc_video_picture_url='" + vc_video_picture_url + '\'' +
                ", dt_pubdate='" + dt_pubdate + '\'' +
                ", dt_gather_time='" + dt_gather_time + '\'' +
                ", vc_lang='" + vc_lang + '\'' +
                ", vc_task_id='" + vc_task_id + '\'' +
                ", vc_task_type='" + vc_task_type + '\'' +
                ", vc_post_type='" + vc_post_type + '\'' +
                ", imgs=" + imgs +
                '}';
    }

    public static void main(String[] args) {
        /*TwitterOutput twitterOutput = new TwitterOutput();
        twitterOutput.setVc_video_url_local("twitter/846038583760699392/b12b4c19b1d8fc204e9c17ec3557a565.mp4");
        standardData(twitterOutput);*/
        String s="ss";
        StringTokenizer stringTokenizer = new StringTokenizer(s, ",");
        System.out.println(stringTokenizer.hasMoreTokens());
    }
}
