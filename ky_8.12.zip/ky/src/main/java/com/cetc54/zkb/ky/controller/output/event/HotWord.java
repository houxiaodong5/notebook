package com.cetc54.zkb.ky.controller.output.event;

public class HotWord{
    private Long num;
    private String tag;

    public Long getNum() {
        return num;
    }

    public void setNum(Long num) {
        this.num = num;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    @Override
    public String toString() {
        return "HotWord{" +
                "num=" + num +
                ", tag='" + tag + '\'' +
                '}';
    }
}
