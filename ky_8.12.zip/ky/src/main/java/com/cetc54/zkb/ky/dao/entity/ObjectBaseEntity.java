package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.controller.output.base.SimpleUnitMsg;
import com.cetc54.zkb.ky.util.TimeUtil;

import java.util.Date;
import java.util.List;

public class ObjectBaseEntity {
    private Long jdid=0L;
    private String jdzwm="";
    private String jdywm="";
    private String jdszd="";
    private String jdjj="";
    private String lsy="";
    private String cjsj="";
    private Float zxdjd=0f;
    private Float zxdwd=0f;
    private String jdhtmldh="";
    private String bdlb="";
    private String gj="";
    private List<SimpleUnitMsg> units;

    public void setJdid(Long jdid) {
        this.jdid = jdid;
    }

    public Long getJdid() {
        return this.jdid;
    }

    public void setJdzwm(String jdzwm) {
        this.jdzwm = jdzwm;
    }

    public String getJdzwm() {
        return this.jdzwm;
    }

    public void setJdywm(String jdywm) {
        this.jdywm = jdywm;
    }

    public String getJdywm() {
        return this.jdywm;
    }

    public void setJdszd(String jdszd) {
        this.jdszd = jdszd;
    }

    public String getJdszd() {
        return this.jdszd;
    }

    public void setJdjj(String jdjj) {
        this.jdjj = jdjj;
    }

    public String getJdjj() {
        return this.jdjj;
    }

    public void setLsy(String lsy) {
        this.lsy = lsy;
    }

    public String getLsy() {
        return this.lsy;
    }

    public String getCjsj() {
        return cjsj;
    }

    public void setCjsj(String cjsj) {
        this.cjsj = TimeUtil.formateStringTime(cjsj);
    }

    public void setZxdjd(Float zxdjd) {
        this.zxdjd = zxdjd;
    }

    public Float getZxdjd() {
        return this.zxdjd;
    }

    public void setZxdwd(Float zxdwd) {
        this.zxdwd = zxdwd;
    }

    public Float getZxdwd() {
        return this.zxdwd;
    }

    public void setJdhtmldh(String jdhtmldh) {
        this.jdhtmldh = jdhtmldh;
    }

    public String getJdhtmldh() {
        return this.jdhtmldh;
    }

    public String getBdlb() {
        return bdlb;
    }

    public void setBdlb(String bdlb) {
        this.bdlb = bdlb;
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj;
    }

    public List<SimpleUnitMsg> getUnits() {
        return units;
    }

    public void setUnits(List<SimpleUnitMsg> units) {
        this.units = units;
    }

    @Override
    public String toString() {
        return "ObjectBaseEntity{" +
                "jdid=" + jdid +
                ", jdzwm='" + jdzwm + '\'' +
                ", jdywm='" + jdywm + '\'' +
                ", jdszd='" + jdszd + '\'' +
                ", jdjj='" + jdjj + '\'' +
                ", lsy='" + lsy + '\'' +
                ", cjsj='" + cjsj + '\'' +
                ", zxdjd=" + zxdjd +
                ", zxdwd=" + zxdwd +
                ", jdhtmldh='" + jdhtmldh + '\'' +
                ", bdlb='" + bdlb + '\'' +
                ", gj='" + gj + '\'' +
                ", units=" + units +
                '}';
    }
}
