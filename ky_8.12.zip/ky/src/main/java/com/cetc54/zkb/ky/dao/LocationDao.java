package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.output.base.SimpleUnitMsg;
import com.cetc54.zkb.ky.controller.output.event.LocationEventOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.ship.ObjectShipOutput;
import com.cetc54.zkb.ky.dao.entity.*;
import com.cetc54.zkb.ky.dao.sql.EventSql;
import com.cetc54.zkb.ky.dao.sql.LocationSql;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

/**
 * Created by Administrator on 2019/5/25/025.
 */
public interface LocationDao {

    //查询所有地点
    @SelectProvider(type = LocationSql.class,method = "queryAllLocation")
    List<ObjectLocation> queryAllLocation();

    //根据地点ID查询此地区所有事件
    @SelectProvider(type = LocationSql.class,method = "queryAllEventByLocationID")
    List<ObjectEventOutput> queryAllEventByLocationID(String locationID);

    //查询所有基地
    @SelectProvider(type = LocationSql.class,method = "queryAllBase")
    List<ObjectBaseBasicInfoEntity> queryAllBase();

    //根据基地ID查询基地事件
    @SelectProvider(type = LocationSql.class,method = "queryAllEventByBaseID")
    List<ObjectEventOutput> queryAllEventByBaseID(Integer jdid);

    //查询所有人物（有事件的）
    @SelectProvider(type = LocationSql.class,method = "queryAllPerson")
    List<ObjectPerson> queryAllPerson();

    //根据人物ID查询事件
    @SelectProvider(type = LocationSql.class,method = "queryAllEventByPersonID")
    List<ObjectEventOutput> queryAllEventByPersonID(Integer renwuid,String name);

    //查询所有船舶
    @SelectProvider(type = LocationSql.class,method = "queryAllShip")
    List<ObjectShipBasicInfoEntity> queryAllShip();
    //根据船舶ID查询所有事件
    @SelectProvider(type = LocationSql.class,method = "queryEventByShipID")
    List<ObjectEventOutput> queryEventByShipID(Integer shipID);

    //查询基地基础信息
    @SelectProvider(type = LocationSql.class,method = "queryBaseByBaseID")
    ObjectBaseBasicInfoEntity queryBaseByBaseID(int bridgeID);
    //查询基地联队基础信息
    @SelectProvider(type = LocationSql.class,method = "queryBaseUnitsInfoByBaseID")
    List<SimpleUnitMsg> queryBaseUnitsInfoByBaseID(@Param("realBaseID") int realBaseID);
    //查询人员
    @SelectProvider(type = LocationSql.class,method = "queryPersonByPersonID")
    ObjectPerson queryPersonByPersonID(int personID);

    @SelectProvider(type = LocationSql.class,method = "queryPersonByPersonIDs")
    List<ObjectPerson>queryPersonByPersonIDs(String sql);

    //根据基地id查询基地信息
    @SelectProvider(type = LocationSql.class,method = "queryBaseByID")
    ObjectBaseBasicInfoEntity queryBaseByID(@Param("baseID") int baseID);
}
