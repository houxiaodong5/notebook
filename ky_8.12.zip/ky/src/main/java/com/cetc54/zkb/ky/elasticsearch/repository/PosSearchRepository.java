package com.cetc54.zkb.ky.elasticsearch.repository;

import com.cetc54.zkb.ky.elasticsearch.document.Person;
import com.cetc54.zkb.ky.elasticsearch.document.Position;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import java.util.List;

public interface PosSearchRepository extends ElasticsearchRepository<Position,Long> {
    List<Position> queryAllByNameContains(String name);
    List<Position> queryNameByNameContains(String name);

}
