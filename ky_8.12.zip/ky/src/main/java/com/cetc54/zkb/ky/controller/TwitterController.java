package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.VideoOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutput;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutputByPage;
import com.cetc54.zkb.ky.dao.entity.ObjectDocument;
import com.cetc54.zkb.ky.service.TwitterService;
import com.cetc54.zkb.ky.util.OSSUtil;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
@Api("twitter-controller")
public class TwitterController extends BaseController {
    public static TwitterOutput twitterOutput;
    public static List<VideoOutput> videoList;

    @Autowired
    private TwitterService twitterService;

    //5s更新twitter数据   20
    @Scheduled(cron = "*/5 * * * * ?")
    public void queryAllEventTimely(){
        TwitterOutput twitter = twitterService.queryLatestTwitter();
        if(null!=twitter){
            twitterOutput=twitter;
        }

    }

    @ApiOperation("分页展示twitter新闻")
    @PostMapping("/query/twitter/news/by/page")
    public DataResponse<TwitterOutputByPage> queryTwitterNewsByPage(@RequestBody QueryByPage page){
        return this.success(twitterService.queryTwitterNewsByPage(page));
    }
    //5m更新视频数据
    @Scheduled(cron = "0 */5 * * * ?")
    //@Scheduled(fixedRate = 60 * 1000 * 5)
    public void queryVideoData(){
        videoList = OSSUtil.getOSSData();
        //videoList=.twitterServicequeryVideoData();
    }

    @ApiOperation("实时视频展示")
    @GetMapping({"/show/video/timely"})
    public DataResponse<List<VideoOutput>> showVideoTimely() {
        if (videoList==null){
            queryVideoData();
        }
        return this.success(videoList);
    }
    //军事文件展示
    @ApiOperation("展示军事文件")
    @GetMapping({"/query/file"})
    public DataResponse<List<ObjectDocument>> queryFile() {
        return this.success(twitterService.queryFile());
    }
}
