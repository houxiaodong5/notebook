package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutput;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutputByPage;
import com.cetc54.zkb.ky.dao.entity.ObjectDocument;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface TwitterService {

    TwitterOutput queryLatestTwitter();

    TwitterOutputByPage queryTwitterNewsByPage(QueryByPage page);

    //查询pdf文件
    List<ObjectDocument> queryFile();
}

