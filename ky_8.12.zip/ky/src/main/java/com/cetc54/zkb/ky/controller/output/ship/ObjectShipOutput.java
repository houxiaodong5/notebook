package com.cetc54.zkb.ky.controller.output.ship;

import com.cetc54.zkb.ky.util.TimeUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

@ApiModel("船舶信息")
public class ObjectShipOutput {
    @ApiModelProperty("舰船id")
    private Integer id;
    @ApiModelProperty("名称")
    private String mc="";
    @ApiModelProperty("类型")
    private String lx="";
    @ApiModelProperty("级别")
    private String jb="";
    @ApiModelProperty("编号")
    private String bh="";
    @ApiModelProperty("服役日期")
    private String fysj="";
    @ApiModelProperty("所属部队")
    private String ssbd="";
    @ApiModelProperty("图片特征")
    private String tptz="";
    @ApiModelProperty("图片")
    private String tp="";
    @ApiModelProperty("简介")
    private String jj="";
    @ApiModelProperty("出厂时间")
    private String ccrq="";
    @ApiModelProperty("下水时间")
    private String xssj="";

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMc() {
        return this.mc;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getLx() {
        return this.lx;
    }

    public void setLx(String lx) {
        this.lx = lx;
    }

    public String getJb() {
        return this.jb;
    }

    public void setJb(String jb) {
        this.jb = jb;
    }

    public String getBh() {
        return this.bh;
    }

    public void setBh(String bh) {
        this.bh = bh;
    }

    public String getFysj() {
        return this.fysj;
    }

    public void setFysj(String  fysj) {
        this.fysj = TimeUtil.formatTime(fysj);
    }

    public String getSsbd() {
        return this.ssbd;
    }

    public void setSsbd(String ssbd) {
        this.ssbd = ssbd;
    }

    public String getTptz() {
        return this.tptz;
    }

    public void setTptz(String tptz) {
        this.tptz = tptz;
    }

    public String getTp() {
        return this.tp;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getJj() {
        return this.jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getCcrq() {
        return this.ccrq;
    }

    public void setCcrq(String ccrq) {
        this.ccrq = TimeUtil.formatTime(ccrq);
    }

    public String getXssj() {
        return this.xssj;
    }

    public void setXssj(String xssj) {
        this.xssj = TimeUtil.formatTime(xssj);
    }
}
