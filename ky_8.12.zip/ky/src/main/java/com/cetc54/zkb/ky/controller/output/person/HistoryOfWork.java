package com.cetc54.zkb.ky.controller.output.person;

import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectTroops;

import java.io.Serializable;
import java.util.List;

public class HistoryOfWork implements Serializable {
    private List<ObjectTroops> troopsList;
    private List<ObjectShipBasicInfoEntity> shipList;

    public List<ObjectTroops> getTroopsList() {
        return troopsList;
    }

    public void setTroopsList(List<ObjectTroops> troopsList) {
        this.troopsList = troopsList;
    }

    public List<ObjectShipBasicInfoEntity> getShipList() {
        return shipList;
    }

    public void setShipList(List<ObjectShipBasicInfoEntity> shipList) {
        this.shipList = shipList;
    }

    @Override
    public String toString() {
        return "HistoryOfWork{" +
                "troopsList=" + troopsList +
                ", shipList=" + shipList +
                '}';
    }
}
