package com.cetc54.zkb.ky.controller.output.ship;

import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;

import java.util.List;

public class ShipEvent extends ObjectEventOutput {
    private int shipID;
    private String shipName;
    private List<String> tags;

    public int getShipID() {
        return shipID;
    }

    public void setShipID(int shipID) {
        this.shipID = shipID;
    }

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    @Override
    public Integer getId() {
        return super.getId();
    }

    @Override
    public void setId(Integer id) {
        super.setId(id);
    }

    @Override
    public String getUuid() {
        return super.getUuid();
    }

    @Override
    public void setUuid(String uuid) {
        super.setUuid(uuid);
    }

    @Override
    public String getBt() {
        return super.getBt();
    }

    @Override
    public void setBt(String bt) {
        super.setBt(bt);
    }

    @Override
    public String getJj() {
        return super.getJj();
    }

    @Override
    public void setJj(String jj) {
        super.setJj(jj);
    }

    @Override
    public String getGjc() {
        return super.getGjc();
    }

    @Override
    public void setGjc(String gjc) {
        super.setGjc(gjc);
    }

    @Override
    public String getFssj() {
        return super.getFssj();
    }

    @Override
    public void setFssj(String fssj) {
        super.setFssj(fssj);
    }

    @Override
    public String getJssj() {
        return super.getJssj();
    }

    @Override
    public void setJssj(String jssj) {
        super.setJssj(jssj);
    }

    @Override
    public String getZbwd() {
        return super.getZbwd();
    }

    @Override
    public void setZbwd(String zbwd) {
        super.setZbwd(zbwd);
    }

    @Override
    public String getZbjd() {
        return super.getZbjd();
    }

    @Override
    public void setZbjd(String zbjd) {
        super.setZbjd(zbjd);
    }

    @Override
    public String getTag1() {
        return super.getTag1();
    }

    @Override
    public void setTag1(String tag1) {
        super.setTag1(tag1);
    }

    @Override
    public String getTag2() {
        return super.getTag2();
    }

    @Override
    public void setTag2(String tag2) {
        super.setTag2(tag2);
    }

    @Override
    public String getTag3() {
        return super.getTag3();
    }

    @Override
    public void setTag3(String tag3) {
        super.setTag3(tag3);
    }

    @Override
    public String getGjmc() {
        return super.getGjmc();
    }

    @Override
    public void setGjmc(String gjmc) {
        super.setGjmc(gjmc);
    }

    @Override
    public String getGjid() {
        return super.getGjid();
    }

    @Override
    public void setGjid(String gjid) {
        super.setGjid(gjid);
    }

    @Override
    public String getDd() {
        return super.getDd();
    }

    @Override
    public void setDd(String dd) {
        super.setDd(dd);
    }

    @Override
    public String getWxdj() {
        return super.getWxdj();
    }

    @Override
    public void setWxdj(String wxdj) {
        super.setWxdj(wxdj);
    }

    @Override
    public String getRksj() {
        return super.getRksj();
    }

    @Override
    public void setRksj(String rksj) {
        super.setRksj(rksj);
    }

    @Override
    public Integer getGdbUsed() {
        return super.getGdbUsed();
    }

    @Override
    public void setGdbUsed(Integer gdbUsed) {
        super.setGdbUsed(gdbUsed);
    }

    @Override
    public String toString() {
        return "ShipEvent{" +
                "shipID=" + shipID +
                ", shipName='" + shipName + '\'' +
                ", tags=" + tags +
                '}';
    }
}
