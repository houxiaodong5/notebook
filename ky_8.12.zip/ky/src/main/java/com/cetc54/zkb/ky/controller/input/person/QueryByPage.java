package com.cetc54.zkb.ky.controller.input.person;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
/**
 *      分页查询所有信息参数
 * */
public class QueryByPage implements Serializable {
    @ApiModelProperty(value = "每页展示数量")
    private int pageSize;
    @ApiModelProperty(value = "当前页码")
    private int pageNum;

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    @Override
    public String toString() {
        return "QueryByPage{" +
                "pageSize=" + pageSize +
                ", pageNum=" + pageNum +
                '}';
    }
}