package com.cetc54.zkb.ky.constraint;

/**
 * 说明:
 * <br>@author lhx
 * <br>@date 2018/10/10 18:41
 * <p>
 * <br>UpdateNote:
 * <br>UpdateTime:
 * <br>UpdateUser:
 */
public abstract class PageQuery {

    private Integer pageNum;
    private Integer pageSize;

    public PageQuery() {
    }

    public Integer getPageNum() {
        return this.pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return this.pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
