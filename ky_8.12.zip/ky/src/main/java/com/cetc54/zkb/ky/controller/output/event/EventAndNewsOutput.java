package com.cetc54.zkb.ky.controller.output.event;

import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutput;
import com.cetc54.zkb.ky.dao.entity.NewsEntitry;
import java.io.Serializable;

public class EventAndNewsOutput implements Serializable {
    private NewsEntitry newsEntitry;
    private EventAllMessageOutput eventOutput;
    private TwitterOutput twitterOutput;


    public NewsEntitry getNewsEntitry() {
        return newsEntitry;
    }

    public void setNewsEntitry(NewsEntitry newsEntitry) {
        this.newsEntitry = newsEntitry;
    }

    public EventAllMessageOutput getEventOutput() {
        return eventOutput;
    }

    public void setEventOutput(EventAllMessageOutput eventOutput) {
        this.eventOutput = eventOutput;
    }

    public TwitterOutput getTwitterOutput() {
        return twitterOutput;
    }

    public void setTwitterOutput(TwitterOutput twitterOutput) {
        this.twitterOutput = twitterOutput;
    }


    @Override
    public String toString() {
        return "EventAndNewsOutput{" +
                "newsEntitry=" + newsEntitry +
                ", eventOutput=" + eventOutput +
                ", twitterOutput=" + twitterOutput +
                '}';
    }
}
