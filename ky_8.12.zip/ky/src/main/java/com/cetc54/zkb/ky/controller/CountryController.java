package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.output.country.ObjectCountryOutput;
import com.cetc54.zkb.ky.service.CountryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@Api("国家controller")
@RestController
public class CountryController extends BaseController {

    @Resource
    private CountryService countryService;

    @ApiOperation("查询所有国家")
    @ApiImplicitParam(name = "country", value = "国家")
    @GetMapping({"/country/all/query"})
    public DataResponse<List<ObjectCountryOutput>> queryAllCountry(String country) {
        return this.success(this.countryService.queryAllCountry(country));
    }
}
