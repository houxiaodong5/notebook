package com.cetc54.zkb.ky.controller.input.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
@ApiModel("通过舰船或人物id和时间点查询事件model")
public class EventQueryByIDAndTime implements Serializable {
    @ApiModelProperty("时间点")
    private String time;
    @ApiModelProperty("id")
    private int id;
    @ApiModelProperty(value = "人物或舰船标识")
    private String type;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "EventQueryByIDAndTime{" +
                "time='" + time + '\'' +
                ", id=" + id +
                ", type='" + type + '\'' +
                '}';
    }
}
