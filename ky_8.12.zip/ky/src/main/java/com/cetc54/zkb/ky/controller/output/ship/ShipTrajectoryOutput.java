package com.cetc54.zkb.ky.controller.output.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel("船舶轨迹输出类")
public class ShipTrajectoryOutput {
    @ApiModelProperty("舰船ID")
    private Integer jcid;
    @ApiModelProperty("舰船名称")
    private String jcName;
    @ApiModelProperty("轨迹")
    private List<Trajectory> trajectory;

    public List<Trajectory> getTrajectory() {
        return this.trajectory;
    }

    public void setTrajectory(List<Trajectory> trajectory) {
        this.trajectory = trajectory;
    }

    public String getJcName() {
        return jcName;
    }

    public void setJcName(String jcName) {
        this.jcName = jcName;
    }

    public Integer getJcid() {
        return this.jcid;
    }

    public void setJcid(Integer jcid) {
        this.jcid = jcid;
    }
}