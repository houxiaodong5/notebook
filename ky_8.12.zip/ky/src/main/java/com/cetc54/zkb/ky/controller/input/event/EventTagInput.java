package com.cetc54.zkb.ky.controller.input.event;

import java.util.List;

public class EventTagInput {
    private List<String> tags;
    private int id;

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "EventTagInput{" +
                "tags=" + tags +
                ", id=" + id +
                '}';
    }
}
