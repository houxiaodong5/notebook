package com.cetc54.zkb.ky.controller.output.statistics;

import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;

import java.io.Serializable;
import java.util.List;

/**
 *      舰船及对应事件
 * */
public class ShipAndEvents implements Serializable {
    private ObjectShipBasicInfoEntity ship;
    private List<ObjectEventOutput> events;

    public ObjectShipBasicInfoEntity getShip() {
        return ship;
    }

    public void setShip(ObjectShipBasicInfoEntity ship) {
        this.ship = ship;
    }

    public List<ObjectEventOutput> getEvents() {
        return events;
    }

    public void setEvents(List<ObjectEventOutput> events) {
        this.events = events;
    }

    @Override
    public String toString() {
        return "ShipAndEvents{" +
                "ship=" + ship +
                ", events=" + events +
                '}';
    }
}
