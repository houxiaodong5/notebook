package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;

/**
 *      嘉奖情况
 * */
public class ObjectHonor implements Serializable {

    private int id;
    private String lgsjnm;
    private String mc;
    private String ywmc;
    private String jj;
    private String hdsj;
    private String hddd;
    private String lx;
    private int gdb_used;
    private String jlsj;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLgsjnm() {
        return lgsjnm;
    }

    public void setLgsjnm(String lgsjnm) {
        this.lgsjnm = lgsjnm;
    }

    public String getMc() {
        return mc;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getHdsj() {
        return hdsj;
    }

    public void setHdsj(String hdsj) {
        this.hdsj = hdsj;
    }

    public String getHddd() {
        return hddd;
    }

    public void setHddd(String hddd) {
        this.hddd = hddd;
    }

    public String getLx() {
        return lx;
    }

    public void setLx(String lx) {
        this.lx = lx;
    }

    public int getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(int gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getJlsj() {
        return jlsj;
    }

    public void setJlsj(String jlsj) {
        this.jlsj = TimeUtil.formateStringTime(jlsj);
    }

    @Override
    public String toString() {
        return "ObjectHonor{" +
                "id=" + id +
                ", lgsjnm='" + lgsjnm + '\'' +
                ", mc='" + mc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", jj='" + jj + '\'' +
                ", hdsj='" + hdsj + '\'' +
                ", hddd='" + hddd + '\'' +
                ", lx='" + lx + '\'' +
                ", gdb_used=" + gdb_used +
                ", jlsj='" + jlsj + '\'' +
                '}';
    }
}
