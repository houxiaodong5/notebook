package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;

/**
 *      tb_news_new
 * */
public class NewsEntity  implements Serializable {
    public static final String prefix_URL="https://shujucaiji.oss-cn-beijing.aliyuncs.com";
    private int nmID;
    private String vcUUID;
    private String vcCrawlDate;  //*
    private String vcOrigin;
    private String vcDomain;
    private String vcPageUrl;
    private String vcLanguage;
    private String vcWebType;
    private String vcTitle;
    private String vcPublishDate;  //*
    private String clContent;
    private String vcFileUrl;
    private String vcChannel;
    private String vcNewsType;
    private String vcKeywords;
    private String vcTags;
    private String vcTitleCn;
    private String vcContentCn;

    public int getNmID() {
        return nmID;
    }

    public void setNmID(int nmID) {
        this.nmID = nmID;
    }

    public String getVcUUID() {
        return vcUUID;
    }

    public void setVcUUID(String vcUUID) {
        this.vcUUID = vcUUID;
    }

    public String getVcCrawlDate() {
        return vcCrawlDate;
    }

    public void setVcCrawlDate(String vcCrawlDate) {
        this.vcCrawlDate = TimeUtil.formateStringTime(vcCrawlDate);
    }

    public String getVcOrigin() {
        return vcOrigin;
    }

    public void setVcOrigin(String vcOrigin) {
        this.vcOrigin = vcOrigin;
    }

    public String getVcDomain() {
        return vcDomain;
    }

    public void setVcDomain(String vcDomain) {
        this.vcDomain = vcDomain;
    }

    public String getVcPageUrl() {
        return vcPageUrl;
    }

    public void setVcPageUrl(String vcPageUrl) {
        this.vcPageUrl = vcPageUrl;
    }

    public String getVcLanguage() {
        return vcLanguage;
    }

    public void setVcLanguage(String vcLanguage) {
        this.vcLanguage = vcLanguage;
    }

    public String getVcWebType() {
        return vcWebType;
    }

    public void setVcWebType(String vcWebType) {
        this.vcWebType = vcWebType;
    }

    public String getVcTitle() {
        return vcTitle;
    }

    public void setVcTitle(String vcTitle) {
        this.vcTitle = vcTitle;
    }

    public String getVcPublishDate() {
        return vcPublishDate;
    }

    public void setVcPublishDate(String vcPublishDate) {
        this.vcPublishDate = TimeUtil.formateStringTime(vcPublishDate);
    }

    public String getClContent() {
        return clContent;
    }

    public void setClContent(String clContent) {
        this.clContent = clContent;
    }

    public String getVcFileUrl() {
        return vcFileUrl;
    }

    public void setVcFileUrl(String vcFileUrl) {

        this.vcFileUrl =vcFileUrl;
    }

    public String getVcChannel() {
        return vcChannel;
    }

    public void setVcChannel(String vcChannel) {
        this.vcChannel = vcChannel;
    }

    public String getVcNewsType() {
        return vcNewsType;
    }

    public void setVcNewsType(String vcNewsType) {
        this.vcNewsType = vcNewsType;
    }

    public String getVcKeywords() {
        return vcKeywords;
    }

    public void setVcKeywords(String vcKeywords) {
        this.vcKeywords = vcKeywords;
    }

    public String getVcTags() {
        return vcTags;
    }

    public void setVcTags(String vcTags) {
        this.vcTags = vcTags;
    }

    public String getVcTitleCn() {
        return vcTitleCn;
    }

    public void setVcTitleCn(String vcTitleCn) {
        this.vcTitleCn = vcTitleCn;
    }

    public String getVcContentCn() {
        return vcContentCn;
    }

    public void setVcContentCn(String vcContentCn) {
        this.vcContentCn = vcContentCn;
    }

    public static NewsEntity stardandNews(NewsEntity newsEntity){
        if(StringUtils.isNotBlank(newsEntity.getVcFileUrl())){
            newsEntity.setVcFileUrl(prefix_URL+newsEntity.getVcFileUrl());
        }
        return newsEntity;
    }

    @Override
    public String toString() {
        return "NewsEntity{" +
                "nmID=" + nmID +
                ", vcUUID='" + vcUUID + '\'' +
                ", vcCrawlDate='" + vcCrawlDate + '\'' +
                ", vcOrigin='" + vcOrigin + '\'' +
                ", vcDomain='" + vcDomain + '\'' +
                ", vcPageUrl='" + vcPageUrl + '\'' +
                ", vcLanguage='" + vcLanguage + '\'' +
                ", vcWebType='" + vcWebType + '\'' +
                ", vcTitle='" + vcTitle + '\'' +
                ", vcPublishDate='" + vcPublishDate + '\'' +
                ", clContent='" + clContent + '\'' +
                ", vcFileUrl='" + vcFileUrl + '\'' +
                ", vcChannel='" + vcChannel + '\'' +
                ", vcNewsType='" + vcNewsType + '\'' +
                ", vcKeywords='" + vcKeywords + '\'' +
                ", vcTags='" + vcTags + '\'' +
                ", vcTitleCn='" + vcTitleCn + '\'' +
                ", vcContentCn='" + vcContentCn + '\'' +
                '}';
    }
}
