package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.controller.output.country.ObjectCountryOutput;

import java.util.List;

/**
* 国家service
* */
public interface CountryService {

    /**
     * 查询所有国家，可根据条件模糊查询
    * */
    List<ObjectCountryOutput> queryAllCountry(String country);
}
