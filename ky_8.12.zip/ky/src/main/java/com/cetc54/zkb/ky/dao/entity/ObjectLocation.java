package com.cetc54.zkb.ky.dao.entity;

import java.io.Serializable;

/**
 * Created by Administrator on 2019/5/25/025.
 */
public class ObjectLocation implements Serializable {

    private Integer ddid=0;
    private String ddywm="";
    private String ddzwm="";
    private String zxdzb="";
    private String ssy="";
    private String zxdjd="";
    private String zxdwd="";
    private String city="";
    private String city_cn="";
    private String prov="";
    private String cnty="";
    private String cnty_cn="";
    private String ddlx="";
    private Integer gdb_used=0;

    public Integer getDdid() {
        return ddid;
    }

    public void setDdid(Integer ddid) {
        this.ddid = ddid;
    }

    public String getDdywm() {
        return ddywm;
    }

    public void setDdywm(String ddywm) {
        this.ddywm = ddywm;
    }

    public String getDdzwm() {
        return ddzwm;
    }

    public void setDdzwm(String ddzwm) {
        this.ddzwm = ddzwm;
    }

    public String getZxdzb() {
        return zxdzb;
    }

    public void setZxdzb(String zxdzb) {
        this.zxdzb = zxdzb;
    }

    public String getSsy() {
        return ssy;
    }

    public void setSsy(String ssy) {
        this.ssy = ssy;
    }

    public String getZxdjd() {
        return zxdjd;
    }

    public void setZxdjd(String zxdjd) {
        this.zxdjd = zxdjd;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity_cn() {
        return city_cn;
    }

    public void setCity_cn(String city_cn) {
        this.city_cn = city_cn;
    }

    public String getProv() {
        return prov;
    }

    public void setProv(String prov) {
        this.prov = prov;
    }

    public String getCnty() {
        return cnty;
    }

    public void setCnty(String cnty) {
        this.cnty = cnty;
    }

    public String getCnty_cn() {
        return cnty_cn;
    }

    public void setCnty_cn(String cnty_cn) {
        this.cnty_cn = cnty_cn;
    }

    public String getDdlx() {
        return ddlx;
    }

    public void setDdlx(String ddlx) {
        this.ddlx = ddlx;
    }

    public Integer getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(Integer gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getZxdwd() {
        return zxdwd;
    }

    public void setZxdwd(String zxdwd) {
        this.zxdwd = zxdwd;
    }

    @Override
    public String toString() {
        return "ObjectLocation{" +
                "ddid=" + ddid +
                ", ddywm='" + ddywm + '\'' +
                ", ddzwm='" + ddzwm + '\'' +
                ", zxdzb='" + zxdzb + '\'' +
                ", ssy='" + ssy + '\'' +
                ", zxdjd='" + zxdjd + '\'' +
                ", zxdwd='" + zxdwd + '\'' +
                ", city='" + city + '\'' +
                ", city_cn='" + city_cn + '\'' +
                ", prov='" + prov + '\'' +
                ", cnty='" + cnty + '\'' +
                ", cnty_cn='" + cnty_cn + '\'' +
                ", ddlx='" + ddlx + '\'' +
                ", gdb_used=" + gdb_used +
                '}';
    }
}
