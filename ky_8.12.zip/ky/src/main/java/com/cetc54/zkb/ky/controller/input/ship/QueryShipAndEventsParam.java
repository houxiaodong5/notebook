package com.cetc54.zkb.ky.controller.input.ship;

import java.io.Serializable;

/**
 *      通过时间查询舰船及对应事件查询参数
 * */

public class QueryShipAndEventsParam implements Serializable {
    private String timeType;
    private String state;//在港、离港
    private String time;

    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "QueryShipAndEventsParam{" +
                "timeType='" + timeType + '\'' +
                ", state='" + state + '\'' +
                ", time='" + time + '\'' +
                '}';
    }
}
