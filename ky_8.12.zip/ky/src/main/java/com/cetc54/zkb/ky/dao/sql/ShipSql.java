package com.cetc54.zkb.ky.dao.sql;

import com.cetc54.zkb.ky.service.model.StatisticShipModel;
import org.apache.commons.lang.StringUtils;

import javax.management.openmbean.InvalidOpenTypeException;

public class ShipSql {

    /**
     * 查询所有基地
     * */
    public String baseAllQuery() {
        return "SELECT * FROM object_base_basic_info";
    }

    /**
     *根据条件查询基地在港情况舰船
     * */
    public String shipQueryByTimeAndZgzt(StatisticShipModel model) {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT jc.gkid,count(*) as number FROM jczgqk jc WHERE jc.gkid in (SELECT jdid FROM object_base_basic_info) ");
        if (StringUtils.isNotBlank(model.getTime())) {
            sql.append("date_format(ztsj,'%Y-%m-%d')=date_format(#{time},'%Y-%m-%d') ");
        }

        if (model.getZgzt() != null && "".equals(model.getZgzt())) {
            sql.append("and jc.zgzt = #{zgzt} ");
        }

        sql.append("GROUP BY jc.gkid");
        return sql.toString();
    }

    /**
     * 通过时间、港口ID及基地ID统计舰船
     * */
    public String statisticShipByTimeAndZgqk(StatisticShipModel model) {
        StringBuffer sql = new StringBuffer();
        sql.append("select count(*) FROM jczgqk where 1=1 ");
        if (StringUtils.isNotBlank(model.getTime())) {
            sql.append("and DATE_FORMAT(ztsj, '" + model.getFormat() + "') = #{time} ");
        }

        if (model.getZgzt() != null && !"".equals(model.getZgzt())) {
            sql.append("and zgzt = #{zgzt} ");
        }

        if (StringUtils.isNotBlank(model.getJdid())) {
            sql.append("and gkid = #{jdid} ");
        }

        return sql.toString();
    }

    /**
     * 根据港口、在港状态查询船舶详情
     * */
    public String queryShipByBase() {
        return "SELECT * FROM object_ship_basic_info os LEFT JOIN jczgqk jc on os.id = jc.jcid WHERE jc.gkid = #{jdid} and  jc.zgzt = #{zgzt} GROUP BY mc";
    }

    /**
     * 统计今日舰船在港、进港、离港总数
     * */

    public String shipTodayStatistic() {
        return "SELECT (select count(*) from jczgqk where to_days(ztsj) = to_days(now()) and zgzt = '1') as zgNum,(select count(*) from jczgqk where to_days(ztsj) = to_days(now()) and zgzt = '3') as jgNum,(select count(*) from jczgqk where to_days(ztsj) = to_days(now()) and zgzt = '4') as lgNum";
    }

    /**
     * 通过时间查询所有舰船ID
     * */
    public String queryShipByTime() {
        return "SELECT os.* from jczgqk jc left join object_ship_basic_info os on jc.jcid = os.id WHERE zgzt != 2 and date_format(ztsj,'%Y-%m-%d') <= date_format(curdate(),'%Y-%m-%d') and date_format(ztsj,'%Y-%m-%d') >= #{time}  group by jcid  ";
    }

    /**
     * 通过时间及舰船ID查询舰船轨迹
     * */
    public String queryShipTrajectoryByTime() {
        return "SELECT zxdjd,zxdwd,jc.zgzt,date_format(ztsj,'%Y-%m-%d') ztsj  FROM jczgqk jc LEFT JOIN object_base_basic_info ob on jc.gkid = ob.jdid " +
                "WHERE jcid = #{jcid} and date_format(ztsj,'%Y-%m-%d') <= date_format(curdate(),'%Y-%m-%d') and date_format(ztsj,'%Y-%m-%d') >= #{time} and zgzt != 2 GROUP BY zgzt,gkid";
    }

    /**
     * 查询舰船涉及年份
     * */
    public String queryShiptYear() {
        return "SELECT DATE_FORMAT(ztsj,'%Y') as eventYear FROM jczgqk GROUP BY DATE_FORMAT(ztsj,'%Y') ";
    }

    //根据id查询船舶信息
    public static String queryShipByID(Integer shipID){
        return "SELECT * FROM `object_ship_basic_info` WHERE id="+shipID;
    }

    public static String queryShipsWhereHaveEvents(){
        return "SELECT DISTINCT ship_id shipID,ship_name shipName FROM relation_ship_event WHERE event_id IS NOT NULL AND event_id !=0 AND ship_id IS NOT NULL AND ship_id !=0 ORDER BY ship_id";
    }

    public static String queryAllEventsOfShips(){
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("SELECT ship_id shipID,ship_name shipName,t2.* FROM `relation_ship_event` t1 ");
        stringBuffer.append(" LEFT JOIN object_event t2 ON t1.`event_id` =t2.`uuid` ");
        stringBuffer.append(" WHERE    t2.tag1 IS NOT NULL AND t2.zbwd IS NOT NULL  AND t1.ship_id IS NOT NULL AND t1.ship_id !=0 ");
        stringBuffer.append(" ORDER BY t1.ship_id");
        return stringBuffer.toString();
    }

    public static String queryAllEventsOfShips_NEW(){
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("SELECT ship_id shipID,ship_name shipName,t2.id,t2.uuid,t2.bt,t2.gjc,t2.fssj,t2.jssj,t2.zbjd,t2.zbwd,t2.tag1,t2.gjmc,t2.gjid,t2.dd,t2.wxdj,t2.rksj FROM `relation_ship_event` t1 ");
        stringBuffer.append(" LEFT JOIN object_event t2 ON t1.`event_id` =t2.`uuid` ");
        stringBuffer.append(" WHERE    t2.tag1 IS NOT NULL AND t2.zbwd IS NOT NULL  AND t1.ship_id IS NOT NULL AND t1.ship_id !=0 ");
        stringBuffer.append(" ORDER BY t1.ship_id");
        return stringBuffer.toString();
    }

    public static String queryShipsByIDs(String sql){
        return sql;
    }

    public static String queryShipByIDForOther(Integer shipId){
        return "SELECT * from object_ship_basic_info where id="+shipId;
    }

}
