package com.cetc54.zkb.ky.controller.output.statistics;

public class StatisticsEventOutputGroupByType extends StatisticsEventOutput {
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "StatisticsEventOutputGroupByType{" +
                "type='" + type + '\'' +
                '}';
    }
}
