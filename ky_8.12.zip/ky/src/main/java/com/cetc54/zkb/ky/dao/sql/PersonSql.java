package com.cetc54.zkb.ky.dao.sql;

import com.cetc54.zkb.ky.controller.input.person.QueryPersonByConditionsInput;
import com.cetc54.zkb.ky.controller.output.person.PersonOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;


public class PersonSql {

    public static String queryConditionsOfFilter(){
        return "SELECT distinct jx,jx_cn zwjx,zw,zw_cn zwzw, rylb,gj,gj_cn zwgjm from `object_person` ";
    }

    public static String queryPersonByConditions(QueryPersonByConditionsInput input){

        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT *  FROM `object_person` WHERE 1=1 ");
        if(StringUtils.isNotBlank(input.getCountry())){
            buffer.append("and gj=#{country} ");
        }
        if(StringUtils.isNotBlank(input.getCountry_CN())){
            buffer.append("and gj_cn=#{country_CN} ");
        }
        if(StringUtils.isNotBlank(input.getMilitaryRank())){
            buffer.append("and jx=#{militaryRank} ");
        }
        if(StringUtils.isNotBlank(input.getMilitaryRank_CN())){
            buffer.append("and jx_cn=#{militaryRank_CN} ");
        }if(StringUtils.isNotBlank(input.getPost())){
            buffer.append("and zw=#{post} ");
        }
        if(StringUtils.isNotBlank(input.getPost_CN())){
            buffer.append("and zw_cn=#{post_CN} ");
        }
        if(StringUtils.isNotBlank(input.getCategory())){
            buffer.append("and rylb=#{category} ");
        }

        return buffer.toString();
    }

    public static String querySchoolByUserID(@Param("userID") int userID){
        StringBuffer buffer = new StringBuffer();
        /*buffer.append("SELECT * from `object_school` where `id` in ( ");
        buffer.append("SELECT DISTINCT  school_id FROM `relation_person_school` WHERE `person_id` ="+userID+" )");*/
        buffer.append("SELECT t1.*,t2.`kssj` jlsj  from object_school t1 ");
        buffer.append("LEFT JOIN relation_person_school t2 on t1.id=t2.`school_id` and t2.`person_id` ="+userID);
        buffer.append("  where t1.`id` in (  ");
        buffer.append(" SELECT DISTINCT  school_id  FROM `relation_person_school` WHERE `person_id` ="+userID+" )");
        return buffer.toString();
    }

    public static String queryActivitiesOfMilitaryByUserID(@Param("userID") int userID){
        StringBuffer buffer = new StringBuffer();
        /*buffer.append("SELECT * from `object_military_activity` where `id` in ( ");
        buffer.append("SELECT DISTINCT  military_activity_id FROM `relation_person_ma` WHERE `person_id` ="+userID+" )");*/

        buffer.append("SELECT t1.*,t2.`kssj` jlsj  from object_military_activity t1 ");
        buffer.append("LEFT JOIN relation_person_ma t2 on t1.id=t2.`military_activity_id`  and t2.`person_id` ="+userID);
        buffer.append(" where t1.`id` in ( ");
        buffer.append("SELECT DISTINCT  military_activity_id  FROM `relation_person_ma` WHERE `person_id` ="+userID+")");
        return buffer.toString();
    }

    public static String queryHonorByUserID(@Param("userID") int userID){
        StringBuffer buffer = new StringBuffer();
        /*buffer.append("SELECT * from `object_honor` where `id` in ( ");
        buffer.append("SELECT DISTINCT  honor_id FROM `relation_person_honor` WHERE `person_id` ="+userID+" )");*/

        buffer.append("SELECT t1.*,t2.`kssj` jlsj  from object_honor t1 ");
        buffer.append("LEFT JOIN relation_person_honor t2 on t1.id=t2.`honor_id`  and t2.`person_id` ="+userID);
        buffer.append(" where t1.`id` in (  ");
        buffer.append(" SELECT DISTINCT  honor_id  FROM `relation_person_honor` WHERE `person_id` ="+userID+") ");
        return buffer.toString();
    }

    public static String queryHistoryOfTroopsByUserID(@Param("userID") int userID){
        StringBuffer buffer = new StringBuffer();
        /*buffer.append("SELECT * from `object_troops` where `id` in ( ");
        buffer.append("SELECT DISTINCT  troops_id FROM `relation_person_troops` WHERE `person_id` ="+userID+" )");*/

        buffer.append("SELECT t1.*,t2.`kssj` jlsj  from object_troops t1 ");
        buffer.append("LEFT JOIN relation_person_troops t2 on t1.id=t2.`troops_id`  and t2.`person_id` ="+userID);
        buffer.append(" where t1.`id` in (  ");
        buffer.append(" SELECT DISTINCT  troops_id  FROM `relation_person_troops` WHERE `person_id` ="+userID+") ");
        return buffer.toString();
    }

    public static String queryHistoryOfShipByUserID(@Param("userID") int userID){
        StringBuffer buffer = new StringBuffer();
        /*buffer.append("SELECT * from `object_ship` where `id` in ( ");
        buffer.append("SELECT DISTINCT  ship_id FROM `relation_person_ship` WHERE `person_id` ="+userID+" )");*/

        buffer.append("SELECT t1.*,t2.`kssj` jlsj  from object_ship_basic_info t1 ");
        buffer.append("LEFT JOIN relation_person_ship t2 on t1.id=t2.`ship_id`  and t2.`person_id` ="+userID);
        buffer.append(" where t1.`id` in (  ");
        buffer.append(" SELECT DISTINCT  ship_id  FROM `relation_person_ship` WHERE `person_id` ="+userID+") ");
        return buffer.toString();
    }

    public static String queryAllPerson(){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT  DISTINCT  zwxm,ywxm ");
        buffer.append(" from `object_person` order by zwxm");
        return buffer.toString();
    }

    public static String queryAllPersonSimpleMsg(){
        return "select renwuid,zwxm,ywxm from  `object_person` order by zwxm";
    }

    public static String updatePersonMessage( PersonOutput person){
        SQL sql = new SQL() {
            {
                UPDATE("object_person");
                if(StringUtils.isNotBlank(person.getZwxm())){
                    SET("zwxm=#{zwxm}");
                }
                if(StringUtils.isNotBlank(person.getYwxm())){
                    SET("ywxm=#{ywxm}");
                }
                if(StringUtils.isNotBlank(person.getFirstName())){
                    SET("first_name=#{firstName}");
                }
                if(StringUtils.isNotBlank(person.getLastName())){
                    SET("last_name=#{lastName}");
                }
                if(StringUtils.isNotBlank(person.getTwoWordName())){
                    SET("two_word_name=#{twoWordName}");
                }
                if(StringUtils.isNotBlank(person.getJx())){
                    SET("jx=#{jx}");
                }
                if(StringUtils.isNotBlank(person.getJxCn())){
                    SET("jx_cn=#{jxCn}");
                }
                if(StringUtils.isNotBlank(person.getZwCn())){
                    SET("zw_cn=#{zwCn}");
                }
                if(StringUtils.isNotBlank(person.getZw())){
                    SET("zw=#{zw}");
                }
                if(StringUtils.isNotBlank(person.getRzsj())){
                    SET("rzsj=#{rzsj}");
                }
                if(StringUtils.isNotBlank(person.getCsd())){
                    SET("csd=#{csd}");
                }
                if(StringUtils.isNotBlank(person.getZylb())){
                    SET("zylb=#{zylb}");
                }
                if(StringUtils.isNotBlank(person.getTxszwj())){
                    SET("txszwj=#{txszwj}");
                }
                if(StringUtils.isNotBlank(person.getSsjg())){
                    SET("ssjg=#{ssjg}");
                }
                if(StringUtils.isNotBlank(person.getSsjgid())){
                    SET("ssjgid=#{ssjgid}");
                }
                if(StringUtils.isNotBlank(person.getSjzh())){
                    SET("sjzh=#{sjzh}");
                }
                if(StringUtils.isNotBlank(person.getRylb())){
                    SET("rylb=#{rylb}");
                }
                if(StringUtils.isNotBlank(person.getZjxy())){
                    SET("zjxy=#{zjxy}");
                }
                if(StringUtils.isNotBlank(person.getRwmbtz())){
                    SET("rwmbtz=#{rwmbtz}");
                }
                if(StringUtils.isNotBlank(person.getGj())){
                    SET("gj=#{gj}");
                }
                if(StringUtils.isNotBlank(person.getGjCn())){
                    SET("gj_cn=#{gjCn}");
                }
                if(StringUtils.isNotBlank(person.getGz())){
                    SET("gz=#{gz}");
                }
                if(StringUtils.isNotBlank(person.getJj())){
                    SET("jj=#{jj}");
                }
                if(StringUtils.isNotBlank(person.getJy())){
                    SET("jy=#{jy}");
                }
                if(StringUtils.isNotBlank(person.getFxjl())){
                    SET("fxjl=#{fxjl}");
                }
                if(StringUtils.isNotBlank(person.getJiangxiang())){
                    SET("jiangxiang=#{jiangxiang}");
                }
                if(StringUtils.isNotBlank(person.getCj())){
                    SET("cj=#{cj}");
                }
                if(StringUtils.isNotBlank(person.getLj())){
                    SET("lj=#{lj}");
                }
                if(StringUtils.isNotBlank(person.getYxrq())){
                    SET("yxrq=#{yxrq}");
                }
                if(StringUtils.isNotBlank(person.getRksj())){
                    SET("rksj=#{rksj}");
                }
                if(StringUtils.isNotBlank(person.getShgx())){
                    SET("shgx=#{shgx}");
                }

                WHERE("renwuid=#{renwuid}");
            }
        };

        return sql.toString();

    }

}
