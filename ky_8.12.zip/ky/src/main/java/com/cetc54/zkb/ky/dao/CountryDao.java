package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.output.country.ObjectCountryOutput;
import com.cetc54.zkb.ky.dao.sql.CountrySql;
import org.apache.ibatis.annotations.SelectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

/**
 * 国家
 * */
public interface CountryDao {
    @SelectProvider(type = CountrySql.class,method = "queryAllCountry")
    List<ObjectCountryOutput> queryAllCountry(String country);

}
