package com.cetc54.zkb.ky.service.impl;

import com.alibaba.fastjson.JSON;
import com.cetc54.zkb.ky.controller.input.event.EventQueryByIDAndTime;
import com.cetc54.zkb.ky.controller.input.event.ExtraMessageQueryInput;
import com.cetc54.zkb.ky.controller.input.ship.QueryShipAndEventsParam;
import com.cetc54.zkb.ky.controller.output.event.*;
import com.cetc54.zkb.ky.controller.output.ship.StatisticsOfShipState;
import com.cetc54.zkb.ky.controller.output.source.OutputSource;
import com.cetc54.zkb.ky.controller.output.statistics.*;
import com.cetc54.zkb.ky.dao.StatisticsDao;
import com.cetc54.zkb.ky.dao.entity.ObjectBaseBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;
import com.cetc54.zkb.ky.enums.BaseEnum;
import com.cetc54.zkb.ky.enums.TimeTypeEnum;
import com.cetc54.zkb.ky.service.EventService;
import com.cetc54.zkb.ky.service.NewsService;
import com.cetc54.zkb.ky.service.StatisticsService;
import com.cetc54.zkb.ky.service.model.QueryModel;
import com.cetc54.zkb.ky.service.model.SliceOfTime;
import com.cetc54.zkb.ky.service.model.StatisticOfWestPacificBaseEventModel;
import com.cetc54.zkb.ky.util.TimeUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service
public class StatisticsImpl implements StatisticsService {
    @Autowired
    private StatisticsDao statisticsDao;
    @Autowired
    private EventService eventService;
    @Autowired
    private NewsService newsService;
    private static Logger logg = LoggerFactory.getLogger(StatisticsImpl.class);
    private Map<String, List<String>> extra_event_map = new HashMap<>();

    @Resource
    @Qualifier("primaryJdbcTemplate")
    private JdbcTemplate primaryJdbcTemplate;
    @Resource
    @Qualifier("secondaryJdbcTemplate")
    private JdbcTemplate secJdbctemplate;

    @Override
    public List<OutputOfStatistics> queryHottestPerson() {
        List<OutputOfStatistics> respData = new ArrayList<>(3);
        OutputOfStatistics outputdata = new OutputOfStatistics();
        List<String> nameList = new ArrayList<>(10);
        List<Long> numList = new ArrayList<>(10);
        List<Long> idsList = new ArrayList<>(10);
        //查询1个月内人名统计
        List<StatisticsMode> monthDBData = statisticsDao.queryHottestPersonOneMonth();
        for (StatisticsMode data : monthDBData) {
            nameList.add(data.getName());
            numList.add(data.getNum());
            idsList.add(data.getId());
        }
        outputdata.setName(nameList);
        outputdata.setNums(numList);
        outputdata.setIds(idsList);
        outputdata.setType(TimeTypeEnum.Month.name());
        respData.add(outputdata);


        //查询一周内人名统计
        List<String> nameList2 = new ArrayList<>(10);
        List<Long> numList2 = new ArrayList<>(10);
        List<Long> idsList2 = new ArrayList<>(10);
        OutputOfStatistics ouptutdataOfWeek = new OutputOfStatistics();
        List<StatisticsMode> weekDBData = statisticsDao.queryHottestPersonOneWeek();
        for (StatisticsMode data : weekDBData) {
            nameList2.add(data.getName());
            numList2.add(data.getNum());
            idsList2.add(data.getId());
        }
        ouptutdataOfWeek.setName(nameList2);
        ouptutdataOfWeek.setNums(numList2);
        ouptutdataOfWeek.setIds(idsList2);
        ouptutdataOfWeek.setType(TimeTypeEnum.Week.name());
        respData.add(ouptutdataOfWeek);


        //查询三天那日人名统计
        List<String> nameList3 = new ArrayList<>(10);
        List<Long> numList3 = new ArrayList<>(10);
        List<Long> idsList3 = new ArrayList<>(10);
        OutputOfStatistics ouptutdataOfDay = new OutputOfStatistics();
        List<StatisticsMode> threeDayDBData = statisticsDao.queryHottestPersonThreeDay();
        for (StatisticsMode data : threeDayDBData) {
            nameList3.add(data.getName());
            numList3.add(data.getNum());
            idsList3.add(data.getId());
        }
        ouptutdataOfDay.setName(nameList3);
        ouptutdataOfDay.setNums(numList3);
        ouptutdataOfDay.setIds(idsList3);
        ouptutdataOfDay.setType(TimeTypeEnum.Day.name());
        respData.add(ouptutdataOfDay);

        Collections.reverse(respData);
        return respData;
    }

    @Override
    public List<OutputOfStatistics> queryHottestShip() {
        List<OutputOfStatistics> respData = new ArrayList<>(3);
        OutputOfStatistics outputdata = new OutputOfStatistics();
        List<String> nameList = new ArrayList<>(10);
        List<Long> numList = new ArrayList<>(10);
        List<Long> idList = new ArrayList<>(10);
        //查询1个月内舰船统计
        List<StatisticsMode> monthDBData = statisticsDao.queryHottestShipOneMonth();
        for (StatisticsMode data : monthDBData) {
            nameList.add(data.getName());
            numList.add(data.getNum());
            idList.add(data.getId());
        }
        outputdata.setName(nameList);
        outputdata.setNums(numList);
        outputdata.setIds(idList);
        outputdata.setType(TimeTypeEnum.Month.name());
        respData.add(outputdata);


        //查询一周内舰船统计
        List<String> nameList2 = new ArrayList<>(10);
        List<Long> numList2 = new ArrayList<>(10);
        List<Long> idList2 = new ArrayList<>(10);
        OutputOfStatistics ouptutdataOfWeek = new OutputOfStatistics();
        List<StatisticsMode> weekDBData = statisticsDao.queryHottestShipOneWeek();
        for (StatisticsMode data : weekDBData) {
            nameList2.add(data.getName());
            numList2.add(data.getNum());
            idList2.add(data.getId());
        }
        ouptutdataOfWeek.setName(nameList2);
        ouptutdataOfWeek.setNums(numList2);
        ouptutdataOfWeek.setIds(idList2);
        ouptutdataOfWeek.setType(TimeTypeEnum.Week.name());
        respData.add(ouptutdataOfWeek);


        //查询三天那日舰船统计
        List<String> nameList3 = new ArrayList<>(10);
        List<Long> numList3 = new ArrayList<>(10);
        List<Long> idList3 = new ArrayList<>(10);
        OutputOfStatistics ouptutdataOfDay = new OutputOfStatistics();
        List<StatisticsMode> threeDayDBData = statisticsDao.queryHottestShipThreeDay();
        for (StatisticsMode data : threeDayDBData) {
            nameList3.add(data.getName());
            numList3.add(data.getNum());
            idList3.add(data.getId());
        }
        ouptutdataOfDay.setName(nameList3);
        ouptutdataOfDay.setNums(numList3);
        ouptutdataOfDay.setIds(idList3);
        ouptutdataOfDay.setType(TimeTypeEnum.Day.name());
        respData.add(ouptutdataOfDay);

        Collections.reverse(respData);
        return respData;
    }

    @Override
    public List<OutputOfStatistics> queryHottestBase() {
        List<OutputOfStatistics> respData = new ArrayList<>(3);
        OutputOfStatistics outputdata = new OutputOfStatistics();
        List<String> nameList = new ArrayList<>(10);
        List<Long> numList = new ArrayList<>(10);
        List<Long> idList = new ArrayList<>(10);
        //查询1个月内基地统计
        List<StatisticsMode> monthDBData = statisticsDao.queryHottestBaseOneMonth();
        for (StatisticsMode data : monthDBData) {
            nameList.add(data.getName());
            numList.add(data.getNum());
            idList.add(data.getId());
        }
        outputdata.setName(nameList);
        outputdata.setNums(numList);
        outputdata.setIds(idList);
        outputdata.setType(TimeTypeEnum.Month.name());
        respData.add(outputdata);


        //查询一周内基地统计
        List<String> nameList2 = new ArrayList<>(10);
        List<Long> numList2 = new ArrayList<>(10);
        List<Long> idList2 = new ArrayList<>(10);
        OutputOfStatistics ouptutdataOfWeek = new OutputOfStatistics();
        List<StatisticsMode> weekDBData = statisticsDao.queryHottestBaseOneWeek();
        for (StatisticsMode data : weekDBData) {
            nameList2.add(data.getName());
            numList2.add(data.getNum());
            idList2.add(data.getId());
        }
        ouptutdataOfWeek.setName(nameList2);
        ouptutdataOfWeek.setNums(numList2);
        ouptutdataOfWeek.setIds(idList2);
        ouptutdataOfWeek.setType(TimeTypeEnum.Week.name());
        respData.add(ouptutdataOfWeek);


        //查询三天那日基地统计
        List<String> nameList3 = new ArrayList<>(10);
        List<Long> numList3 = new ArrayList<>(10);
        List<Long> idList3 = new ArrayList<>(10);
        OutputOfStatistics ouptutdataOfDay = new OutputOfStatistics();
        List<StatisticsMode> threeDayDBData = statisticsDao.queryHottestBaseThreeDay();
        for (StatisticsMode data : threeDayDBData) {
            nameList3.add(data.getName());
            numList3.add(data.getNum());
            idList3.add(data.getId());
        }
        ouptutdataOfDay.setName(nameList3);
        ouptutdataOfDay.setNums(numList3);
        ouptutdataOfDay.setIds(idList3);
        ouptutdataOfDay.setType(TimeTypeEnum.Day.name());
        respData.add(ouptutdataOfDay);

        Collections.reverse(respData);
        return respData;
    }

    @Override
    public List<HotWord> queryHottestWords() {
        List<String> tagList = new ArrayList<>();
        HashSet<String> tags = new HashSet<>();
        //List<String> tagStr = new ArrayList<>();
        //List<Long> tagNum = new ArrayList<>();
        List<HotWord> words = new ArrayList<>();
        //OutputHottestWords hottestWords = new OutputHottestWords();

        List<Map<String, Object>> list = statisticsDao.queryHottestWords();
        if (list.size() > 0) {
            // List<String> tags = new ArrayList<>(10);
            //List<Long> num = new ArrayList<>(10);
            for (Map<String, Object> map : list) {
                String tag = (String) map.get("tag");

                if (tag.contains(";")) {
                    StringTokenizer tokenizer = new StringTokenizer(tag, ";");
                    while (tokenizer.hasMoreTokens()) {
                        String str = tokenizer.nextToken();
                        tagList.add(str);
                        tags.add(str);
                    }
                }
                if (tag.contains("；")) {
                    StringTokenizer tokenizer1 = new StringTokenizer(tag, "；");
                    while (tokenizer1.hasMoreTokens()) {
                        String str = tokenizer1.nextToken();
                        tagList.add(str);
                        tags.add(str);
                    }
                }

            }

        }


        //唯一
        for (String tag : tags) {
            HotWord hotWord = new HotWord();
            /*Long count = 0L;

            //重复
            for (int j = 0; j < tagList.size(); j++) {
                if (tagList.get(j).equals(tag)) {
                    count++;
                    tagList.remove(tagList.get(j));
                    j--;
                }
            }*/

            int count = Collections.frequency(tagList, tag);

            hotWord.setNum(Long.valueOf(count));
            hotWord.setTag(tag);
            words.add(hotWord);
            //tagStr.add(tag);
            //tagNum.add(count);
        }

        order(words);
        if (words.size() >= 10) {
            return words.subList(0, 10);
        } else {
            //List<HotWord> list2=statisticsDao.selectHottestShip(10-list.size());
            StringBuffer buffer = new StringBuffer();
            buffer.append("select ship_name tag,count(ship_name) num from `relation_ship_event` ");
            buffer.append("where event_id in ( ");
            buffer.append("select uuid from object_event where fssj BETWEEN  (select DATE_SUB(now(), interval 1 month))   and now() ");
            buffer.append(" )  group by ship_name order by num desc limit " + (10 - words.size()));
            List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(buffer.toString());
            if (maps.size() > 0) {
                for (Map<String, Object> map : maps) {
                    String s = JSON.toJSONString(map);
                    HotWord output = JSON.toJavaObject(JSON.parseObject(s), HotWord.class);
                    words.add(output);
                }
            }

            //  words.addAll(list2);
            order(words);
            return words;
        }


    }


    //统计昨日事件总数
    @Override
    public Integer statisticsYesterdayEvent() {
        Calendar instance = Calendar.getInstance();
        String time = instance.get(Calendar.YEAR) + "-" + Integer.valueOf(instance.get(Calendar.MONTH) + 1) + "-" + (instance.get(Calendar.DAY_OF_MONTH) - 1);
        return statisticsDao.statisticsYesterdayEvent(time);
    }

    @Override
    public List<StatisticsOfBaseEventByType> statisticsEventOfBaseByType() {
        List<StatisticsOfBaseEventByType> data = new ArrayList<>();
        try {
            List<Integer> baseIDs = BaseEnum.allOfBaseID();

            //查询所有事件的标签集
            List<String> types = eventService.queryAllEventType();
            List<StatisticOfWestPacificBaseEventModel> basicData = null;
            for (int i = 0; i < baseIDs.size(); i++) {
                StatisticsOfBaseEventByType statisticsMsg = new StatisticsOfBaseEventByType();
                int baseID = baseIDs.get(i);
                statisticsMsg.setBaseID(baseID);
                List<String> reType = new ArrayList<>();
                List<Long> num = new ArrayList<>();
                for (String type : types) {
                    reType.add(type);
                    basicData = statisticsDao.StatisticOfWestPacificBaseEvent(baseID, type);
                    num.add(Long.valueOf(basicData.size()));
                    if (basicData.size() > 0) {

                        statisticsMsg.setYwmc(basicData.get(0).getJdywm());
                        statisticsMsg.setZwmc(basicData.get(0).getJdzwm());
                    }

                    //统计每个基地事件类型

                }
                statisticsMsg.setNum(num);
                statisticsMsg.setType(reType);
                if (null == statisticsMsg.getYwmc()) {
                    List<ObjectBaseBasicInfoEntity> bases = statisticsDao.queryBaseByID(Arrays.asList(baseID));
                    if (bases.size() > 0) {
                        statisticsMsg.setZwmc(bases.get(0).getJdzwm());
                        statisticsMsg.setYwmc(bases.get(0).getJdywm());
                    }

                }
                data.add(statisticsMsg);
            }
        } catch (Exception e) {
            logg.error("操作失败");
        }

        return data;
    }

    @Override
    public List<StatisticsManoeuvreOutput> statisticsManoeuvreOfBaseByTime() {
        List<StatisticsManoeuvreOutput> list = new ArrayList<>(4);//当天 三天 七天 一个月
        //查询所有西太基地基地中英文名
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        List<ObjectBaseBasicInfoEntity> bases = statisticsDao.queryBaseByID(baseIDs);
        for (ObjectBaseBasicInfoEntity basicInfoEntity : bases) {
            StatisticsManoeuvreOutput output_1Day = new StatisticsManoeuvreOutput();
            StatisticsManoeuvreOutput output_3Day = new StatisticsManoeuvreOutput();
            StatisticsManoeuvreOutput output_7Day = new StatisticsManoeuvreOutput();
            StatisticsManoeuvreOutput output_1Month = new StatisticsManoeuvreOutput();

            int baseID = basicInfoEntity.getJdid();

            output_1Day.setBaseID(baseID);
            output_1Day.setZwmc(basicInfoEntity.getJdzwm());
            output_1Day.setYwmc(basicInfoEntity.getJdywm());
            output_3Day.setBaseID(baseID);
            output_3Day.setZwmc(basicInfoEntity.getJdzwm());
            output_3Day.setYwmc(basicInfoEntity.getJdywm());
            output_7Day.setBaseID(baseID);
            output_7Day.setZwmc(basicInfoEntity.getJdzwm());
            output_7Day.setYwmc(basicInfoEntity.getJdywm());
            output_1Month.setBaseID(baseID);
            output_1Month.setZwmc(basicInfoEntity.getJdzwm());
            output_1Month.setYwmc(basicInfoEntity.getJdywm());

            //统计当日
            output_1Day.setTimeType("Today");
            List<String> times = new ArrayList<>();
            List<Integer> nums = new ArrayList<>();
            List<SliceOfTime> sliceOfTime = TimeUtil.getSliceOfTime("1Day");
            for (SliceOfTime slice : sliceOfTime) {
                String time = slice.getBeginTime().split(" ")[1].split(":")[0] + "时";//"2019-02-02 11:11:33"
                int count = statisticsDao.statisticsManoeuvreOfBaseByTime(baseID, slice);
                times.add(time);
                nums.add(count);
            }
            output_1Day.setTime(times);
            output_1Day.setNum(nums);


            //统计三天
            output_3Day.setTimeType("3Day");
            List<String> times_3Day = new ArrayList<>();
            List<Integer> nums_3Day = new ArrayList<>();
            List<SliceOfTime> sliceOfTime_3Day = TimeUtil.getSliceOfTime("3Day");
            for (SliceOfTime slice : sliceOfTime_3Day) {
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                int count = statisticsDao.statisticsManoeuvreOfBaseByTime(baseID, slice);
                times_3Day.add(time);
                nums_3Day.add(count);
            }
            output_3Day.setTime(times_3Day);
            output_3Day.setNum(nums_3Day);

            //统计七天
            output_7Day.setTimeType("7Day");
            List<String> times_7Day = new ArrayList<>();
            List<Integer> nums_7Day = new ArrayList<>();
            List<SliceOfTime> sliceOfTime_7Day = TimeUtil.getSliceOfTime("7Day");
            for (SliceOfTime slice : sliceOfTime_7Day) {
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                int count = statisticsDao.statisticsManoeuvreOfBaseByTime(baseID, slice);
                times_7Day.add(time);
                nums_7Day.add(count);
            }
            output_7Day.setTime(times_7Day);
            output_7Day.setNum(nums_7Day);

            //统计一个月
            output_1Month.setTimeType("1Month");
            List<String> times_1Month = new ArrayList<>();
            List<Integer> nums_1Month = new ArrayList<>();
            List<SliceOfTime> sliceOfTime_1Month = TimeUtil.getSliceOfTime("1Month");
            for (SliceOfTime slice : sliceOfTime_1Month) {
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                int count = statisticsDao.statisticsManoeuvreOfBaseByTime(baseID, slice);
                times_1Month.add(time);
                nums_1Month.add(count);
            }
            output_1Month.setTime(times_1Month);
            output_1Month.setNum(nums_1Month);
            list.add(output_1Day);
            list.add(output_3Day);
            list.add(output_7Day);
            list.add(output_1Month);
        }


        return list;
    }

    //西太地区：演习事件地点发生事件统计
    @Override
    public StatisticsLocationOfManoeuvreOutput statisticsLocationOfManoeuvre() {
        StatisticsLocationOfManoeuvreOutput output = new StatisticsLocationOfManoeuvreOutput();
        List<Long> num = new ArrayList<>();
        List<String> name = new ArrayList<>();
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT dd location,count(dd) number from object_event  where uuid in ( ");
        buffer.append("SELECT `event_id`  FROM `relation_base_event` WHERE `base_id` in (");
        for (Integer baseID : baseIDs) {
            buffer.append(baseID + ",");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(" ))");
        buffer.append("and dd is not null and `tag1` like '%演习%' ");
        buffer.append("GROUP BY location ORDER BY number desc  limit 10");
        List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(buffer.toString());

        for (Map<String, Object> map : maps) {
            name.add((String) map.get("location"));
            num.add(Long.valueOf((Long) map.get("number")));
        }
        output.setName(name);
        output.setNum(num);
        return output;
    }

    //西太地区：按时间统计舰船事件
    @Override
    public List<StatisticsEventOutput> statisticsEventOfShipByTime() {
        List<StatisticsEventOutput> response = new ArrayList<>();
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        //查询西太地区所有舰船基本信息
        List<StatisticsEventOutput> list = statisticsDao.queryBasicShipMsg(baseIDs);
        //追加舰船数据  relation_ship_location  判断此表中qymc是否为空
        List<StatisticsEventOutput> extra = statisticsDao.queryBasicShipMsgExtra();
        if (extra.size() > 0) {

            for (StatisticsEventOutput output : list) {
                int id = output.getId();
                extra.removeIf(out -> out.getId() == id);
            }

            list.addAll(extra);
        }


        for (StatisticsEventOutput output : list) {
            StatisticsEventOutput output_1Day = new StatisticsEventOutput();
            StatisticsEventOutput output_3Day = new StatisticsEventOutput();
            StatisticsEventOutput output_7Day = new StatisticsEventOutput();
            StatisticsEventOutput output_1Month = new StatisticsEventOutput();

            output_1Day.setId(output.getId());
            output_1Day.setMc(output.getMc());
            output_1Day.setYwmc(output.getYwmc());
            output_1Day.setTimeType("Today");

            output_3Day.setId(output.getId());
            output_3Day.setMc(output.getMc());
            output_3Day.setYwmc(output.getYwmc());
            output_3Day.setTimeType("3Day");

            output_7Day.setId(output.getId());
            output_7Day.setMc(output.getMc());
            output_7Day.setYwmc(output.getYwmc());
            output_7Day.setTimeType("7Day");

            output_1Month.setId(output.getId());
            output_1Month.setMc(output.getMc());
            output_1Month.setYwmc(output.getYwmc());
            output_1Month.setTimeType("1Month");

            int shipID = output.getId();

            //统计当天

            List<String> times = new ArrayList<>();
            List<Integer> nums = new ArrayList<>();
            List<SliceOfTime> sliceOfTime = TimeUtil.getSliceOfTime("1Day");
            for (SliceOfTime slice : sliceOfTime) {
                String time = slice.getBeginTime().split(" ")[1].split(":")[0] + "时";//"2019-02-02 11:11:33"

                List<String> events = statisticsDao.statisticsEventByTime(shipID, slice, baseIDs);//
                List<String> extra_event = statisticsDao.statisticsEventByTime_Extra(shipID, slice);
                if (extra_event.size() > 0 && events.size() > 0) {

                    for (String event : events) {
                        extra_event.removeIf(ex -> ex.equals(event));
                    }
                    events.addAll(extra_event);
                }
                times.add(time);
                nums.add(events.size());
            }
            output_1Day.setTime(times);
            output_1Day.setNum(nums);

            //统计三天
            List<String> times_3Day = new ArrayList<>();
            List<Integer> nums_3Day = new ArrayList<>();
            List<SliceOfTime> sliceOfTime_3Day = TimeUtil.getSliceOfTime("3Day");
            for (SliceOfTime slice : sliceOfTime_3Day) {
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                List<String> events = statisticsDao.statisticsEventByTime(shipID, slice, baseIDs);//
                List<String> extra_event = statisticsDao.statisticsEventByTime_Extra(shipID, slice);
                if (extra_event.size() > 0 && events.size() > 0) {

                    for (String event : events) {
                        extra_event.removeIf(ex -> ex.equals(event));
                    }
                    events.addAll(extra_event);
                }
                times_3Day.add(time);
                nums_3Day.add(events.size());
            }

            output_3Day.setTime(times_3Day);
            output_3Day.setNum(nums_3Day);

            //统计七天
            List<String> times_7Day = new ArrayList<>();
            List<Integer> nums_7Day = new ArrayList<>();
            List<SliceOfTime> sliceOfTime_7Day = TimeUtil.getSliceOfTime("7Day");
            for (SliceOfTime slice : sliceOfTime_7Day) {
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                List<String> events = statisticsDao.statisticsEventByTime(shipID, slice, baseIDs);//
                List<String> extra_event = statisticsDao.statisticsEventByTime_Extra(shipID, slice);
                if (extra_event.size() > 0 && events.size() > 0) {

                    for (String event : events) {
                        extra_event.removeIf(ex -> ex.equals(event));
                    }
                    events.addAll(extra_event);
                }
                times_7Day.add(time);
                nums_7Day.add(events.size());
            }
            output_7Day.setTime(times_7Day);
            output_7Day.setNum(nums_7Day);

            //统计一个月
            List<String> times_1Month = new ArrayList<>();
            List<Integer> nums_1Month = new ArrayList<>();
            List<SliceOfTime> sliceOfTime_1Month = TimeUtil.getSliceOfTime("1Month");
            for (SliceOfTime slice : sliceOfTime_1Month) {
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                List<String> events = statisticsDao.statisticsEventByTime(shipID, slice, baseIDs);//
                List<String> extra_event = statisticsDao.statisticsEventByTime_Extra(shipID, slice);
                if (extra_event.size() > 0 && events.size() > 0) {

                    for (String event : events) {
                        extra_event.removeIf(ex -> ex.equals(event));
                    }
                    events.addAll(extra_event);
                }
                times_1Month.add(time);
                nums_1Month.add(events.size());
            }


            output_1Month.setTime(times_1Month);
            output_1Month.setNum(nums_1Month);
            response.add(output_1Day);
            response.add(output_3Day);
            response.add(output_7Day);
            response.add(output_1Month);
        }
        return response;
    }

    //西太地区：按时间统计基地事件
    @Override
    public List<StatisticsEventOutput> statisticsEventOfBaseByTime() {
        List<StatisticsEventOutput> response = new ArrayList<>();
        try {
            List<Integer> baseIDs = BaseEnum.allOfBaseID();
            //当天
            //当天事件最多的基地
            SliceOfTime sliceOfTime = TimeUtil.getQueryTime("1Day");
            List<StatisticsEventOutput> list = statisticsDao.queryMostEventOfBaseByTime(sliceOfTime, baseIDs);
            List<SliceOfTime> timeList = TimeUtil.getSliceOfTime("1Day");
            //查询具体事件的事件数
            for (StatisticsEventOutput output : list) {
                StatisticsEventOutput output_1Day = new StatisticsEventOutput();
                int baseID = output.getId();
                output_1Day.setMc(output.getMc());
                output_1Day.setYwmc(output.getYwmc());
                output_1Day.setId(baseID);
                output_1Day.setTimeType("1Day");

                List<String> time = new ArrayList<>();
                List<Integer> num = new ArrayList<>();

                for (SliceOfTime slice : timeList) {
                    //统计基地具体时间内事件总数
                    String hour = slice.getBeginTime().split(" ")[1].split(":")[0] + "时";//"2019-02-02 11:11:33"
                    Integer eventCount = statisticsDao.statisticsEventCountByBaseIDInSliceOfTime(baseID, slice);
                    time.add(hour);
                    num.add(eventCount);
                }
                output_1Day.setTime(time);
                output_1Day.setNum(num);
                response.add(output_1Day);
            }

            //近3天
            //近3天事件最多的基地
            SliceOfTime sliceOfTime_3Day = TimeUtil.getQueryTime("3Day");
            List<StatisticsEventOutput> list_3Day = statisticsDao.queryMostEventOfBaseByTime(sliceOfTime_3Day, baseIDs);
            List<SliceOfTime> timeList_3Day = TimeUtil.getSliceOfTime("3Day");
            //查询具体事件的事件数
            for (StatisticsEventOutput output : list_3Day) {
                StatisticsEventOutput output_3Day = new StatisticsEventOutput();
                int baseID = output.getId();
                output_3Day.setMc(output.getMc());
                output_3Day.setYwmc(output.getYwmc());
                output_3Day.setId(baseID);
                output_3Day.setTimeType("3Day");

                List<String> time = new ArrayList<>();
                List<Integer> num = new ArrayList<>();

                for (SliceOfTime slice : timeList_3Day) {
                    //统计基地具体时间内事件总数
                    String day = slice.getBeginTime().split(" ")[0].split("-", 2)[1];
                    Integer eventCount = statisticsDao.statisticsEventCountByBaseIDInSliceOfTime(baseID, slice);
                    time.add(day);
                    num.add(eventCount);
                }
                output_3Day.setTime(time);
                output_3Day.setNum(num);
                response.add(output_3Day);
            }

            //近7天
            //近7天事件最多的基地
            SliceOfTime sliceOfTime_7Day = TimeUtil.getQueryTime("7Day");
            List<StatisticsEventOutput> list_7Day = statisticsDao.queryMostEventOfBaseByTime(sliceOfTime_7Day, baseIDs);
            List<SliceOfTime> timeList_7Day = TimeUtil.getSliceOfTime("7Day");
            //查询具体事件的事件数
            for (StatisticsEventOutput output : list_7Day) {
                StatisticsEventOutput output_7Day = new StatisticsEventOutput();
                int baseID = output.getId();
                output_7Day.setMc(output.getMc());
                output_7Day.setYwmc(output.getYwmc());
                output_7Day.setId(baseID);
                output_7Day.setTimeType("7Day");

                List<String> time = new ArrayList<>();
                List<Integer> num = new ArrayList<>();

                for (SliceOfTime slice : timeList_7Day) {
                    //统计基地具体时间内事件总数
                    String day = slice.getBeginTime().split(" ")[0].split("-", 2)[1];
                    Integer eventCount = statisticsDao.statisticsEventCountByBaseIDInSliceOfTime(baseID, slice);
                    time.add(day);
                    num.add(eventCount);
                }
                output_7Day.setTime(time);
                output_7Day.setNum(num);
                response.add(output_7Day);
            }

            //近1个月
            //近1个月事件最多的基地
            SliceOfTime sliceOfTime_1Month = TimeUtil.getQueryTime("1Month");
            List<StatisticsEventOutput> list_1Month = statisticsDao.queryMostEventOfBaseByTime(sliceOfTime_1Month, baseIDs);
            List<SliceOfTime> timeList_1Month = TimeUtil.getSliceOfTime("1Month");
            //查询具体事件的事件数
            for (StatisticsEventOutput output : list_1Month) {
                StatisticsEventOutput output_1Month = new StatisticsEventOutput();
                int baseID = output.getId();
                output_1Month.setMc(output.getMc());
                output_1Month.setYwmc(output.getYwmc());
                output_1Month.setId(baseID);
                output_1Month.setTimeType("1Month");

                List<String> time = new ArrayList<>();
                List<Integer> num = new ArrayList<>();

                for (SliceOfTime slice : timeList_1Month) {
                    //统计基地具体时间内事件总数
                    String day = slice.getBeginTime().split(" ")[0].split("-", 2)[1];
                    Integer eventCount = statisticsDao.statisticsEventCountByBaseIDInSliceOfTime(baseID, slice);
                    time.add(day);
                    num.add(eventCount);
                }
                output_1Month.setTime(time);
                output_1Month.setNum(num);
                response.add(output_1Month);
            }
        } catch (Exception e) {
            logg.error("查询错误！");
        }

        return response;
    }

    //西太地区：按时间及基地id查询基地事件详情：1,3,7天,1月
    @Override
    public List<EventAllMsgs> queryEventsByTimeAndBaseID(EventQueryByIDAndTime input) {
        if(input.getTime()==null||input.getId()==0){
            return null;
        }
        String time = input.getTime();
        //标准化查询时间
        SliceOfTime queryTime = TimeUtil.getQueryTime(time);
        //根据基地id及时间查询事件信息:包含相关人物、舰船、基地
        List<EventAllMsgs> list=statisticsDao.queryEventsByTimeAndBaseID(queryTime,input.getId());
        for (EventAllMsgs allMsgs : list) {
            String uuid = allMsgs.getUuid();
            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关人物
            List<SimpleModel> personList = statisticsDao.querySimplePersonByUUID(uuid);

            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关舰船
            List<SimpleModel> shipList = statisticsDao.querySimpleShipByUUID(uuid);

            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关基地
            List<SimpleModel> baseList = statisticsDao.querySimpleBaseByUUID(uuid);

            allMsgs.setPerson(personList);
            allMsgs.setShip(shipList);
            allMsgs.setBase(baseList);

        }
        return list;
    }

    //西太地区：按时间统计人物事件
    @Override
    public List<StatisticsEventOutput> statisticsEventOfPersonByTime() {
        List<StatisticsEventOutput> response = new ArrayList<>();
        try {
            List<Integer> baseIDs = BaseEnum.allOfBaseID();
            //查询西太地区所有人物
            List<StatisticsEventOutput> person = statisticsDao.queryPersonByBase(baseIDs,"1Month");
            List<StatisticsEventOutput> personList=statisticsDao.queryPersonByBase(baseIDs,"7Day");
            if(personList.size()>person.size()){
                person=personList;

            }
            //查询西太地区人物事件
            for (StatisticsEventOutput output : person) {

                StatisticsEventOutput output_1Day = new StatisticsEventOutput();
                StatisticsEventOutput output_3Day = new StatisticsEventOutput();
                StatisticsEventOutput output_7Day = new StatisticsEventOutput();
                StatisticsEventOutput output_1Month = new StatisticsEventOutput();

                output_1Day.setId(output.getId());
                output_1Day.setMc(output.getMc());
                output_1Day.setYwmc(output.getYwmc());
                output_1Day.setTimeType("Today");

                output_3Day.setId(output.getId());
                output_3Day.setMc(output.getMc());
                output_3Day.setYwmc(output.getYwmc());
                output_3Day.setTimeType("3Day");

                output_7Day.setId(output.getId());
                output_7Day.setMc(output.getMc());
                output_7Day.setYwmc(output.getYwmc());
                output_7Day.setTimeType("7Day");

                output_1Month.setId(output.getId());
                output_1Month.setMc(output.getMc());
                output_1Month.setYwmc(output.getYwmc());
                output_1Month.setTimeType("1Month");

                int personID = output.getId();
                //统计1天
                List<String> times = new ArrayList<>();
                List<Integer> nums = new ArrayList<>();
                List<SliceOfTime> sliceOfTime = TimeUtil.getSliceOfTime("1Day");
                for (SliceOfTime slice : sliceOfTime) {
                    String time = slice.getBeginTime().split(" ")[1].split(":")[0] + "时";//"2019-02-02 11:11:33"
                    List<String> extra_event;
                    List<String> events = statisticsDao.statisticsEventByTimeOfPerson(personID, slice);//人物-事件
                    if (extra_event_map.get(time) == null) {
                        extra_event = statisticsDao.statisticsEventByTimeOfPerson_extra(baseIDs, slice);//基地-事件
                        extra_event_map.put(time, extra_event);
                    } else extra_event = extra_event_map.get(time);
                    //List<String> realEvent = new ArrayList<>();
                    events.retainAll(extra_event);

                    times.add(time);
                    nums.add(events.size());
                }
                output_1Day.setTime(times);
                output_1Day.setNum(nums);

                //统计三天
                List<String> times_3Day = new ArrayList<>();
                List<Integer> nums_3Day = new ArrayList<>();
                List<SliceOfTime> sliceOfTime_3Day = TimeUtil.getSliceOfTime("3Day");
                for (SliceOfTime slice : sliceOfTime_3Day) {
                    String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                    List<String> extra_event;
                    List<String> events = statisticsDao.statisticsEventByTimeOfPerson(personID, slice);//人物-事件
                    if (extra_event_map.get(time) == null) {
                        extra_event = statisticsDao.statisticsEventByTimeOfPerson_extra(baseIDs, slice);//基地-事件
                        extra_event_map.put(time, extra_event);
                    } else extra_event = extra_event_map.get(time);
                    events.retainAll(extra_event);
                    times_3Day.add(time);
                    nums_3Day.add(events.size());
                }

                output_3Day.setTime(times_3Day);
                output_3Day.setNum(nums_3Day);

                //统计七天
                List<String> times_7Day = new ArrayList<>();
                List<Integer> nums_7Day = new ArrayList<>();
                List<SliceOfTime> sliceOfTime_7Day = TimeUtil.getSliceOfTime("7Day");
                for (SliceOfTime slice : sliceOfTime_7Day) {
                    String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                    List<String> extra_event;
                    List<String> events = statisticsDao.statisticsEventByTimeOfPerson(personID, slice);//人物-事件
                    if (extra_event_map.get(time) == null) {
                        extra_event = statisticsDao.statisticsEventByTimeOfPerson_extra(baseIDs, slice);//基地-事件
                        extra_event_map.put(time, extra_event);
                    } else extra_event = extra_event_map.get(time);
                    events.retainAll(extra_event);
                    times_7Day.add(time);
                    nums_7Day.add(events.size());
                }
                output_7Day.setTime(times_7Day);
                output_7Day.setNum(nums_7Day);

                //统计一个月
                List<String> times_1Month = new ArrayList<>();
                List<Integer> nums_1Month = new ArrayList<>();
                List<SliceOfTime> sliceOfTime_1Month = TimeUtil.getSliceOfTime("1Month");
                for (SliceOfTime slice : sliceOfTime_1Month) {
                    String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                    List<String> extra_event;
                    List<String> events = statisticsDao.statisticsEventByTimeOfPerson(personID, slice);//人物-事件
                    if (extra_event_map.get(time) == null) {
                        extra_event = statisticsDao.statisticsEventByTimeOfPerson_extra(baseIDs, slice);//基地-事件
                        extra_event_map.put(time, extra_event);
                    } else extra_event = extra_event_map.get(time);
                    events.retainAll(extra_event);

                    times_1Month.add(time);
                    nums_1Month.add(events.size());
                }

                output_1Month.setTime(times_1Month);
                output_1Month.setNum(nums_1Month);

                response.add(output_1Day);
                response.add(output_3Day);
                response.add(output_7Day);
                response.add(output_1Month);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            return response;
        }
    }

    @Override
    public List<StatisticsOfOutputSource> statisticsEventByDatasource() {
        List<StatisticsOfOutputSource> list = new ArrayList<>();
        List<OutputSource> sources = newsService.queryAllSource();
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT `vc_domain` soure,`vc_origin` name,count(`vc_uuid`)  count FROM `tb_news_new` where  ");
        buffer.append("`vc_domain` in ( ");
        for (OutputSource source : sources) {
            String soure = source.getSoure();
            buffer.append("'" + soure + "',");
        }
        buffer.deleteCharAt(buffer.lastIndexOf(","));
        buffer.append(") GROUP BY vc_domain ORDER BY count desc limit 10 ");
        List<Map<String, Object>> maps = secJdbctemplate.queryForList(buffer.toString());
        for (Map<String, Object> map : maps) {
            String s = JSON.toJSONString(map);
            StatisticsOfOutputSource source = JSON.toJavaObject(JSON.parseObject(s), StatisticsOfOutputSource.class);
            list.add(source);
        }

        return list;
    }

    @Override
    public List<StatisticsOfShipState> statisticsQuantityOfShipByState() {
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        return statisticsDao.statisticsQuantityOfShipByState(baseIDs);
    }

    //西太地区：按事件类型统计一定时间内的事件
    @Override
    public List<StatisticsManoeuvreOutput> statisticsEventGroupByTypeByTime() {
        List<StatisticsManoeuvreOutput> data = new ArrayList<>();
        try {
            List<Integer> baseIDs = BaseEnum.allOfBaseID();
            List<String> types = eventService.queryAllEventType();
            types.remove("其他");
            for (String type : types) {

                StatisticsManoeuvreOutput output_1Month = new StatisticsManoeuvreOutput();
                StatisticsManoeuvreOutput output_3Month = new StatisticsManoeuvreOutput();
                StatisticsManoeuvreOutput output_1Year = new StatisticsManoeuvreOutput();
                output_1Month.setType(type);
                output_3Month.setType(type);
                output_1Year.setType(type);


                //填充近一月统计数据
                List<String> time_1Month = new ArrayList<>();
                List<Integer> num_1Month = new ArrayList<>();
                output_1Month.setTimeType("1Month");
                List<SliceOfTime> sliceOfTimes = TimeUtil.getSliceOfTime("1Month");
                for (SliceOfTime slice : sliceOfTimes) {
                    String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                    Integer count = statisticsDao.statisticsEventByTimeAndType(baseIDs, slice, type);
                    time_1Month.add(time);
                    num_1Month.add(count);
                }
                output_1Month.setTime(time_1Month);
                output_1Month.setNum(num_1Month);

                //填充近三个月统计数据
                List<String> time_3Month = new ArrayList<>();
                List<Integer> num_3Month = new ArrayList<>();
                output_3Month.setTimeType("3Month");
                List<SliceOfTime> sliceOfTimes_3Month = TimeUtil.getSliceOfTime("3Month");
                for (SliceOfTime slice : sliceOfTimes_3Month) {

                    String[] time_number = slice.getBeginTime().split(" ")[0].split("-");//"2019-02-02 11:11:33"
                    String time = time_number[0] + "-" + time_number[1];
                    Integer count = statisticsDao.statisticsEventByTimeAndType(baseIDs, slice, type);
                    time_3Month.add(time);
                    num_3Month.add(count);
                }
                output_3Month.setTime(time_3Month);
                output_3Month.setNum(num_3Month);


                //填充本年统计数据
                List<String> time_1Year = new ArrayList<>();
                List<Integer> num_1Year = new ArrayList<>();
                output_1Year.setTimeType("1Year");
                List<SliceOfTime> sliceOfTimes_1Year = TimeUtil.getSliceOfTime("1Year");
                for (SliceOfTime slice : sliceOfTimes_1Year) {

                    String[] time_number = slice.getBeginTime().split(" ")[0].split("-");//"2019-02-02 11:11:33"
                    String time = time_number[0] + "-" + time_number[1];
                    Integer count = statisticsDao.statisticsEventByTimeAndType(baseIDs, slice, type);
                    time_1Year.add(time);
                    num_1Year.add(count);
                }
                output_1Year.setTime(time_1Year);
                output_1Year.setNum(num_1Year);

                data.add(output_1Month);
                data.add(output_3Month);
                data.add(output_1Year);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logg.error("查询出错！");
        }
        return data;
    }


    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>,携带相关人物、舰船、基地
    @Override
    public List<EventAllMsgs> queryEventsByTypeAndTime(EventQueryByIDAndTime input) {
        String time = input.getTime();
        String type = input.getType();
        if (input.getTime() == null || input.getType() == null) {
            return null;
        }
        //标准化查询时间
        SliceOfTime slice = TimeUtil.getQueryTime(time);
        String flag = Integer.valueOf(time.split("-")[0]) > 12 ? "MONTH" : "DAY";
        List<EventAllMsgs> list = statisticsDao.queryEventsByTypeAndTime(type, slice, flag);
        for (EventAllMsgs allMsgs : list) {
            String uuid = allMsgs.getUuid();
            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关人物
            List<SimpleModel> personList = statisticsDao.querySimplePersonByUUID(uuid);

            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关舰船
            List<SimpleModel> shipList = statisticsDao.querySimpleShipByUUID(uuid);

            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关基地
            List<SimpleModel> baseList = statisticsDao.querySimpleBaseByUUID(uuid);

            allMsgs.setPerson(personList);
            allMsgs.setShip(shipList);
            allMsgs.setBase(baseList);
            //职务变动特别处理
            String tag1 = allMsgs.getTag1();
            if(tag1!=null&&tag1.contains("职务变动")){
                //查询关键句
                String sql="SELECT new_leader newLeader,old_leader oldLeader,gjj from `relation_zwbd` where `event_id` ='"+allMsgs.getUuid()+"'";
                //List<String> gjj = primaryJdbcTemplate.queryForList(sql, String.class);
                List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(sql);
                for(Map<String, Object> map:maps){
                    String oldLeader = (String) map.get("oldLeader");
                    String newLeader = (String) map.get("newLeader");
                    String gjjStr = (String) map.get("gjj");
                    allMsgs.setOldLeader(oldLeader);
                    allMsgs.setNewLeader(newLeader);
                    allMsgs.setGjj(gjjStr);
                    break;
                }
                /*if(gjj.size()>0){
                    allMsgs.setGjj(gjj.get(0));
                    continue;
                }*/
            }

        }

        return list;
    }



    @Override
    public List<StatisticsStateOfShip> statisticsStateOfShipByTime() {
        List<StatisticsStateOfShip> data = new ArrayList<>();//当天、3天、7天、1month

        try {
            /**                                     当天数据                                      */

            StatisticsStateOfShip data_1Day_IN = new StatisticsStateOfShip();
            StatisticsStateOfShip data_1Day_OUT = new StatisticsStateOfShip();
            List<String> time_1Day = new ArrayList<>();
            List<Integer> num_1Day_IN = new ArrayList<>();
            List<Integer> num_1Day_OUT = new ArrayList<>();
            data_1Day_IN.setState("在港");
            data_1Day_OUT.setState("离港");
            data_1Day_IN.setTimeType("1Day");
            data_1Day_OUT.setTimeType("1Day");
            //获取时间片
            List<SliceOfTime> sliceOfTime = TimeUtil.getSliceOfTime("1Day");
            for (SliceOfTime slice : sliceOfTime) {
                //统计每个时间点内再港数据
                String time = slice.getBeginTime().split(" ")[1].split(":")[0] + "时";//"2019-02-02 11:11:33"
                List<Integer> state_num = statisticsDao.statisticsShipByStateAndSliceOfTime(slice);//list[0]-在港,list[1]不在港
                if (state_num.size() == 1) {
                    num_1Day_IN.add(state_num.get(0));
                    num_1Day_OUT.add(state_num.get(0));
                } else if (state_num.size() > 1) {
                    num_1Day_IN.add(state_num.get(0));
                    num_1Day_OUT.add(state_num.get(1));
                }
                time_1Day.add(time);
            }
            data_1Day_IN.setTime(time_1Day);
            data_1Day_OUT.setTime(time_1Day);
            data_1Day_IN.setNum(num_1Day_IN);
            data_1Day_OUT.setNum(num_1Day_OUT);
            data.add(data_1Day_IN);
            data.add(data_1Day_OUT);
            System.out.println(num_1Day_IN.size());
            System.out.println(num_1Day_OUT.size());
            /**                                     3天数据                                      */

            StatisticsStateOfShip data_3Day_IN = new StatisticsStateOfShip();
            StatisticsStateOfShip data_3Day_OUT = new StatisticsStateOfShip();
            List<String> time_3Day = new ArrayList<>();
            List<Integer> num_3Day_IN = new ArrayList<>();
            List<Integer> num_3Day_OUT = new ArrayList<>();
            data_3Day_IN.setState("在港");
            data_3Day_OUT.setState("离港");
            data_3Day_IN.setTimeType("3Day");
            data_3Day_OUT.setTimeType("3Day");
            //获取时间片
            List<SliceOfTime> sliceOfTime_3Day = TimeUtil.getSliceOfTime("3Day");
            for (SliceOfTime slice : sliceOfTime_3Day) {
                //统计每个时间点内再港数据
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                List<Integer> state_num = statisticsDao.statisticsShipByStateAndSliceOfTime(slice);//list[0]-在港,list[1]不在港
                time_3Day.add(time);
                if (state_num.size() == 1) {
                    num_3Day_IN.add(state_num.get(0));
                    num_3Day_OUT.add(state_num.get(0));
                } else if (state_num.size() > 1) {
                    num_3Day_IN.add(state_num.get(0));
                    num_3Day_OUT.add(state_num.get(1));
                }
            }
            data_3Day_IN.setTime(time_3Day);
            data_3Day_OUT.setTime(time_3Day);
            data_3Day_IN.setNum(num_3Day_IN);
            data_3Day_OUT.setNum(num_3Day_OUT);
            data.add(data_3Day_IN);
            data.add(data_3Day_OUT);

            /**                                     7天数据                                      */

            StatisticsStateOfShip data_7Day_IN = new StatisticsStateOfShip();
            StatisticsStateOfShip data_7Day_OUT = new StatisticsStateOfShip();
            List<String> time_7Day = new ArrayList<>();
            List<Integer> num_7Day_IN = new ArrayList<>();
            List<Integer> num_7Day_OUT = new ArrayList<>();
            data_7Day_IN.setState("在港");
            data_7Day_OUT.setState("离港");
            data_7Day_IN.setTimeType("7Day");
            data_7Day_OUT.setTimeType("7Day");
            //获取时间片
            List<SliceOfTime> sliceOfTime_7Day = TimeUtil.getSliceOfTime("7Day");
            for (SliceOfTime slice : sliceOfTime_7Day) {
                //统计每个时间点内再港数据
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                List<Integer> state_num = statisticsDao.statisticsShipByStateAndSliceOfTime(slice);//list[0]-在港,list[1]不在港
                time_7Day.add(time);
                if (state_num.size() == 1) {
                    num_7Day_IN.add(state_num.get(0));
                    num_7Day_OUT.add(state_num.get(0));
                } else if (state_num.size() > 1) {
                    num_7Day_IN.add(state_num.get(0));
                    num_7Day_OUT.add(state_num.get(1));
                }
            }
            data_7Day_IN.setTime(time_7Day);
            data_7Day_OUT.setTime(time_7Day);
            data_7Day_IN.setNum(num_7Day_IN);
            data_7Day_OUT.setNum(num_7Day_OUT);
            data.add(data_7Day_IN);
            data.add(data_7Day_OUT);

            /**                                     近一月数据                                      */

            StatisticsStateOfShip data_1Month_IN = new StatisticsStateOfShip();
            StatisticsStateOfShip data_1Month_OUT = new StatisticsStateOfShip();
            List<String> time_1Month = new ArrayList<>();
            List<Integer> num_1Month_IN = new ArrayList<>();
            List<Integer> num_1Month_OUT = new ArrayList<>();
            data_1Month_IN.setState("在港");
            data_1Month_OUT.setState("离港");
            data_1Month_IN.setTimeType("1Month");
            data_1Month_OUT.setTimeType("1Month");
            //获取时间片
            List<SliceOfTime> sliceOfTime_1Month = TimeUtil.getSliceOfTime("1Month");
            for (SliceOfTime slice : sliceOfTime_1Month) {
                //统计每个时间点内再港数据
                String time = slice.getBeginTime().split(" ")[0].split("-", 2)[1];//"2019-02-02 11:11:33"
                List<Integer> state_num = statisticsDao.statisticsShipByStateAndSliceOfTime(slice);//list[0]-在港,list[1]不在港
                time_1Month.add(time);
                if (state_num.size() == 1) {
                    num_1Month_IN.add(state_num.get(0));
                    num_1Month_OUT.add(state_num.get(0));
                } else if (state_num.size() > 1) {
                    num_1Month_IN.add(state_num.get(0));
                    num_1Month_OUT.add(state_num.get(1));
                }
            }
            data_1Month_IN.setTime(time_1Month);
            data_1Month_OUT.setTime(time_1Month);
            data_1Month_IN.setNum(num_1Month_IN);
            data_1Month_OUT.setNum(num_1Month_OUT);
            data.add(data_1Month_IN);
            data.add(data_1Month_OUT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    @Override
    public List<ShipAndEvents> queryShipAndeventsByTime(QueryShipAndEventsParam param) {
        if (param.getTimeType() == null || param.getTime() == null || param.getState() == null) {
            return null;
        }
        List<ShipAndEvents> list = new ArrayList<>();
        try {
            //标准化时间
            String time = param.getTime();
            String state = param.getState();
            String flag = "";
            SliceOfTime queryTime = TimeUtil.getQueryTime(time);
            if (time.contains("-")) {
                flag = "日";
            } else if (time.contains("时")) {
                flag = "时";
            }
            QueryModel model = new QueryModel(queryTime, state, flag);
            //根据时间及舰船状态查询相关舰船

            List<ObjectShipBasicInfoEntity> ships = statisticsDao.queryShipsByStateAndTime(model);

            for (ObjectShipBasicInfoEntity ship : ships) {
                Integer shipID = ship.getId();
                ShipAndEvents shipAndEvents = new ShipAndEvents();
                shipAndEvents.setShip(ship);

                //查询舰船对应事件
                QueryModel model1 = new QueryModel(queryTime, state, flag, shipID);
                List<ObjectEventOutput> events = statisticsDao.queryEventsByStateAndTimeAndShipID(model1);
                shipAndEvents.setEvents(events);
                list.add(shipAndEvents);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return list;
        }

    }

    //根据事件uuid查询事件对应人物、舰船、基地简要信息
    @Override
    public EventAllMsgs queryExtraMessageBrieflyByUUID(ExtraMessageQueryInput input) throws RuntimeException{
        String uuid = input.getUuid();
        if(StringUtils.isEmpty(uuid)){
            return null;
        }

        try {
            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关人物
            List<SimpleModel> personList = statisticsDao.querySimplePersonByUUID(uuid);

            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关舰船
            List<SimpleModel> shipList = statisticsDao.querySimpleShipByUUID(uuid);

            //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关基地
            List<SimpleModel> baseList = statisticsDao.querySimpleBaseByUUID(uuid);

            EventAllMsgs eventAllMsgs = new EventAllMsgs(personList,shipList,baseList);

            return eventAllMsgs;
        } catch (RuntimeException e) {
            throw  new RuntimeException("操作失败");
        }
    }

    //西太地区：根据事件类型及基地id查询相关事件
    @Override
    public List<EventAllMsgs> queryEventsByTypeAndBaseID(EventQueryByIDAndTime input) throws RuntimeException {
        if(input.getId()==0||input.getType()==null){
            return null;
        }
        try {
            List<EventAllMsgs> list=statisticsDao.queryEventsByTypeAndBaseID(input);
            return list;
        } catch (Exception e) {
           throw new RuntimeException("操作失败");
        }
    }

    @Override
    public List<EventAllMsgs> statisticsMostEventsOfViewed() {

        return statisticsDao.statisticsMostEventsOfViewed();
    }

    //热词排序
    public static void order(List<HotWord> words) {
        Collections.sort(words, new Comparator<HotWord>() {

            public int compare(HotWord h1, HotWord h2) {
                //按照Person的年龄进行升序排列
                if (h1.getNum() > h2.getNum()) {
                    return 1;
                }
                if (h1.getNum() == h2.getNum()) {
                    return 0;
                }
                return -1;
            }
        });

        Collections.reverse(words);
    }

    public static void main(String[] args) {
        List<SliceOfTime> sliceOfTime = TimeUtil.getSliceOfTime("3Day");
        sliceOfTime.forEach(a -> System.out.println(a));
        //System.out.println(TimeUtil.getSliceOfTime("7Day"));

    }


}


