package com.cetc54.zkb.ky.constraint;

/**
 * 说明: 错误响应信息
 * <br>UpdateNote:
 * <br>UpdateTime:
 * <br>UpdateUser:
 */
public class ErrorResponse extends Response{


    /**
     * 错误码描述
     */
    private String errorMsg;

    public ErrorResponse(String errorCode, String errorMsg) {
        super.setCode(errorCode);
        this.errorMsg = errorMsg;
    }


    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
