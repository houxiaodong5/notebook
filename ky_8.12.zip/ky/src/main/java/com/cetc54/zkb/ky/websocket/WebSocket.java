package com.cetc54.zkb.ky.websocket;


import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.servlet.http.HttpServletRequest;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.controller.EventController;
import com.cetc54.zkb.ky.controller.NewsController;
import com.cetc54.zkb.ky.controller.TwitterController;
import com.cetc54.zkb.ky.controller.output.event.EventAllMessageOutput;
import com.cetc54.zkb.ky.controller.output.event.EventAndNewsOutput;
import com.cetc54.zkb.ky.util.YjsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@ServerEndpoint("/websocket")
@Component
public class WebSocket extends BaseController {
    private static Logger logger= LoggerFactory.getLogger(WebSocket.class);
    private  ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
    private static ExecutorService pool = Executors.newFixedThreadPool(10);


    //静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
    private static int onlineCount = 0;
    //concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。
    private static CopyOnWriteArraySet<WebSocket> webSocketSet = new CopyOnWriteArraySet<>();

    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;
    private String time;
    private static CopyOnWriteArraySet<Session> set= new CopyOnWriteArraySet<>();

    //接收sid
    //private String sid = "";

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session) {
        logger.info("连接已建立");
        try {
            this.session = session;
            set.add(session);
            webSocketSet.add(this);     //加入set中
            addOnlineCount();           //在线数加1
        } catch (Exception e) {
            logger.error("websocket发生错误");
        }
    }

    //定时发送(5s)
    @Scheduled(fixedRate = 1000 * 5)
    public void sendMSG() {
        if(set.size()==0){
            return;
        }
        List<EventAllMessageOutput> outputDataResponse=EventController.list;
        if (outputDataResponse==null){
            return;
        }
        EventAndNewsOutput eventAndNewsOutput = new EventAndNewsOutput();
        for (Session session:set ) {
            try {
                //发送事件及爬取日志
                for (EventAllMessageOutput output : outputDataResponse) {
                    //注释：只发送实时数据  无最新数据不发送
                    //设置事件
                    if (!map.containsKey(output.getId()+"-"+session.getId())) {
                        eventAndNewsOutput.setEventOutput(output);
                        map.put(output.getId()+"-"+session.getId(), output.getId()+"-"+session.getId());
                    } else {
                        eventAndNewsOutput.setEventOutput(null);
                    }
              /*  //重复发送最新数据1000条，
                eventAndNewsOutput.setEventOutput(output);*/

                    //设置news
                    if (NewsController.newsEntitrie != null && !map.containsKey(NewsController.newsEntitrie.getId() + session.getId())) {
                        eventAndNewsOutput.setNewsEntitry(NewsController.newsEntitrie);

                        map.put(NewsController.newsEntitrie.getId() + session.getId(), String.valueOf(NewsController.newsEntitrie.getId()));
                    } else {
                        eventAndNewsOutput.setNewsEntitry(null);
                    }

                    //设置推特体

                    if (TwitterController.twitterOutput != null && !map.containsKey(TwitterController.twitterOutput.getVc_id() + session.getId())) {
                        eventAndNewsOutput.setTwitterOutput(TwitterController.twitterOutput);

                        map.put(TwitterController.twitterOutput.getVc_id() + session.getId(), TwitterController.twitterOutput.getVc_id());
                    } else {
                        eventAndNewsOutput.setTwitterOutput(null);
                    }

                    if (eventAndNewsOutput.getNewsEntitry() == null && eventAndNewsOutput.getEventOutput() == null&&eventAndNewsOutput.getTwitterOutput()==null) {
                        continue;
                    }


                    synchronized (this) {
                        if (session!=null&&session.isOpen()) {
                            //eventAndNewsOutput.setTwitterOutput(TwitterController.twitterOutput);
                            sendMessage(session, YjsonUtil.toJson(this.success(eventAndNewsOutput)));
                        } else {
                            return;
                        }
                    }

                }
            } catch (Exception e) {
                logger.error("websocket发送数据失败");
            }

        }


    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose(Session session) {
        webSocketSet.remove(this);  //从set中删除
        set.remove(session);
        map.clear();
        subOnlineCount();           //在线数减1
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        //群发消息
       /* for (WebSocket item : webSocketSet) {
            try {
                item.sendMessage(session,message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }*/
    }

    /**
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    /**
     * 实现服务器主动推送
     */
    public void sendMessage(Session session, String message) throws IOException {
        try {

            if (session.isOpen()) {
                session.getBasicRemote().sendText(message);
            }

        } catch (Exception e) {
         //   throw new IOException("发送失败");
        }
    }


    /**
     * 群发自定义消息
     */
    public static void sendInfo(String message, @PathParam("sid") String sid) throws IOException {

    }

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        WebSocket.onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        WebSocket.onlineCount--;
    }






}

