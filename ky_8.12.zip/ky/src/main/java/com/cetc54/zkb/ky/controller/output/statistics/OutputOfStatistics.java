package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
import java.util.List;

/**
 *      人员、基地、舰船统计输出数据
 * */
public class OutputOfStatistics implements Serializable {

    private List<Long> nums;//出现次数
    private List<String> name;//名字
    private List<Long> ids;//id
    private String type="";

    public List<Long> getNums() {
        return nums;
    }

    public void setNums(List<Long> nums) {
        this.nums = nums;
    }

    public List<String> getName() {
        return name;
    }

    public void setName(List<String> name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return "OutputOfStatistics{" +
                "nums=" + nums +
                ", name=" + name +
                ", ids=" + ids +
                ", type='" + type + '\'' +
                '}';
    }
}
