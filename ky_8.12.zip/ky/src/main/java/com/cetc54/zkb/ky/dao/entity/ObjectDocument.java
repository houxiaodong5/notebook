package com.cetc54.zkb.ky.dao.entity;

public class ObjectDocument {
    private int nm_id;
    private String vc_origin="";
    private String vc_pageUrl="";
    private String vc_title="";
    private String vc_publishDate="";
    private String cl_content="";
    private String vc_keyword="";
    private String vc_fileName="";
    private String vc_filePath="";

    public int getNm_id() {
        return nm_id;
    }

    public void setNm_id(int nm_id) {
        this.nm_id = nm_id;
    }

    public String getVc_origin() {
        return vc_origin;
    }

    public void setVc_origin(String vc_origin) {
        this.vc_origin = vc_origin;
    }

    public String getVc_pageUrl() {
        return vc_pageUrl;
    }

    public void setVc_pageUrl(String vc_pageUrl) {
        this.vc_pageUrl = vc_pageUrl;
    }

    public String getVc_title() {
        return vc_title;
    }

    public void setVc_title(String vc_title) {
        this.vc_title = vc_title;
    }

    public String getVc_publishDate() {
        return vc_publishDate;
    }

    public void setVc_publishDate(String vc_publishDate) {
        this.vc_publishDate = vc_publishDate;
    }

    public String getCl_content() {
        return cl_content;
    }

    public void setCl_content(String cl_content) {
        this.cl_content = cl_content;
    }

    public String getVc_keyword() {
        return vc_keyword;
    }

    public void setVc_keyword(String vc_keyword) {
        this.vc_keyword = vc_keyword;
    }

    public String getVc_fileName() {
        return vc_fileName;
    }

    public void setVc_fileName(String vc_fileName) {
        this.vc_fileName = vc_fileName;
    }

    public String getVc_filePath() {
        return vc_filePath;
    }

    public void setVc_filePath(String vc_filePath) {
        this.vc_filePath = vc_filePath;
    }

    @Override
    public String toString() {
        return "ObjectDocument{" +
                "nm_id=" + nm_id +
                ", vc_origin='" + vc_origin + '\'' +
                ", vc_pageUrl='" + vc_pageUrl + '\'' +
                ", vc_title='" + vc_title + '\'' +
                ", vc_publishDate='" + vc_publishDate + '\'' +
                ", cl_content='" + cl_content + '\'' +
                ", vc_keyword='" + vc_keyword + '\'' +
                ", vc_fileName='" + vc_fileName + '\'' +
                ", vc_filePath='" + vc_filePath + '\'' +
                '}';
    }
}
