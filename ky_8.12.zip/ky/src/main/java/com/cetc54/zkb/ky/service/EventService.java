package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.*;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.event.*;
import com.cetc54.zkb.ky.dao.sql.EventSql;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.SelectProvider;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashSet;
import java.util.List;

/**
 * 事件service
 * */
public interface EventService {

    /**
     * 查询所有事件
     * */
    List<EventAllMessageOutput> queryAllEvent();

    /**
     * 查询所有事件等级
     * */
    List<String> queryAllEventGrade();

    /**
     * 查询所有事件类型
     * */
    List<String> queryAllEventType();

    /**
     * 根据事件类型及年、月、周统计
     * */
    List<EventTimeStatisticListOutput> statisticEventByTimeType(StatisticEventByTimeInput input);

    /**
     * 根据不同条件统计事件总数、实时推送、当天事件
     * */
    List<EventStatisticOutput> statisticEvent();

    /**
     * 查询当天事件
     * */
    List<ObjectEventOutput> queryEventToday();

    /**
     * 根据事件ID查询事件详情
     * */
    List<ObjectEventOutput> queryEventById(String eventId);

    /**
     * 通过条件查询事件
     * */
    //EventQueryOutput queryEvent(EventQueryInput input);
    List<EventQueryOutput2> queryEvent(EventQueryInput input);

    List<String> queryAllWxdj();

    //通过事件类型统计
    EventStatisticByTypeOutput statisticByEventType();

    //用户为事件自定义标签
    String diyTagForEvent(EventTagInput input);

    //根据时间查询事件
    List<ObjectEventOutput> queryEventByTime1(EventQueryInput input);

    //根据时间查询事件
    PageInfo<ObjectEventOutput> queryEventByTime(EventQueryByPage input);

    //根据标签查询事件
    List<ObjectEventOutput> queryEventByTag(String tag);

    //查询最新事件(5条)
    List<EventAllMessageOutput> queryLatestEvent();
    List<EventAllMessageOutput> queryLatestEventNOFitlter();//不过滤经纬度查询最新事件

    //分页查询最新事件(前500条,不过滤)
    PageInfo<EventAllMessageOutput> queryAllEventByPage(QueryByPage page);

    //根据事件类型及事件地点查询事件
    PageInfo<ObjectEventOutput> queryEventByLocationAndEventType(EventQueryByPage input);

    PageInfo<ObjectEventOutput> queryEventByDatasource(EventQueryByDataSource input);

    List<ObjectEventOutput> queryEventByIDAndTime(EventQueryByIDAndTime input);

    //西太地区所有事件按事件类型分类
    List<EventOutputGroupByType> queryEventGroupByType();
}
