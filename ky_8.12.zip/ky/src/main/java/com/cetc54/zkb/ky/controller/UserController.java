package com.cetc54.zkb.ky.controller;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSBuilder;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ListObjectsRequest;
import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.user.UserInput;
import com.cetc54.zkb.ky.controller.input.user.UserViewRecord;
import com.cetc54.zkb.ky.controller.output.user.UserOutput;
import com.cetc54.zkb.ky.service.UserService;
import com.cetc54.zkb.ky.util.OSSUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.reflections.vfs.Vfs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.UUID;

@RestController
@Api("用户相关接口")
public class UserController extends BaseController {
    @Autowired
    private UserService userService;
    static final String bucketName="ky-user";//此bucket专门用于存储系统用户数据
    /*static final String endpoint = "http://oss-cn-beijing.aliyuncs.com";
    static final String accessKeyId = "LTAIPXgyNU8AYp37";
    static final String accessKeySecret = "4rAsy9byTBIhwO2c4wUKo8zBtfh99u";
    static final String bucketName="ky-user";
    static final String folderNode="img/";//OSS中要存储的文件夹*/

    @ApiOperation("用户注册")
    @PostMapping("/user/register")
    public DataResponse<String> registerUser(@RequestBody UserInput input){

        return this.success(userService.registerUser(input));
    }

    @ApiOperation("用户登录")
    @PostMapping("/user/login")
    public DataResponse<UserOutput> login(HttpServletRequest request,@RequestBody UserInput input){
        try {
            UserOutput userOutput = userService.login(request, input);
            return this.success(userOutput==null?"用户名和密码不可为空":userOutput);
        } catch (Exception e) {
            return this.success(e.getMessage());
        }

    }

    @ApiOperation("用户登出")
    @PostMapping("/user/logout")
    public DataResponse<String> logout(HttpServletRequest request){
            return this.success(userService.logout(request)==true?"您已安全退出":"操作失败");

    }

    @ApiOperation("修改用户头像")
    @PostMapping(value = "/user/update/img",headers = "content-type=multipart/form-data")
    public DataResponse<Object> userUpdateImg( @RequestParam(value = "id") int id, @RequestParam(value = "file") MultipartFile file) {
        if (file.isEmpty()) {
            return this.success("图片不可为空");
        }

        try {
            String ossUrl = OSSUtil.updateImgToOSS(bucketName,"img/",file);
            return this.success("上传成功");
        } catch (Exception e) {
            e.printStackTrace();
            return this.success("操作失败");
        }

    }

    @ApiOperation("用户观看新闻记录")
    @PostMapping("/user/view/record")
    public DataResponse<String> userViewRecord(@RequestBody UserViewRecord userViewRecord){
        try {
            return this.success(userService.userViewRecord(userViewRecord));
        } catch (Exception e) {
            return this.success(e.getMessage());
        }
    }


}
