package com.cetc54.zkb.ky.elasticsearch.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import java.io.Serializable;

@Document(indexName = "kaiyuan", type = "person")
public class Person implements Serializable {
    @Id
    private String renwuid;
    private String zwxm="";
    private String ywxm="";
    private String first_name="";
    private String last_name="";
    private String two_word_name="";
    private String jx="";
    private String jx_cn="";
    private String zw_cn="";
    private String zw="";
    private String rzsj="";
    private String csd="";
    private String zylb="";
    private String txszwj="";
    private String ssjg="";
    private String  ssjgid;
    private String sjzh="";
    private String rylb="";
    private String zjxy="";
    private String rwmbtz="";
    private String gj="";
    private String gj_cn="";
    private String gz="";
    private String jj="";
    private String jy="";
    private String fxjl="";
    private String jiangxiang="";
    private String cj="";
    private String tx="";
    private String lj="";
    private Integer gdb_used;
    private String yxrq="";
    private String rksj="";
    private String txpic;
    private String shgx="";

    public String getRenwuid() {
        return renwuid;
    }

    public void setRenwuid(String renwuid) {
        this.renwuid = renwuid;
    }

    public String getZwxm() {
        return zwxm;
    }

    public void setZwxm(String zwxm) {
        this.zwxm = zwxm;
    }

    public String getYwxm() {
        return ywxm;
    }

    public void setYwxm(String ywxm) {
        this.ywxm = ywxm;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getTwo_word_name() {
        return two_word_name;
    }

    public void setTwo_word_name(String two_word_name) {
        this.two_word_name = two_word_name;
    }

    public String getJx() {
        return jx;
    }

    public void setJx(String jx) {
        this.jx = jx;
    }

    public String getJx_cn() {
        return jx_cn;
    }

    public void setJx_cn(String jx_cn) {
        this.jx_cn = jx_cn;
    }

    public String getZw_cn() {
        return zw_cn;
    }

    public void setZw_cn(String zw_cn) {
        this.zw_cn = zw_cn;
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    public String getRzsj() {
        return rzsj;
    }

    public void setRzsj(String rzsj) {
        this.rzsj = rzsj;
    }

    public String getCsd() {
        return csd;
    }

    public void setCsd(String csd) {
        this.csd = csd;
    }

    public String getZylb() {
        return zylb;
    }

    public void setZylb(String zylb) {
        this.zylb = zylb;
    }

    public String getTxszwj() {
        return txszwj;
    }

    public void setTxszwj(String txszwj) {
        this.txszwj = txszwj;
    }

    public String getSsjg() {
        return ssjg;
    }

    public void setSsjg(String ssjg) {
        this.ssjg = ssjg;
    }

    public String getSsjgid() {
        return ssjgid;
    }

    public void setSsjgid(String ssjgid) {
        this.ssjgid = ssjgid;
    }

    public String getSjzh() {
        return sjzh;
    }

    public void setSjzh(String sjzh) {
        this.sjzh = sjzh;
    }

    public String getRylb() {
        return rylb;
    }

    public void setRylb(String rylb) {
        this.rylb = rylb;
    }

    public String getZjxy() {
        return zjxy;
    }

    public void setZjxy(String zjxy) {
        this.zjxy = zjxy;
    }

    public String getRwmbtz() {
        return rwmbtz;
    }

    public void setRwmbtz(String rwmbtz) {
        this.rwmbtz = rwmbtz;
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj;
    }

    public String getGj_cn() {
        return gj_cn;
    }

    public void setGj_cn(String gj_cn) {
        this.gj_cn = gj_cn;
    }

    public String getGz() {
        return gz;
    }

    public void setGz(String gz) {
        this.gz = gz;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getJy() {
        return jy;
    }

    public void setJy(String jy) {
        this.jy = jy;
    }

    public String getFxjl() {
        return fxjl;
    }

    public void setFxjl(String fxjl) {
        this.fxjl = fxjl;
    }

    public String getJiangxiang() {
        return jiangxiang;
    }

    public void setJiangxiang(String jiangxiang) {
        this.jiangxiang = jiangxiang;
    }

    public String getCj() {
        return cj;
    }

    public void setCj(String cj) {
        this.cj = cj;
    }

    public String getTx() {
        return tx;
    }

    public void setTx(String tx) {
        this.tx = tx;
    }

    public String getLj() {
        return lj;
    }

    public void setLj(String lj) {
        this.lj = lj;
    }

    public Integer getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(Integer gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getYxrq() {
        return yxrq;
    }

    public void setYxrq(String yxrq) {
        this.yxrq = yxrq;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = rksj;
    }

    public String getTxpic() {
        return txpic;
    }

    public void setTxpic(String txpic) {
        this.txpic = txpic;
    }

    public String getShgx() {
        return shgx;
    }

    public void setShgx(String shgx) {
        this.shgx = shgx;
    }

    @Override
    public String toString() {
        return "Person{" +
                "renwuid='" + renwuid + '\'' +
                ", zwxm='" + zwxm + '\'' +
                ", ywxm='" + ywxm + '\'' +
                ", first_name='" + first_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", two_word_name='" + two_word_name + '\'' +
                ", jx='" + jx + '\'' +
                ", jx_cn='" + jx_cn + '\'' +
                ", zw_cn='" + zw_cn + '\'' +
                ", zw='" + zw + '\'' +
                ", rzsj='" + rzsj + '\'' +
                ", csd='" + csd + '\'' +
                ", zylb='" + zylb + '\'' +
                ", txszwj='" + txszwj + '\'' +
                ", ssjg='" + ssjg + '\'' +
                ", ssjgid='" + ssjgid + '\'' +
                ", sjzh='" + sjzh + '\'' +
                ", rylb='" + rylb + '\'' +
                ", zjxy='" + zjxy + '\'' +
                ", rwmbtz='" + rwmbtz + '\'' +
                ", gj='" + gj + '\'' +
                ", gj_cn='" + gj_cn + '\'' +
                ", gz='" + gz + '\'' +
                ", jj='" + jj + '\'' +
                ", jy='" + jy + '\'' +
                ", fxjl='" + fxjl + '\'' +
                ", jiangxiang='" + jiangxiang + '\'' +
                ", cj='" + cj + '\'' +
                ", tx='" + tx + '\'' +
                ", lj='" + lj + '\'' +
                ", gdb_used=" + gdb_used +
                ", yxrq='" + yxrq + '\'' +
                ", rksj='" + rksj + '\'' +
                ", txpic=" + txpic +
                ", shgx='" + shgx + '\'' +
                '}';
    }
}
