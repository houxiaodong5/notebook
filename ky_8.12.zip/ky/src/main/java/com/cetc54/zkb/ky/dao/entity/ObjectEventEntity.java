package com.cetc54.zkb.ky.dao.entity;


import java.util.Date;

/**
* Description: object_event(事件) 实体类.<br/>
* Author: lhx.<br/>
* Version: 1.0 <br/>
* CreateTime: 2019年05月14日 22:09:54.<br/>
* <br/>UpdateTime: 
* <br/>UpdateUser: 
* <br/>UpdateNote: 
* <br/>------------------------------*/
public class ObjectEventEntity{
	private Long id;
	private String uuid;
	private String bt;
	private String jj;
	private String gjc;
	private Date fssj;
	private Date jssj;
	private String zbwd;
	private String zbjd;
	private String tag1="";
	private String tag2="";
	private String tag3="";
	private String gjmc;
	private String gjid;
	private String dd;
	private String wxdj;
	private Date rksj;
	private Long gdbUsed;

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return this.id;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getUuid() {
		return this.uuid;
	}

	public void setBt(String bt) {
		this.bt = bt;
	}

	public String getBt() {
		return this.bt;
	}

	public void setJj(String jj) {
		this.jj = jj;
	}

	public String getJj() {
		return this.jj;
	}

	public void setGjc(String gjc) {
		this.gjc = gjc;
	}

	public String getGjc() {
		return this.gjc;
	}

	public void setFssj(Date fssj) {
		this.fssj = fssj;
	}

	public Date getFssj() {
		return this.fssj;
	}

	public void setJssj(Date jssj) {
		this.jssj = jssj;
	}

	public Date getJssj() {
		return this.jssj;
	}

	public void setZbwd(String zbwd) {
		this.zbwd = zbwd;
	}

	public String getZbwd() {
		return this.zbwd;
	}

	public void setZbjd(String zbjd) {
		this.zbjd = zbjd;
	}

	public String getZbjd() {
		return this.zbjd;
	}

	public void setTag1(String tag1) {
		this.tag1 = tag1;
	}

	public String getTag1() {
		return this.tag1;
	}

	public void setTag2(String tag2) {
		this.tag2 = tag2;
	}

	public String getTag2() {
		return this.tag2;
	}

	public void setTag3(String tag3) {
		this.tag3 = tag3;
	}

	public String getTag3() {
		return this.tag3;
	}

	public void setGjmc(String gjmc) {
		this.gjmc = gjmc;
	}

	public String getGjmc() {
		return this.gjmc;
	}

	public void setGjid(String gjid) {
		this.gjid = gjid;
	}

	public String getGjid() {
		return this.gjid;
	}

	public void setDd(String dd) {
		this.dd = dd;
	}

	public String getDd() {
		return this.dd;
	}

	public void setWxdj(String wxdj) {
		this.wxdj = wxdj;
	}

	public String getWxdj() {
		return this.wxdj;
	}

	public void setRksj(Date rksj) {
		this.rksj = rksj;
	}

	public Date getRksj() {
		return this.rksj;
	}

	public void setGdbUsed(Long gdbUsed) {
		this.gdbUsed = gdbUsed;
	}

	public Long getGdbUsed() {
		return this.gdbUsed;
	}
}

