package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;

/**
 *      用户查看事件记录：对应relation_ky_user_event
 * */
public class UserViewRecordEntity implements Serializable {
    private int id;
    private int userID;
    private String eventID;
    private int viewNumber;
    private String updateTime;
    private String eventType;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public int getViewNumber() {
        return viewNumber;
    }

    public void setViewNumber(int viewNumber) {
        this.viewNumber = viewNumber;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = TimeUtil.formateStringTime(updateTime);
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @Override
    public String toString() {
        return "UserViewRecordEntity{" +
                "id=" + id +
                ", userID=" + userID +
                ", eventID='" + eventID + '\'' +
                ", viewNumber=" + viewNumber +
                ", updateTime='" + updateTime + '\'' +
                ", eventType='" + eventType + '\'' +
                '}';
    }
}
