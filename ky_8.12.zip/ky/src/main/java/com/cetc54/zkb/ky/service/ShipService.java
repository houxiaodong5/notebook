package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.controller.input.person.QueryPersonOrShipsInput;
import com.cetc54.zkb.ky.controller.input.ship.BaseShipInput;
import com.cetc54.zkb.ky.controller.input.ship.BaseShipMsg;
import com.cetc54.zkb.ky.controller.input.ship.StatisticShipByBaseInput;
import com.cetc54.zkb.ky.controller.output.ship.*;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;

import java.util.List;

/**
 * 舰船service
 * */
public interface ShipService {

    /**
     * 基地在港舰船及事件情况统计
     * */
    List<ShipAndEventTodayStatisticOutput> shipAndEventStatistic(String time);

    /**
     * 统计今日舰船在港、进港、离港总数
     * */
    ShipTodayStatisticOutput shipTodayStatistic();

    /**
     * 按年、月、周及基地ID统计舰船情况
     * */
    List<ShipTimeStatisticOutput> statisticShipByBase(StatisticShipByBaseInput input);

    /**
     * 查询舰船在当前时间到选择时间的轨迹
     * */
    List<ShipTrajectoryOutput> queryShipTrajectory(String time);

    /**
     *  根据港口、在港状态查询船舶详情
     * */
    List<ObjectShipBasicInfoEntity> queryShipByBase(BaseShipInput input);

    //根据船舶id查询船舶信息--林肯
    ObjectShipBasicInfoEntity queryShipByID(BaseShipMsg baseShipMsg);
    ObjectShipBasicInfoEntity queryShipByIDForOther(BaseShipMsg baseShipMsg);

    List<ShipAllEvents> queryAllShipEvents();
    List<ShipEvent> queryAllShipEvents_NEW();

    List<ObjectShipBasicInfoEntity> queryShipsByIDs(QueryPersonOrShipsInput input);
}
