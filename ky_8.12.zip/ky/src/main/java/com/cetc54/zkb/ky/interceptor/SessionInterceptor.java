/*
package com.cetc54.zkb.ky.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

*/
/**
 *          自定义拦截器，对非登录，注册的请求进行拦截
 * *//*


public class SessionInterceptor implements HandlerInterceptor {
    private static List<String>  ALLOW_URL=new ArrayList<>();
    static {
        ALLOW_URL.add("/user/login");
        ALLOW_URL.add("/user/register");
        ALLOW_URL.add("/swagger-ui.html");
        ALLOW_URL.add("/webjars/**");
        ALLOW_URL.add("/v2/**");
        ALLOW_URL.add("/swagger-resources");
    }
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        // 登录注册不做拦截
        //System.out.println(request.getRequestURI());

 if(request.getRequestURI().equals("/user/login") || request.getRequestURI().equals("/user/register")||request.getRequestURI().equals("/v2/api-docs")){
            return true;
        }

        if(ALLOW_URL.contains(request.getRequestURI())){
            return true;
        }
        if(request.getRequestURI().contains("/swagger-resources")){
            return true;
        }

        // 验证session是否存在
        Object obj = request.getSession().getAttribute("user");
        if(obj == null){
            return false;
        }
        return true;

    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
*/
