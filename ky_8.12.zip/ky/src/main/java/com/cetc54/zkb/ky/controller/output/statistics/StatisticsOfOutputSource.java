package com.cetc54.zkb.ky.controller.output.statistics;

import com.cetc54.zkb.ky.controller.output.source.OutputSource;

public class StatisticsOfOutputSource extends OutputSource {
    private Long count;

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "StatisticsOfOutputSource{" +
                "count=" + count +
                '}';
    }
}
