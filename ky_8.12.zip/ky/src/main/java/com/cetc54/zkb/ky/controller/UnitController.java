package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.output.unit.SimpleUnitPersonOutput;
import com.cetc54.zkb.ky.controller.output.unit.UnitInfoOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;
import com.cetc54.zkb.ky.service.UnitService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 *      联队controller
 * */
@Api("联队controller")
@RestController
public class UnitController extends BaseController {

    @Autowired
    private UnitService unitService;


    @ApiOperation("查询联队详情")
    @GetMapping({"/query/unit/message"})
    @ApiImplicitParam(name = "unitID", value = "联队id：unitID")
    public DataResponse<UnitInfoOutput> queryUnitMsgByUnitID(int unitID){
        return this.success(unitService.queryUnitMsgByUnitID(unitID));
    }

    @ApiOperation("根据军官id查询联队军官信息")
    @GetMapping({"/query/commander/message"})
    @ApiImplicitParam(name = "id", value = "军官id")
    public DataResponse<ObjectPerson> queryCommanderMsg(int id){
        return this.success(unitService.queryCommanderMsg(id));
    }

    //@ApiOperation("更新IMG")   修正库中数据：请勿调用！！！
    //@GetMapping({"/update/tx"})
    public void uodatePersonImg(){
         unitService.uodatePersonImg();
    }

    @ApiOperation("展示联队军官层级关系  基于联队")
    @GetMapping({"/query/person/relation"})
    @ApiImplicitParam(name = "unitID", value = "联队id")
    public DataResponse<List<SimpleUnitPersonOutput>> queryPersonRelation(int unitID){

        return this.success(unitService.queryPersonRelation(unitID));
    }

    @ApiOperation("展示联队军官层级关系  基于军官")
    @GetMapping({"/query/person/relation/based/person"})
    @ApiImplicitParam(name = "personID", value = "军官ID")
    public DataResponse<List<SimpleUnitPersonOutput>> queryPersonRelationBasedPerson(int personID){

        return this.success(unitService.queryPersonRelationBasedPerson(personID));
    }


}
