package com.cetc54.zkb.ky.controller.input.ship;

import java.util.Date;

public class ObjectShipOutput {
    private Long id;
    private String mc;
    private String lx;
    private String jb;
    private String bh;
    private Date fysj;
    private String ssbd;
    private String tptz;
    private String tp;
    private String jj;
    private Date ccrq;
    private Date xssj;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getMc() {
        return this.mc;
    }

    public void setLx(String lx) {
        this.lx = lx;
    }

    public String getLx() {
        return this.lx;
    }

    public void setJb(String jb) {
        this.jb = jb;
    }

    public String getJb() {
        return this.jb;
    }

    public void setBh(String bh) {
        this.bh = bh;
    }

    public String getBh() {
        return this.bh;
    }

    public void setFysj(Date fysj) {
        this.fysj = fysj;
    }

    public Date getFysj() {
        return this.fysj;
    }

    public void setSsbd(String ssbd) {
        this.ssbd = ssbd;
    }

    public String getSsbd() {
        return this.ssbd;
    }

    public void setTptz(String tptz) {
        this.tptz = tptz;
    }

    public String getTptz() {
        return this.tptz;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getTp() {
        return this.tp;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getJj() {
        return this.jj;
    }

    public void setCcrq(Date ccrq) {
        this.ccrq = ccrq;
    }

    public Date getCcrq() {
        return this.ccrq;
    }

    public void setXssj(Date xssj) {
        this.xssj = xssj;
    }

    public Date getXssj() {
        return this.xssj;
    }
}
