package com.cetc54.zkb.ky.controller.output.person;

import java.util.HashSet;
import java.util.List;
/**
 *          人物筛选条件
 * */
public class ConditionsOfFilter {
    private HashSet<String> country;//国家
    private HashSet<String> country_CN;//国家
    private HashSet<String> militaryRank;//军衔
    private HashSet<String> militaryRank_CN;//军衔
    private HashSet<String> post;//职务
    private HashSet<String> post_CN;//职务
    private HashSet<String> category;//类别

    public HashSet<String> getCountry() {
        return country;
    }

    public void setCountry(HashSet<String> country) {
        this.country = country;
    }

    public HashSet<String> getCountry_CN() {
        return country_CN;
    }

    public void setCountry_CN(HashSet<String> country_CN) {
        this.country_CN = country_CN;
    }

    public HashSet<String> getMilitaryRank() {
        return militaryRank;
    }

    public void setMilitaryRank(HashSet<String> militaryRank) {
        this.militaryRank = militaryRank;
    }

    public HashSet<String> getMilitaryRank_CN() {
        return militaryRank_CN;
    }

    public void setMilitaryRank_CN(HashSet<String> militaryRank_CN) {
        this.militaryRank_CN = militaryRank_CN;
    }

    public HashSet<String> getPost() {
        return post;
    }

    public void setPost(HashSet<String> post) {
        this.post = post;
    }

    public HashSet<String> getPost_CN() {
        return post_CN;
    }

    public void setPost_CN(HashSet<String> post_CN) {
        this.post_CN = post_CN;
    }

    public HashSet<String> getCategory() {
        return category;
    }

    public void setCategory(HashSet<String> category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "ConditionsOfFilter{" +
                "country=" + country +
                ", country_CN=" + country_CN +
                ", militaryRank=" + militaryRank +
                ", militaryRank_CN=" + militaryRank_CN +
                ", post=" + post +
                ", post_CN=" + post_CN +
                ", category=" + category +
                '}';
    }
}
