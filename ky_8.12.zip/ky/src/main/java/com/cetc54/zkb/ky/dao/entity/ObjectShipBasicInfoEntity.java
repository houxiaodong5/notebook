package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;
import java.util.Arrays;

/**
 *      table:  object_ship_basic_info  传播基础信息表，信息较全
 * */
public class ObjectShipBasicInfoEntity implements Serializable {
    private int id;//'舰船ID'
    private String mc;//名称
    private String bh;//编号
    private String jj;//'简介'
    private String tp;//'图片链接'
    private String ssgj;//'所属国家'
    private String jc;//简称
    private String pzrq;//'批准日期'
    private String jzz;//'建造者'
    private String cb;//'成本'
    private String jzrq;//'建造日期'
    private String ccrq;//'出厂时间'  *
    private String xssj;//'下水时间'    *
    private String cmm;//'重命名'
    private String zzz;//'赞助者'
    private String fysj;//'服役时间'    *
    private String tyrq;//'退役日期'
    private String mg;//'母港'
    private String hh;//'呼号'
    private String zym;//'座右铭'
    private String nc;//'昵称,多个昵称之间使用分号(;)隔开'
    private String ryjx;//'荣誉奖项'
    private String my;//'命运'
    private String zt;//'状态'
    private String hz;//'徽章'
    private String lx;//'类型'
    private String lb;//'类别'
    private String ds;//'吨数'
    private String psl;//'排水量'
    private String cd;//'长度'
    private String kd;//'宽度'
    private String gd;//'高度'
    private String cssd;//'吃水深度'
    private String zjdl;//'装机动力'
    private String jb;//'装甲，船身和关键部件的厚度'
    private String dl;//'动力'
    private String sd;//'速度'
    private String jbcc;//'甲板尺寸'
    private String xhl;//'续航距离'
    private String qt;//'其他'
    private String qtry;//'全体人员'
    private String zsxt;//'侦搜系统'
    private String fyxt;//'防御系统'
    private String wqzb;//'武器装备'
    private String fydj;//'防御等级'
    private String xdcz;//'携带船只'
    private String jzj;//'舰载机'
    private String rksj;//'入库时间'    *
    private String ywmc;//'英文名称'
    private String zxzb;//'最新坐标'
    private byte[] tpBlob;//'图片'
    private int bridgeID;//'object_ship中舰船ID'   弃
    private int gdbUsed;//'gdb_used'

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMc() {
        return mc;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getBh() {
        return bh;
    }

    public void setBh(String bh) {
        this.bh = bh;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getTp() {
        return tp;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getSsgj() {
        return ssgj;
    }

    public void setSsgj(String ssgj) {
        this.ssgj = ssgj;
    }

    public String getJc() {
        return jc;
    }

    public void setJc(String jc) {
        this.jc = jc;
    }

    public String getPzrq() {
        return pzrq;
    }

    public void setPzrq(String pzrq) {
        this.pzrq = pzrq;
    }

    public String getJzz() {
        return jzz;
    }

    public void setJzz(String jzz) {
        this.jzz = jzz;
    }

    public String getCb() {
        return cb;
    }

    public void setCb(String cb) {
        this.cb = cb;
    }

    public String getJzrq() {
        return jzrq;
    }

    public void setJzrq(String jzrq) {
        this.jzrq = jzrq;
    }

    public String getCcrq() {
        return ccrq;
    }

    public void setCcrq(String ccrq) {
        this.ccrq = ccrq;
    }

    public String getXssj() {
        return xssj;
    }

    public void setXssj(String xssj) {
        this.xssj = xssj;
    }

    public String getCmm() {
        return cmm;
    }

    public void setCmm(String cmm) {
        this.cmm = cmm;
    }

    public String getZzz() {
        return zzz;
    }

    public void setZzz(String zzz) {
        this.zzz = zzz;
    }

    public String getFysj() {
        return fysj;
    }

    public void setFysj(String fysj) {
        this.fysj = fysj;
    }

    public String getTyrq() {
        return tyrq;
    }

    public void setTyrq(String tyrq) {
        this.tyrq = tyrq;
    }

    public String getMg() {
        return mg;
    }

    public void setMg(String mg) {
        this.mg = mg;
    }

    public String getHh() {
        return hh;
    }

    public void setHh(String hh) {
        this.hh = hh;
    }

    public String getZym() {
        return zym;
    }

    public void setZym(String zym) {
        this.zym = zym;
    }

    public String getNc() {
        return nc;
    }

    public void setNc(String nc) {
        this.nc = nc;
    }

    public String getRyjx() {
        return ryjx;
    }

    public void setRyjx(String ryjx) {
        this.ryjx = ryjx;
    }

    public String getMy() {
        return my;
    }

    public void setMy(String my) {
        this.my = my;
    }

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt;
    }

    public String getHz() {
        return hz;
    }

    public void setHz(String hz) {
        this.hz = hz;
    }

    public String getLx() {
        return lx;
    }

    public void setLx(String lx) {
        this.lx = lx;
    }

    public String getLb() {
        return lb;
    }

    public void setLb(String lb) {
        this.lb = lb;
    }

    public String getDs() {
        return ds;
    }

    public void setDs(String ds) {
        this.ds = ds;
    }

    public String getPsl() {
        return psl;
    }

    public void setPsl(String psl) {
        this.psl = psl;
    }

    public String getCd() {
        return cd;
    }

    public void setCd(String cd) {
        this.cd = cd;
    }

    public String getKd() {
        return kd;
    }

    public void setKd(String kd) {
        this.kd = kd;
    }

    public String getGd() {
        return gd;
    }

    public void setGd(String gd) {
        this.gd = gd;
    }

    public String getCssd() {
        return cssd;
    }

    public void setCssd(String cssd) {
        this.cssd = cssd;
    }

    public String getZjdl() {
        return zjdl;
    }

    public void setZjdl(String zjdl) {
        this.zjdl = zjdl;
    }

    public String getJb() {
        return jb;
    }

    public void setJb(String jb) {
        this.jb = jb;
    }

    public String getDl() {
        return dl;
    }

    public void setDl(String dl) {
        this.dl = dl;
    }

    public String getSd() {
        return sd;
    }

    public void setSd(String sd) {
        this.sd = sd;
    }

    public String getJbcc() {
        return jbcc;
    }

    public void setJbcc(String jbcc) {
        this.jbcc = jbcc;
    }

    public String getXhl() {
        return xhl;
    }

    public void setXhl(String xhl) {
        this.xhl = xhl;
    }

    public String getQt() {
        return qt;
    }

    public void setQt(String qt) {
        this.qt = qt;
    }

    public String getQtry() {
        return qtry;
    }

    public void setQtry(String qtry) {
        this.qtry = qtry;
    }

    public String getZsxt() {
        return zsxt;
    }

    public void setZsxt(String zsxt) {
        this.zsxt = zsxt;
    }

    public String getFyxt() {
        return fyxt;
    }

    public void setFyxt(String fyxt) {
        this.fyxt = fyxt;
    }

    public String getWqzb() {
        return wqzb;
    }

    public void setWqzb(String wqzb) {
        this.wqzb = wqzb;
    }

    public String getFydj() {
        return fydj;
    }

    public void setFydj(String fydj) {
        this.fydj = fydj;
    }

    public String getXdcz() {
        return xdcz;
    }

    public void setXdcz(String xdcz) {
        this.xdcz = xdcz;
    }

    public String getJzj() {
        return jzj;
    }

    public void setJzj(String jzj) {
        this.jzj = jzj;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = rksj;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getZxzb() {
        return zxzb;
    }

    public void setZxzb(String zxzb) {
        this.zxzb = zxzb;
    }

    public byte[] getTpBlob() {
        return tpBlob;
    }

    public void setTpBlob(byte[] tpBlob) {
        this.tpBlob = tpBlob;
    }

    public int getBridgeID() {
        return bridgeID;
    }

    public void setBridgeID(int bridgeID) {
        this.bridgeID = bridgeID;
    }

    public int getGdbUsed() {
        return gdbUsed;
    }

    public void setGdbUsed(int gdbUsed) {
        this.gdbUsed = gdbUsed;
    }

    @Override
    public String toString() {
        return "ObjectShipBasicInfoEntity{" +
                "id=" + id +
                ", mc='" + mc + '\'' +
                ", bh='" + bh + '\'' +
                ", jj='" + jj + '\'' +
                ", tp='" + tp + '\'' +
                ", ssgj='" + ssgj + '\'' +
                ", jc='" + jc + '\'' +
                ", pzrq='" + pzrq + '\'' +
                ", jzz='" + jzz + '\'' +
                ", cb='" + cb + '\'' +
                ", jzrq='" + jzrq + '\'' +
                ", ccrq='" + ccrq + '\'' +
                ", xssj='" + xssj + '\'' +
                ", cmm='" + cmm + '\'' +
                ", zzz='" + zzz + '\'' +
                ", fysj='" + fysj + '\'' +
                ", tyrq='" + tyrq + '\'' +
                ", mg='" + mg + '\'' +
                ", hh='" + hh + '\'' +
                ", zym='" + zym + '\'' +
                ", nc='" + nc + '\'' +
                ", ryjx='" + ryjx + '\'' +
                ", my='" + my + '\'' +
                ", zt='" + zt + '\'' +
                ", hz='" + hz + '\'' +
                ", lx='" + lx + '\'' +
                ", lb='" + lb + '\'' +
                ", ds='" + ds + '\'' +
                ", psl='" + psl + '\'' +
                ", cd='" + cd + '\'' +
                ", kd='" + kd + '\'' +
                ", gd='" + gd + '\'' +
                ", cssd='" + cssd + '\'' +
                ", zjdl='" + zjdl + '\'' +
                ", jb='" + jb + '\'' +
                ", dl='" + dl + '\'' +
                ", sd='" + sd + '\'' +
                ", jbcc='" + jbcc + '\'' +
                ", xhl='" + xhl + '\'' +
                ", qt='" + qt + '\'' +
                ", qtry='" + qtry + '\'' +
                ", zsxt='" + zsxt + '\'' +
                ", fyxt='" + fyxt + '\'' +
                ", wqzb='" + wqzb + '\'' +
                ", fydj='" + fydj + '\'' +
                ", xdcz='" + xdcz + '\'' +
                ", jzj='" + jzj + '\'' +
                ", rksj='" + rksj + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", zxzb='" + zxzb + '\'' +
                ", tpBlob=" + Arrays.toString(tpBlob) +
                ", bridgeID=" + bridgeID +
                ", gdbUsed=" + gdbUsed +
                '}';
    }
}
