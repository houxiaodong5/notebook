package com.cetc54.zkb.ky.websocket;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.controller.EventController;
import com.cetc54.zkb.ky.controller.NewsController;
import com.cetc54.zkb.ky.controller.TwitterController;
import com.cetc54.zkb.ky.controller.output.event.EventAndNewsOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutput;
import com.cetc54.zkb.ky.util.YjsonUtil;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;

@ServerEndpoint("/websocket/twitter")
@Component
public class TwitterWebSocket extends BaseController {

    //静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
    private static int onlineCount = 0;
    //concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。
    private static CopyOnWriteArraySet<TwitterWebSocket> webSocketSet = new CopyOnWriteArraySet<>();

    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;

    //接收sid
    //private String sid = "";

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session) {
        System.out.println("连接已建立");
        try {
            this.session = session;
            webSocketSet.add(this);     //加入set中
            addOnlineCount();           //在线数加1
            do {
           /*     if(TwitterController.twitterOutput==null){
                    Thread.sleep(5000);
                    continue;
                }else {*/
                //sendMSG(session, TwitterController.list);
                Thread.sleep(5000);
                //  }

            } while (true);
        } catch (Exception e) {
        }
    }

    public void sendMSG(Session session, List<TwitterOutput> list) {
        try {
            for (TwitterOutput output : list) {
                synchronized (this) {
                    if (session.isOpen()) {
                        System.out.println("------------轮训开始--------------");
                        sendMessage(session, YjsonUtil.toJson(this.success(output)));
                        System.out.println("成功发送数据：" + YjsonUtil.toJson(output));
                        System.out.println("当前连接数：" + getOnlineCount());
                        System.out.println("线程休眠开始:" + new Date().toLocaleString());
                        Thread.sleep(5000);
                        System.out.println("线程休眠结束:" + new Date().toLocaleString());
                        System.out.println("轮训结束");
                    } else return;
                }

            }


        } catch (Exception e) {
        }
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        System.out.println("自动关闭连接");
        webSocketSet.remove(this);  //从set中删除
        subOnlineCount();           //在线数减1
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        //群发消息
        for (TwitterWebSocket item : webSocketSet) {
            try {
                item.sendMessage(session, message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    /**
     * 实现服务器主动推送
     */
    public synchronized void sendMessage(Session session, String message) {
        try {
            if (session.isOpen()) {
                this.session.getBasicRemote().sendText(message);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 群发自定义消息
     */
    public static void sendInfo(String message, @PathParam("sid") String sid) throws IOException {

    }

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        TwitterWebSocket.onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        TwitterWebSocket.onlineCount--;
    }
}
