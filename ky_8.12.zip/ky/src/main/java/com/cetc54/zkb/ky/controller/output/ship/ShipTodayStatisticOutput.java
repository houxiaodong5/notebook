package com.cetc54.zkb.ky.controller.output.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("当前船舶情况统计")
public class ShipTodayStatisticOutput {
    @ApiModelProperty("在港舰船数量")
    private Integer zgNum;
    @ApiModelProperty("进港舰船数量")
    private Integer jgNum;
    @ApiModelProperty("离港舰船数量")
    private Integer lgNum;

    public Integer getZgNum() {
        return this.zgNum;
    }

    public void setZgNum(Integer zgNum) {
        this.zgNum = zgNum;
    }

    public Integer getJgNum() {
        return this.jgNum;
    }

    public void setJgNum(Integer jgNum) {
        this.jgNum = jgNum;
    }

    public Integer getLgNum() {
        return this.lgNum;
    }

    public void setLgNum(Integer lgNum) {
        this.lgNum = lgNum;
    }
}