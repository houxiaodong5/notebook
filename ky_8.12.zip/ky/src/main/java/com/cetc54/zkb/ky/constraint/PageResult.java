package com.cetc54.zkb.ky.constraint;

import com.github.pagehelper.Page;

import java.math.BigInteger;
import java.util.List;

public class PageResult<T> {

    /** 集合数据 **/
    private List<T> pageData;

    /** 总数量 **/
    private BigInteger totalSize;

    public List<T> getPageData() {
        return pageData;
    }

    public void setPageData(List<T> pageData) {
        this.pageData = pageData;
    }

    public BigInteger getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(BigInteger totalSize) {
        this.totalSize = totalSize;
    }

    public PageResult(List<T> list) {
        if (list instanceof Page) {
            Page page = (Page) list;
            this.pageData = page;
            this.totalSize = BigInteger.valueOf(page.getTotal());
        }
    }
}
