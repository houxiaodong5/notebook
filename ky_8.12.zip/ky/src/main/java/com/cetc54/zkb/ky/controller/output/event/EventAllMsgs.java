package com.cetc54.zkb.ky.controller.output.event;

import com.cetc54.zkb.ky.util.TimeUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

@ApiModel("事件详情(包含人、基地、舰船)")
public class EventAllMsgs implements Serializable {

    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("uuid")
    private String uuid;
    @ApiModelProperty("标题")
    private String bt;
    @ApiModelProperty("简介")
    private String jj;
    @ApiModelProperty("关键词")
    private String gjc;
    @ApiModelProperty("发生时间")
    private String fssj;
    @ApiModelProperty("结束时间")
    private String jssj;
    @ApiModelProperty("坐标纬度")
    private String zbwd;
    @ApiModelProperty("坐标经度")
    private String zbjd;
    @ApiModelProperty("标签1")
    private String tag1;
    @ApiModelProperty("标签2")
    private String tag2;
    @ApiModelProperty("标签3")
    private String tag3;
    @ApiModelProperty("国家名称")
    private String gjmc;
    @ApiModelProperty("国家id")
    private String gjid;
    @ApiModelProperty("地点")
    private String dd;
    @ApiModelProperty("威胁等级")
    private String wxdj;
    @ApiModelProperty("入库时间")
    private String rksj;
    @ApiModelProperty("id")
    private Integer gdbUsed;
    @ApiModelProperty("涉及人员")
    private List<SimpleModel> person;
    @ApiModelProperty("涉及船舶")
    private List<SimpleModel> ship;
    @ApiModelProperty("涉及基地")
    private List<SimpleModel> base;
    private String gjj;
    //new_leader newLeader,old_leader oldLeader,gjj
    private String oldLeader;
    private String newLeader;
    private String locationName;
    private int locationID;
    private int viewNumber;

    public int getViewNumber() {
        return viewNumber;
    }

    public void setViewNumber(int viewNumber) {
        this.viewNumber = viewNumber;
    }

    public String getOldLeader() {
        return oldLeader;
    }

    public void setOldLeader(String oldLeader) {
        this.oldLeader = oldLeader;
    }

    public String getNewLeader() {
        return newLeader;
    }

    public void setNewLeader(String newLeader) {
        this.newLeader = newLeader;
    }

    public String getGjj() {
        return gjj;
    }

    public void setGjj(String gjj) {
        this.gjj = gjj;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public int getLocationID() {
        return locationID;
    }

    public void setLocationID(int locationID) {
        this.locationID = locationID;
    }

    public EventAllMsgs() {
    }

    public EventAllMsgs(List<SimpleModel> person, List<SimpleModel> ship, List<SimpleModel> base) {
        this.person = person;
        this.ship = ship;
        this.base = base;
    }

    public EventAllMsgs(Integer id, String uuid, String bt, String jj, String gjc, String fssj, String jssj, String zbwd, String zbjd, String tag1, String tag2, String tag3, String gjmc, String gjid, String dd, String wxdj, String rksj, Integer gdbUsed, List<SimpleModel> person, List<SimpleModel> ship, List<SimpleModel> base) {
        this.id = id;
        this.uuid = uuid;
        this.bt = bt;
        this.jj = jj;
        this.gjc = gjc;
        this.fssj = fssj;
        this.jssj = jssj;
        this.zbwd = zbwd;
        this.zbjd = zbjd;
        this.tag1 = tag1;
        this.tag2 = tag2;
        this.tag3 = tag3;
        this.gjmc = gjmc;
        this.gjid = gjid;
        this.dd = dd;
        this.wxdj = wxdj;
        this.rksj = rksj;
        this.gdbUsed = gdbUsed;
        this.person = person;
        this.ship = ship;
        this.base = base;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getBt() {
        return bt;
    }

    public void setBt(String bt) {
        this.bt = bt;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getGjc() {
        return gjc;
    }

    public void setGjc(String gjc) {
        this.gjc = gjc;
    }

    public String getFssj() {
        return fssj;
    }

    public void setFssj(String fssj) {
        this.fssj = TimeUtil.formateStringTime(fssj);
    }

    public String getJssj() {
        return jssj;
    }

    public void setJssj(String jssj) {
        this.jssj = TimeUtil.formateStringTime(jssj);
    }

    public String getZbwd() {
        return zbwd;
    }

    public void setZbwd(String zbwd) {
        this.zbwd = zbwd;
    }

    public String getZbjd() {
        return zbjd;
    }

    public void setZbjd(String zbjd) {
        this.zbjd = zbjd;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getGjmc() {
        return gjmc;
    }

    public void setGjmc(String gjmc) {
        this.gjmc = gjmc;
    }

    public String getGjid() {
        return gjid;
    }

    public void setGjid(String gjid) {
        this.gjid = gjid;
    }

    public String getDd() {
        return dd;
    }

    public void setDd(String dd) {
        this.dd = dd;
    }

    public String getWxdj() {
        return wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }

    public Integer getGdbUsed() {
        return gdbUsed;
    }

    public void setGdbUsed(Integer gdbUsed) {
        this.gdbUsed = gdbUsed;
    }

    public List<SimpleModel> getPerson() {
        return person;
    }

    public void setPerson(List<SimpleModel> person) {
        this.person = person;
    }

    public List<SimpleModel> getShip() {
        return ship;
    }

    public void setShip(List<SimpleModel> ship) {
        this.ship = ship;
    }

    public List<SimpleModel> getBase() {
        return base;
    }

    public void setBase(List<SimpleModel> base) {
        this.base = base;
    }


    @Override
    public String toString() {
        return "EventAllMsgs{" +
                "id=" + id +
                ", uuid='" + uuid + '\'' +
                ", bt='" + bt + '\'' +
                ", jj='" + jj + '\'' +
                ", gjc='" + gjc + '\'' +
                ", fssj='" + fssj + '\'' +
                ", jssj='" + jssj + '\'' +
                ", zbwd='" + zbwd + '\'' +
                ", zbjd='" + zbjd + '\'' +
                ", tag1='" + tag1 + '\'' +
                ", tag2='" + tag2 + '\'' +
                ", tag3='" + tag3 + '\'' +
                ", gjmc='" + gjmc + '\'' +
                ", gjid='" + gjid + '\'' +
                ", dd='" + dd + '\'' +
                ", wxdj='" + wxdj + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdbUsed=" + gdbUsed +
                ", person=" + person +
                ", ship=" + ship +
                ", base=" + base +
                ", gjj='" + gjj + '\'' +
                ", oldLeader='" + oldLeader + '\'' +
                ", newLeader='" + newLeader + '\'' +
                ", locationName='" + locationName + '\'' +
                ", locationID=" + locationID +
                '}';
    }
}

