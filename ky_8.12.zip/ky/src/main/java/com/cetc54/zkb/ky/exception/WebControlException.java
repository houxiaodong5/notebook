package com.cetc54.zkb.ky.exception;

/**
 * 说明:控制异常,用于其他业务系统继承,在web端统一进行拦截处理
 * <br>UpdateNote:
 * <br>UpdateTime:
 * <br>UpdateUser:
 */
public class WebControlException extends Exception  {

    private String code;
    private String msg;

    public WebControlException(String code, String msg) {
        super(msg);
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
