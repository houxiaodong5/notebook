package com.cetc54.zkb.ky.dao.sql;

import com.cetc54.zkb.ky.dao.entity.UserInfoEntity;
import org.apache.ibatis.annotations.Param;

public class UserSql {

    public static String registerUser(@Param("user") UserInfoEntity user){
        return "";
    }
}
