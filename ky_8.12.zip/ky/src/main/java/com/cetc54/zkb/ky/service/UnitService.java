package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.controller.output.unit.SimpleUnitPersonOutput;
import com.cetc54.zkb.ky.controller.output.unit.UnitInfoOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;

import java.util.List;

public interface UnitService {
    UnitInfoOutput queryUnitMsgByUnitID(int unitID);

    ObjectPerson queryCommanderMsg(int id);

    //更新所有人头像路径
    void uodatePersonImg();

    List<SimpleUnitPersonOutput> queryPersonRelation(int unitID);

    List<SimpleUnitPersonOutput> queryPersonRelationBasedPerson(int personID);
}
