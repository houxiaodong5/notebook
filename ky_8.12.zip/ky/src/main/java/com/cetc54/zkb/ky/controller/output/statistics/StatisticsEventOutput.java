package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 *      西太地区：按时间统计舰船,人物事件结果
 * */
public class StatisticsEventOutput implements Serializable,Comparable<StatisticsEventOutput>{

    private int id;
    private String mc;
    private String ywmc;
    private  String timeType;
    private List<String> time;
    private List<Integer> num;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMc() {
        return mc;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public List<String> getTime() {
        return time;
    }

    public void setTime(List<String> time) {
        this.time = time;
    }

    public List<Integer> getNum() {
        return num;
    }

    public void setNum(List<Integer> num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "StatisticsEventOutput{" +
                "id=" + id +
                ", mc='" + mc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", timeType='" + timeType + '\'' +
                ", time=" + time +
                ", num=" + num +
                '}';
    }

    @Override
    public int compareTo(StatisticsEventOutput o) {
        List<Integer> count = this.getNum();
        List<Integer>  count1= o.getNum();
        int sum = count.stream().mapToInt(x -> x).sum();
        int sum1 = count1.stream().mapToInt(x -> x).sum();

        if(sum<sum1){
            return 1;
        }else if(sum==sum1){
            return 0;
        }
        return -1;
    }
}


