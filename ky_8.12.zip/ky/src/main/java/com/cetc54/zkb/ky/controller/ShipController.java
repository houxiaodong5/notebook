package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonOrShipsInput;
import com.cetc54.zkb.ky.controller.input.ship.BaseShipInput;
import com.cetc54.zkb.ky.controller.input.ship.BaseShipMsg;
import com.cetc54.zkb.ky.controller.input.ship.StatisticShipByBaseInput;
import com.cetc54.zkb.ky.controller.output.ship.*;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;
import com.cetc54.zkb.ky.service.ShipService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Api("船舶controller")
@RestController
public class ShipController extends BaseController {
    @Resource
    private ShipService shipService;

    @ApiOperation("基地在港舰船坐标及舰船进出港数量统计")
    @ApiImplicitParam(name = "time",value = "时间，格式为yyyy-MM-dd,查询某天传某天时间，当日传当日时间")
    @GetMapping({"/ship/statistic"})
    public DataResponse<ShipAndEventTodayStatisticOutput> shipAndEventStatistic(String time) {
        return this.success(this.shipService.shipAndEventStatistic(time));
    }

    @ApiOperation("统计今日舰船在港、进港、离港总数")
    @GetMapping({"/ship/today/statistic"})
    public DataResponse<ShipTodayStatisticOutput> shipTodayStatistic() {
        return this.success(this.shipService.shipTodayStatistic());
    }

    @ApiOperation("按年、月、周及基地ID统计舰船情况")
    @GetMapping({"/ship/base/statistic"})
    public DataResponse<ShipStaticOutput> statisticShipByBase(StatisticShipByBaseInput input) {
        return this.success(this.shipService.statisticShipByBase(input));
    }

    @ApiOperation("查询船舶轨迹,返回查询日期至今日的船舶轨迹")
    @ApiImplicitParam(name = "time",value = "时间，格式为yyyy-MM-dd,查询某天传某天时间")
    @GetMapping({"/ship/trajectory/query"})
    public DataResponse<ShipTrajectoryOutput> queryShipTrajectory(String time) {
        return this.success(this.shipService.queryShipTrajectory(time));
    }

    @ApiOperation(" 根据港口、在港状态查询船舶详情")
    @GetMapping({"/ship/base/query"})
    public DataResponse<ObjectShipBasicInfoEntity> queryShipByBase(BaseShipInput input) {
        return this.success(this.shipService.queryShipByBase(input));
    }

    @ApiOperation(" 根据船舶id查询船舶详情--林肯号专用")
    @PostMapping({"/query/ship/byID"})
    public DataResponse<ObjectShipBasicInfoEntity> queryShipByID(@RequestBody BaseShipMsg shipMsg) {
        return this.success(this.shipService.queryShipByID(shipMsg));
    }

    @ApiOperation(" 根据船舶id查询船舶详情")
    @PostMapping({"/query/ship/byID/for/other"})
    public DataResponse<ObjectShipBasicInfoEntity> queryShipByIDForOther(@RequestBody BaseShipMsg shipMsg) {
        return this.success(this.shipService.queryShipByIDForOther(shipMsg));
    }

    @ApiOperation(" 根据船舶id集合查询船舶信息<集合>-简要信息")
    @PostMapping({"/query/ships/byIDs"})
    public DataResponse<List<ObjectShipBasicInfoEntity>> queryShipsByIDs(@RequestBody QueryPersonOrShipsInput input) {
        return this.success(this.shipService.queryShipsByIDs(input));
    }



    @ApiOperation("查询所有船的事件-分层")
    @GetMapping({"query/all/ship/events"})
    public DataResponse<List<ShipAllEvents>> queryAllShipEvents(){
        return this.success(shipService.queryAllShipEvents());
    }

    @ApiOperation("查询所有船的事件-不分层")
    @GetMapping({"query/all/ship/events_new"})
    public DataResponse<List<ShipEvent>> queryAllShipEvents_NEW(){
        return this.success(shipService.queryAllShipEvents_NEW());
    }


}
