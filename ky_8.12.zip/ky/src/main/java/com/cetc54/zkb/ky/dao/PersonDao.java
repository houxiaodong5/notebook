package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.input.person.QueryPersonByConditionsInput;
import com.cetc54.zkb.ky.controller.output.person.OrigConditions;
import com.cetc54.zkb.ky.controller.output.person.PersonOutput;
import com.cetc54.zkb.ky.dao.entity.*;
import com.cetc54.zkb.ky.dao.sql.CountrySql;
import com.cetc54.zkb.ky.dao.sql.PersonSql;
import com.cetc54.zkb.ky.elasticsearch.document.Person;
import org.apache.ibatis.annotations.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface PersonDao {
    @SelectProvider(type = PersonSql.class,method = "queryConditionsOfFilter")
    List<OrigConditions> queryConditionsOfFilter();

    @SelectProvider(type = PersonSql.class,method = "queryPersonByConditions")
    List<ObjectPerson> queryPersonByConditions( QueryPersonByConditionsInput input);

    @SelectProvider(type = PersonSql.class,method = "querySchoolByUserID")
    List<ObjectSchool> querySchoolByUserID(@Param("userID") int userID);

    @SelectProvider(type = PersonSql.class,method = "queryActivitiesOfMilitaryByUserID")
    List<ObjectMilitaryActivity> queryActivitiesOfMilitaryByUserID(@Param("userID") int userID);

    @SelectProvider(type = PersonSql.class,method = "queryHonorByUserID")
    List<ObjectHonor> queryHonorByUserID(@Param("userID") int userID);

    @SelectProvider(type = PersonSql.class,method = "queryHistoryOfTroopsByUserID")
    List<ObjectTroops> queryHistoryOfTroopsByUserID(@Param("userID") int userID);

    @SelectProvider(type = PersonSql.class,method = "queryHistoryOfShipByUserID")
    List<ObjectShipBasicInfoEntity> queryHistoryOfShipByUserID(@Param("userID") int userID);

    @SelectProvider(type = PersonSql.class,method = "queryAllPerson")
    List<PersonOutput> queryAllPerson();

    @SelectProvider(type = PersonSql.class,method = "queryAllPersonSimpleMsg")
    List<Person> queryAllPersonSimpleMsg();

    @Select("select * from object_person order by renwuid")
    List<PersonOutput> queryAllPersonMessage();

    @Update("update object_person set tx=#{tx},txpic=#{txpic} where renwuid=#{renwuid}")
    void updatePersonImg(PersonOutput personOutput);

    @UpdateProvider(type = PersonSql.class,method = "updatePersonMessage")
    void updatePersonMessage(PersonOutput person);
}
