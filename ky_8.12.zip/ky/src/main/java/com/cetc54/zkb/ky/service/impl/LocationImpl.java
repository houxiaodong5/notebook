package com.cetc54.zkb.ky.service.impl;

import com.alibaba.fastjson.JSON;
import com.cetc54.zkb.ky.controller.input.event.EventQueryByID;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonOrShipsInput;
import com.cetc54.zkb.ky.controller.output.base.SimpleUnitMsg;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.ship.ObjectShipOutput;
import com.cetc54.zkb.ky.dao.LocationDao;
import com.cetc54.zkb.ky.dao.entity.*;
import com.cetc54.zkb.ky.service.LocationService;
import com.cetc54.zkb.ky.util.StringUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Created by Administrator on 2019/5/25/025.
 */
@Service
public class LocationImpl implements LocationService {
    private static Logger logger = LoggerFactory.getLogger(LocationImpl.class);

    @Autowired
    private LocationDao locationDao;
    @Resource
    @Qualifier("primaryJdbcTemplate")
    private JdbcTemplate primaryJdbcTemplate;

    @Override
    public List<ObjectLocation> queryAllLocation() {
        return locationDao.queryAllLocation();
    }

    @Override
    public List<ObjectEventOutput> queryAllEventByLocationID(String locationID) {

        return locationDao.queryAllEventByLocationID(locationID);
    }

    @Override
    public List<ObjectBaseBasicInfoEntity> queryAllBase() {

        return locationDao.queryAllBase();
    }

    @Override
    public List<ObjectEventOutput> queryAllEventByBaseID(EventQueryByID input) {
       // PageHelper.startPage(input.getPageNum(), input.getPageSize());
        List<ObjectEventOutput> list = locationDao.queryAllEventByBaseID(input.getId());
        Integer id = 0;
        for (int i = 0; i < list.size(); i++) {
            ObjectEventOutput output = list.get(i);
            Integer currentId = output.getId();
            if (id == 0) {
                id = currentId;
                continue;
            }
            if (currentId.equals(id)) {
                list.remove(list.get(i));
                i--;
            }else {
                List<String> tagList = StringUtil.splitStr(output.getTag1());
                output.setTags(tagList);
            }


            id = currentId;
        }
       // PageInfo<ObjectEventOutput> pageInfo = new PageInfo<>(list);
        return list;
    }

    @Override
    public List<ObjectPerson> queryAllPerson() {

        return locationDao.queryAllPerson();
    }

    @Override
    public List<ObjectEventOutput> queryAllEventByPersonID(Integer renwuid, String name) {
        //处理人名中出现单引号的数据
        name=StringUtil.standardStr(name);
        List<ObjectEventOutput> list = locationDao.queryAllEventByPersonID(renwuid, name);
        HashSet<String> set = new LinkedHashSet<>();
        /*for(ObjectEventOutput output:list){
            String tag1 = output.getTag1();
            output.setTags(StringUtil.splitStr(tag1));
            if(){

            }
        }*/

        for(int i=0;i<list.size();i++){
            ObjectEventOutput output = list.get(i);
            if(set.contains(output.getBt())){
                list.remove(i);
                i--;
            }else {
                set.add(output.getBt());
                String tag1 = output.getTag1();
                output.setTags(StringUtil.splitStr(tag1));
            }
        }
        return list;
    }

    @Override
    public List<ObjectShipBasicInfoEntity> queryAllShip() {
        return locationDao.queryAllShip();
    }

    @Override
    public List<ObjectEventOutput> queryEventByShipID(Integer shipID) {
        return locationDao.queryEventByShipID(shipID);
    }


    @Override                   //原object_base 中基地iD
    public ObjectBaseBasicInfoEntity queryBaseByBaseID(int baseID) {
        //查询基地基础信息


       /* String sql = "SELECT * FROM `object_base_basic_info` WHERE  jdid=" + baseID;
        List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(sql);
        ObjectBaseBasicInfoEntity baseBasicInfoEntity = null;
        for (Map<String, Object> map : maps) {
            System.out.println(map);
            System.out.println("----------");
            String s = JSON.toJSONString(map);
            System.out.println(s);
            baseBasicInfoEntity = JSON.toJavaObject(JSON.parseObject(s), ObjectBaseBasicInfoEntity.class);
        }*/
        ObjectBaseBasicInfoEntity baseBasicInfoEntity=locationDao.queryBaseByID(baseID);
        if(baseBasicInfoEntity==null){
            return null;
        }

        //ObjectBaseBasicInfoEntity baseBasicInfoEntity = locationDao.queryBaseByBaseID(baseID);
        //查询基地联队基础信息
        //base64StringToImage(baseBasicInfoEntity.getGarrison_symbol());

        String sql1 = "SELECT id,zwm,ywm FROM `object_troops` WHERE id in(select troops_id FROM `relation_troops_base` where base_id=" + baseID + ")";
        List<Map<String, Object>> maps2 = primaryJdbcTemplate.queryForList(sql1);
        List<SimpleUnitMsg> simpleUnitMsgs = new ArrayList<>();
        for (Map<String, Object> map : maps2) {
            String s = JSON.toJSONString(map);
            SimpleUnitMsg simpleUnitMsg = JSON.toJavaObject(JSON.parseObject(s), SimpleUnitMsg.class);
            simpleUnitMsgs.add(simpleUnitMsg);
        }

        //List<SimpleUnitMsg> simpleUnitMsgs = locationDao.queryBaseUnitsInfoByBaseID(realBaseID);
        baseBasicInfoEntity.setUnits(simpleUnitMsgs);
        //String time = new Date(Long.valueOf(baseBasicInfoEntity.getRksj())).toLocaleString();
        //baseBasicInfoEntity.setRksj(baseBasicInfoEntity.getRksj());
        return baseBasicInfoEntity;

    }

    @Override
    public ObjectBaseBasicInfoEntity queryOtherBaseByBaseID(int baseID) {
        ObjectBaseBasicInfoEntity baseEntity=locationDao.queryBaseByID(baseID);
       /* String sql = "SELECT * FROM `object_base` WHERE jdid=" + baseID;
        List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(sql);
        ObjectBaseEntity baseEntity = null;
        for (Map<String, Object> map : maps) {
            String s = JSON.toJSONString(map);
            baseEntity = JSON.toJavaObject(JSON.parseObject(s), ObjectBaseEntity.class);
        }*/
        if(baseEntity==null){
            return null;
        }

        //ObjectBaseBasicInfoEntity baseBasicInfoEntity = locationDao.queryBaseByBaseID(baseID);
        //查询基地联队基础信息
        //base64StringToImage(baseBasicInfoEntity.getGarrison_symbol());

        String sql1 = "SELECT id,zwm,ywm FROM `object_troops` WHERE id in(select troops_id FROM `relation_troops_base` where base_id=" + baseID + ")";
        List<Map<String, Object>> maps2 = primaryJdbcTemplate.queryForList(sql1);
        List<SimpleUnitMsg> simpleUnitMsgs = new ArrayList<>();
        for (Map<String, Object> map : maps2) {
            String s = JSON.toJSONString(map);
            SimpleUnitMsg simpleUnitMsg = JSON.toJavaObject(JSON.parseObject(s), SimpleUnitMsg.class);
            simpleUnitMsgs.add(simpleUnitMsg);
        }

        //List<SimpleUnitMsg> simpleUnitMsgs = locationDao.queryBaseUnitsInfoByBaseID(realBaseID);
        baseEntity.setUnits(simpleUnitMsgs);

        return baseEntity;
    }

    @Override
    public ObjectPerson queryPersonByPersonID(int personID) {
        return locationDao.queryPersonByPersonID(personID);
    }

    //


    public static void base64StringToImage(byte[] bytes) {
        try {

            ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
            BufferedImage bi1 = ImageIO.read(bais);
            File w2 = new File("C:\\Users\\Administrator.WIN-F64LG4L5QFQ\\Desktop\\aaa.jpg");//可以是jpg,png格式
            ImageIO.write(bi1, "jpg", w2);//不管输出什么格式图片，此处不需改动
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
    }

    @Override
    public List<ObjectPerson> queryPersonByPersonIDs(QueryPersonOrShipsInput input) {
        List<Integer> ids = input.getIds();
        if(ids.size()==0){
            return new ArrayList<>();
        }

        try {
            String sql="SELECT  renwuid,zwxm,ywxm,txpic,gj,shgx FROM `object_person`where renwuid in(  ";
            StringBuffer buffer = new StringBuffer();
            for (Integer id:ids) {
                buffer.append(id+",");
            }
            String substring = buffer.substring(0, buffer.lastIndexOf(","));
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(sql);
            stringBuffer.append(substring);
            stringBuffer.append(")");
            List<ObjectPerson> list = locationDao.queryPersonByPersonIDs(stringBuffer.toString());
            for(ObjectPerson objectPerson:list){
                String shgx = objectPerson.getShgx();
                if(null==objectPerson.getShgx()){
                    continue;
                }
                List<String> str = StringUtil.splitStr(shgx);
                objectPerson.setShgxs(str);
            }
            return list;
        } catch (Exception e) {
            logger.error("操作失败");
            return null;
        }

    }

    @Override
    public List<ObjectEventOutput> queryAllEventByShipID(int shipID) {
        List<ObjectEventOutput> eventOutputs = new ArrayList<>();
        try {
            StringBuffer buffer = new StringBuffer();
            buffer.append("SELECT distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj  FROM `object_event` t1 ");
            buffer.append("LEFT join relation_ship_location t2 on t1.`uuid` =t2.`event_id` ");
            buffer.append("where t1.`uuid` in  ( ");
            buffer.append("SELECT  distinct event_id   from `relation_ship_event`  WHERE `ship_id` ="+shipID+" ORDER BY `event_id` ) ");
            buffer.append("ORDER BY t1.`fssj` DESC  ");
            String sql=buffer.toString();
            List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(sql);
            for (Map<String, Object> map:maps) {
                String s = JSON.toJSONString(map);
                ObjectEventOutput output = JSON.toJavaObject(JSON.parseObject(s), ObjectEventOutput.class);

                String uuid=(String) map.get("uuid");
                sql="select gxlx from `relation_ship_location`  where ship_id="+shipID+" and event_id='"+uuid+"'";
                List<String> list = primaryJdbcTemplate.queryForList(sql, String.class);
                if(list.size()>0){
                    output.setShipTag(list.get(0));
                }
                eventOutputs.add(output);
                continue;

            }
        } catch (Exception e) {
            logger.error("操作失败");
        }
        return eventOutputs;
    }
}
