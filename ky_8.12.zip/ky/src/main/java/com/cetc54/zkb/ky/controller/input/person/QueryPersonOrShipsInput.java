package com.cetc54.zkb.ky.controller.input.person;

import java.util.List;

public class QueryPersonOrShipsInput {
    private List<Integer> ids;

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return "QueryPersonInput{" +
                "ids=" + ids +
                '}';
    }
}
