package com.cetc54.zkb.ky.elasticsearch.repository;

import com.cetc54.zkb.ky.elasticsearch.document.Person;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import java.util.List;

public interface PersonRepository extends ElasticsearchRepository<Person,String> {
    //@Query("{"bool" : {"must" : {"field" : {"name" : "?0"}}}}")
    List<Person> queryPersonByZwxm(String zwxm);

}
