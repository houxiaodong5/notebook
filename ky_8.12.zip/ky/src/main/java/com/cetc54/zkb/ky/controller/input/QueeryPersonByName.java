package com.cetc54.zkb.ky.controller.input;

public class QueeryPersonByName {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "QueeryPersonByName{" +
                "name='" + name + '\'' +
                '}';
    }
}
