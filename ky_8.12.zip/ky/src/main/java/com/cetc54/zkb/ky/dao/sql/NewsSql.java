package com.cetc54.zkb.ky.dao.sql;

import java.util.List;

public class NewsSql {
    public static String queryLatestNews(){
        return "SELECT nm_id id,vc_uuid uuid, cast(vc_crawlDate as char) crawlTime,vc_domain source,vc_title title FROM tb_news_new  order by vc_crawlDate DESC limit 1 ";
        //return "SELECT nm_id id,vc_uuid uuid,vc_crawlDate crawlDate,vc_domain source,vc_title title FROM tb_news order by vc_crawlDate DESC limit 5 ";
    }

    public static String queryAllSource(){
        return "SELECT DISTINCT vc_domain source,`vc_origin` name  FROM tb_news_new  order by vc_domain ";
    }

    public static String queryDataBySource(List<String> list ){
        StringBuffer sql = new StringBuffer();
        sql.append("select id,uuid,bt,jj,gjc,cast(fssj as char) fssj ,cast(jssj as char) jssj,zbwd,zbjd,tag1,tag2,tag3,gjmc,gjid,dd,wxdj,cast(rksj as char) rksj,gdb_used gdbUsed FROM object_event where 1=1 and uuid in('");
        for (String str:list){
            sql.append(str+"','");
        }
       sql.deleteCharAt(sql.lastIndexOf("'"));
       sql.deleteCharAt(sql.lastIndexOf(","));
        sql.append(" )order by fssj desc limit 1000");
        return sql.toString();
    }

    public static String queryAllUUIDBySource(String source){
        return "SELECT DISTINCT vc_uuid uuid FROM tb_news_new where vc_domain='"+source +" '";
    }

}
