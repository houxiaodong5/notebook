package com.cetc54.zkb.ky.controller.output.person;

import com.cetc54.zkb.ky.dao.entity.ObjectHonor;
import com.cetc54.zkb.ky.dao.entity.ObjectMilitaryActivity;
import com.cetc54.zkb.ky.dao.entity.ObjectSchool;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;
@ApiModel("人物经历信息")
public class PersonRelationMsg implements Serializable {
    @ApiModelProperty(name = "xx",value = "学校信息")
    private List<ObjectSchool> xx;
    @ApiModelProperty(name = "zzjl",value = "作战经历")
    private List<ObjectMilitaryActivity> zzjl;
    @ApiModelProperty(name = "jjqk",value = "嘉奖情况")
    private List<ObjectHonor> jjqk;
    @ApiModelProperty(name = "gzjl",value = "工作经历")
    private HistoryOfWork gzjl;

    public List<ObjectSchool> getXx() {
        return xx;
    }

    public void setXx(List<ObjectSchool> xx) {
        this.xx = xx;
    }

    public List<ObjectMilitaryActivity> getZzjl() {
        return zzjl;
    }

    public void setZzjl(List<ObjectMilitaryActivity> zzjl) {
        this.zzjl = zzjl;
    }

    public List<ObjectHonor> getJjqk() {
        return jjqk;
    }

    public void setJjqk(List<ObjectHonor> jjqk) {
        this.jjqk = jjqk;
    }

    public HistoryOfWork getGzjl() {
        return gzjl;
    }

    public void setGzjl(HistoryOfWork gzjl) {
        this.gzjl = gzjl;
    }

    @Override
    public String toString() {
        return "PersonRelationMsg{" +
                "xx=" + xx +
                ", zzjl=" + zzjl +
                ", jjqk=" + jjqk +
                ", gzjl=" + gzjl +
                '}';
    }
}
