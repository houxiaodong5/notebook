package com.cetc54.zkb.ky.enums;

/**
 * 时间类型枚举类
 * */
public enum  TimeTypeEnum {
    Day,Week,Month,Year;
}
