package com.cetc54.zkb.ky.service.model;

public class QueryModel {
    private SliceOfTime queryTime;
    private String state;
    private String flag;
    private int shipID;

    public SliceOfTime getQueryTime() {
        return queryTime;
    }

    public void setQueryTime(SliceOfTime queryTime) {
        this.queryTime = queryTime;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public int getShipID() {
        return shipID;
    }

    public void setShipID(int shipID) {
        this.shipID = shipID;
    }

    public QueryModel() {
    }

    public QueryModel(SliceOfTime queryTime, String state, String flag) {
        this.queryTime = queryTime;
        this.state = state;
        this.flag = flag;
    }

    public QueryModel(SliceOfTime queryTime, String state, String flag, int shipID) {
        this.queryTime = queryTime;
        this.state = state;
        this.flag = flag;
        this.shipID = shipID;
    }

    @Override
    public String toString() {
        return "QueryModel{" +
                "queryTime=" + queryTime +
                ", state='" + state + '\'' +
                ", flag='" + flag + '\'' +
                ", shipID=" + shipID +
                '}';
    }

}
