package com.cetc54.zkb.ky.service.impl;


import com.alibaba.fastjson.JSON;
import com.cetc54.zkb.ky.controller.output.unit.SimpleUnitInfo;
import com.cetc54.zkb.ky.controller.output.unit.SimpleUnitPersonOutput;
import com.cetc54.zkb.ky.controller.output.unit.UnitInfoOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;
import com.cetc54.zkb.ky.service.UnitService;
import com.cetc54.zkb.ky.util.OSSUtil;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class UnitImpl implements UnitService {

    private List<String> urlList;

    @PostConstruct
    public void init() {
        urlList = OSSUtil.getPersonIMg();
    }

    static final String url_prefix = "https://shujucaiji.oss-cn-beijing.aliyuncs.com";
    @Resource
    @Qualifier("primaryJdbcTemplate")
    private JdbcTemplate primaryJdbcTemplate;
    private static Logger logger= LoggerFactory.getLogger(UnitImpl.class);

    @Override
    public UnitInfoOutput queryUnitMsgByUnitID(int unitID) {
        //查询联队详细信息
        UnitInfoOutput unit = null;
        List<SimpleUnitInfo> children;
        try {
            String sql = "SELECT * FROM object_troops WHERE id=" + unitID;
            List<Map<String, Object>> list = primaryJdbcTemplate.queryForList(sql);
            for (Map<String, Object> map : list) {
                String data = JSON.toJSONString(map);
                unit = JSON.toJavaObject(JSON.parseObject(data), UnitInfoOutput.class);
            }
            //查询联队下属单位
            sql = "SELECT id,zwm,ywm FROM object_troops WHERE parentID=" + unitID;
            list = primaryJdbcTemplate.queryForList(sql);
            if (list.size() > 0) {
                children = new ArrayList<>();
                for (Map<String, Object> map : list) {
                    String data = JSON.toJSONString(map);
                    SimpleUnitInfo simpleUnitInfo = JSON.toJavaObject(JSON.parseObject(data), SimpleUnitInfo.class);
                    children.add(simpleUnitInfo);
                }
                unit.setChildren(children);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        } finally {
            return unit;
        }

    }

    @Override
    public ObjectPerson queryCommanderMsg(int id) {
        String sql = "SELECT * FROM object_person WHERE renwuid=" + id;
        List<Map<String, Object>> list = primaryJdbcTemplate.queryForList(sql);
        ObjectPerson person = null;
        if (list.size() > 0) {
            for (Map<String, Object> map : list) {
                String data = JSON.toJSONString(map);
                person = JSON.toJavaObject(JSON.parseObject(data), ObjectPerson.class);
                break;
            }

        }
        return person;
    }

    @Override
    public void uodatePersonImg() {
        //查询所有人头像
        try {
            String sql = "select renwuid,tx from object_person";
            List<Map<String, Object>> list = primaryJdbcTemplate.queryForList(sql);
            sql = "";
            for (Map<String, Object> map : list) {
                if (null != map.get("tx")) {
                    String tx = (String) map.get("tx");
                    if (!StringUtils.isEmpty(tx)) {

                        String[] split = tx.split("/");
                        String imgName = split[4];
                        String url = "";
                        for (String imgUrl : urlList) {
                            if (imgUrl.contains(imgName)) {
                                url = imgUrl;
                                break;
                            }
                        }

                        if (url.equals("")) {
                            continue;
                        }
                        sql = "update object_person set tx='" + url + "' where renwuid=" + map.get("renwuid") ;
                        primaryJdbcTemplate.update(sql);
                    }
                    continue;
                }
                continue;

            }

        } catch (DataAccessException e) {
            logger.error(e.getMessage());
        }


        //System.out.println(sql);

    }

    @Override
    public List<SimpleUnitPersonOutput> queryPersonRelation(int unitID) {
        //查询联队层级关系
        List<SimpleUnitPersonOutput> responseData=new ArrayList<>();
        String sql = "SELECT id,parentID pid,zwm,ywm,commander personName,commander_id personID FROM `object_troops`  WHERE id=" + unitID;
        List<Map<String, Object>> list = primaryJdbcTemplate.queryForList(sql);
        List<Map<String, Object>> allList = selectUnitRelation(unitID, list);
        String sql1="";
        if (allList.size() > 0) {
            for (Map<String, Object> map : allList) {
                String data = JSON.toJSONString(map);
                SimpleUnitPersonOutput output = JSON.toJavaObject(JSON.parseObject(data), SimpleUnitPersonOutput.class);
                int personID = output.getPersonID();
                if(personID!=0){
                    sql="select zw,txpic,tx from object_person where renwuid ="+personID ;
                    List<Map<String, Object>> personMsg = primaryJdbcTemplate.queryForList(sql);
                    for(Map<String, Object> map1:personMsg){
                        output.setZw((String) map1.get("zw"));
                        output.setTxpic((byte[]) map1.get("txpic"));
                        output.setTx((String)map1.get("tx"));
                        break;
                    }
                }

                responseData.add(output);
            }
        }
        return responseData;
    }

    @Override
    public List<SimpleUnitPersonOutput> queryPersonRelationBasedPerson(int personID) {
        //查询人所处联队
        List<SimpleUnitPersonOutput> responseData=new ArrayList<>();
        try {
            String sql = "SELECT ssjgid unitID FROM `object_person`  WHERE renwuid=" + personID;
            List<Map<String, Object>> list = primaryJdbcTemplate.queryForList(sql);
            if(list.size()>0){
                Map<String, Object> map1 = list.get(0);

                if(null!=map1.get("unitID")){
                    Integer unitID = Integer.valueOf((String) map1.get("unitID"));
                    responseData = queryPersonRelation(unitID);
                }

            }

        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return responseData;
    }

    public List<Map<String, Object>> selectUnitRelation(int parentID, List<Map<String, Object>> list){
        String sql = "SELECT id,parentID pid,zwm,ywm,commander personName,commander_id personID FROM `object_troops`  WHERE parentID=" + parentID;
        List<Map<String, Object>> list1 = primaryJdbcTemplate.queryForList(sql);
        if(list1.size()!=0){
            for (Map<String, Object> map:list1) {
                 list.add(map);
                selectUnitRelation(Integer.valueOf((String)map.get("id")),list);
            }
        }
        return list;
    }

}
