package com.cetc54.zkb.ky.controller.output;

import com.cetc54.zkb.ky.dao.entity.NewsEntity;

import java.io.Serializable;
import java.util.List;

public class NewsOutputByPage implements Serializable {
    private int totalPage;
    private int currentPage;
    private int totalData;
    private List<NewsEntity> data;

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getTotalData() {
        return totalData;
    }

    public void setTotalData(int totalData) {
        this.totalData = totalData;
    }

    public List<NewsEntity> getData() {
        return data;
    }

    public void setData(List<NewsEntity> data) {
        this.data = data;
    }


    @Override
    public String toString() {
        return "NewsOutputByPage{" +
                "totalPage=" + totalPage +
                ", currentPage=" + currentPage +
                ", totalData=" + totalData +
                ", data=" + data +
                '}';
    }
}
