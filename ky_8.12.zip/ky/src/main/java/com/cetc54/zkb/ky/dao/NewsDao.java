package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.dao.entity.NewsEntitry;
import com.cetc54.zkb.ky.dao.sql.NewsSql;
import org.apache.ibatis.annotations.SelectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public interface NewsDao {
    //@Autowired
    //@Qualifier("secondaryJdbcTemplate")
    //查询入库爬取数据

    @SelectProvider(type = NewsSql.class,method = "queryLatestNews")
    List<NewsEntitry> queryLatestNews();

    @SelectProvider(type = NewsSql.class,method = "queryDataBySource")
    List<ObjectEventOutput> queryDataBySource(String source);
}
