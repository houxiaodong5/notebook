package com.cetc54.zkb.ky.constraint;

/**
 * 说明:成功响应结果
 * <br>UpdateNote:
 * <br>UpdateTime:
 * <br>UpdateUser:
 */
public class DataResponse<T> extends Response {

    private T data;

    public DataResponse(T data) {
        this.data = data;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
