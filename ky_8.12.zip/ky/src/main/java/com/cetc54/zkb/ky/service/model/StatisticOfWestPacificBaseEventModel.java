package com.cetc54.zkb.ky.service.model;

public class StatisticOfWestPacificBaseEventModel {
    private String tag;
    private String uuid;
    private int baseId;
    private String jdzwm;
    private String jdywm;

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getBaseId() {
        return baseId;
    }

    public void setBaseId(int baseId) {
        this.baseId = baseId;
    }

    public String getJdzwm() {
        return jdzwm;
    }

    public void setJdzwm(String jdzwm) {
        this.jdzwm = jdzwm;
    }

    public String getJdywm() {
        return jdywm;
    }

    public void setJdywm(String jdywm) {
        this.jdywm = jdywm;
    }

    @Override
    public String toString() {
        return "StatisticOfWestPacificBaseEventModel{" +
                "tag='" + tag + '\'' +
                ", uuid='" + uuid + '\'' +
                ", baseId=" + baseId +
                ", jdzwm='" + jdzwm + '\'' +
                ", jdywm='" + jdywm + '\'' +
                '}';
    }
}
