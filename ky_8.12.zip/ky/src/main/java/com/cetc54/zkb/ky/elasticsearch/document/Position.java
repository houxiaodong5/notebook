package com.cetc54.zkb.ky.elasticsearch.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Document(indexName = "geo_names", type = "items")
public class Position {
    @Id
    private String id;
    private String alternative_names;
    private String city;
    private String country_code;
    private String county;
    private String display_name;
    private float east;
    private float importance;
    private float lat;
    private float lon;
    private String name;
    private float north;
    private float south;
    private String state;
    private String type;
    private float west;
    private String wikidata;
    private String wikipedia;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAlternative_names() {
        return alternative_names;
    }

    public void setAlternative_names(String alternative_names) {
        this.alternative_names = alternative_names;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getDisplay_name() {
        return display_name;
    }

    public void setDisplay_name(String display_name) {
        this.display_name = display_name;
    }

    public float getEast() {
        return east;
    }

    public void setEast(float east) {
        this.east = east;
    }

    public float getImportance() {
        return importance;
    }

    public void setImportance(float importance) {
        this.importance = importance;
    }

    public float getLat() {
        return lat;
    }

    public void setLat(float lat) {
        this.lat = lat;
    }

    public float getLon() {
        return lon;
    }

    public void setLon(float lon) {
        this.lon = lon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getNorth() {
        return north;
    }

    public void setNorth(float north) {
        this.north = north;
    }

    public float getSouth() {
        return south;
    }

    public void setSouth(float south) {
        this.south = south;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getWest() {
        return west;
    }

    public void setWest(float west) {
        this.west = west;
    }

    public String getWikidata() {
        return wikidata;
    }

    public void setWikidata(String wikidata) {
        this.wikidata = wikidata;
    }

    public String getWikipedia() {
        return wikipedia;
    }

    public void setWikipedia(String wikipedia) {
        this.wikipedia = wikipedia;
    }

    @Override
    public String toString() {
        return "Position{" +
                "id='" + id + '\'' +
                ", alternative_names='" + alternative_names + '\'' +
                ", city='" + city + '\'' +
                ", country_code='" + country_code + '\'' +
                ", county='" + county + '\'' +
                ", display_name='" + display_name + '\'' +
                ", east=" + east +
                ", importance=" + importance +
                ", lat=" + lat +
                ", lon=" + lon +
                ", name='" + name + '\'' +
                ", north=" + north +
                ", south=" + south +
                ", state='" + state + '\'' +
                ", type='" + type + '\'' +
                ", west=" + west +
                ", wikidata='" + wikidata + '\'' +
                ", wikipedia='" + wikipedia + '\'' +
                '}';
    }
}

