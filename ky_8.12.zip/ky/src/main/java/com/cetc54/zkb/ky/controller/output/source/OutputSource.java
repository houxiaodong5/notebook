package com.cetc54.zkb.ky.controller.output.source;

import java.io.Serializable;

public class OutputSource implements Serializable {
    private String soure;
    private String name;

    public String getSoure() {
        return soure;
    }

    public void setSoure(String soure) {
        this.soure = soure;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public String toString() {
        return "OutputSource{" +
                "soure='" + soure + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
