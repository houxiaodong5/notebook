package com.cetc54.zkb.ky.controller.output.ship;

public class StatisticsOfShipState {
    private String state;
    private Long number;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Long getNumber() {
        return number;
    }

    public void setNumber(Long number) {
        this.number = number;
    }

    @Override
    public String toString() {
        return "StatisticsOfShipState{" +
                "state='" + state + '\'' +
                ", number=" + number +
                '}';
    }
}
