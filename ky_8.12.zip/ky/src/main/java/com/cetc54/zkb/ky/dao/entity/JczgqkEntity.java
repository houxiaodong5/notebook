package com.cetc54.zkb.ky.dao.entity;

import java.util.Date;

public class JczgqkEntity {
    private Integer id;
    private Integer jcid;
    private Integer gkid;
    private Date ztsj;
    private Integer zgzt;
    private Date rksj;
    private String bz;
    private String jcmc;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return this.id;
    }

    public void setJcid(Integer jcid) {
        this.jcid = jcid;
    }

    public Integer getJcid() {
        return this.jcid;
    }

    public void setGkid(Integer gkid) {
        this.gkid = gkid;
    }

    public Integer getGkid() {
        return this.gkid;
    }

    public void setZtsj(Date ztsj) {
        this.ztsj = ztsj;
    }

    public Date getZtsj() {
        return this.ztsj;
    }

    public void setZgzt(Integer zgzt) {
        this.zgzt = zgzt;
    }

    public Integer getZgzt() {
        return this.zgzt;
    }

    public void setRksj(Date rksj) {
        this.rksj = rksj;
    }

    public Date getRksj() {
        return this.rksj;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    public String getBz() {
        return this.bz;
    }

    public void setJcmc(String jcmc) {
        this.jcmc = jcmc;
    }

    public String getJcmc() {
        return this.jcmc;
    }
}
