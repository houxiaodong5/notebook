package com.cetc54.zkb.ky.controller.input.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("基地船只输入类")
public class BaseShipInput {
    @ApiModelProperty("基地ID")
    private Integer jdid;
    @ApiModelProperty("在港状态")
    private Integer zgzt;

    public Integer getJdid() {
        return this.jdid;
    }

    public void setJdid(Integer jdid) {
        this.jdid = jdid;
    }

    public Integer getZgzt() {
        return this.zgzt;
    }

    public void setZgzt(Integer zgzt) {
        this.zgzt = zgzt;
    }
}

