package com.cetc54.zkb.ky.controller.output.person;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;
import java.util.Arrays;

public class PersonOutput implements Serializable {

    private int renwuid;
    private String zwxm="";
    private String ywxm="";
    private String firstName="";
    private String lastName="";
    private String twoWordName="";
    private String jx="";
    private String jxCn="";
    private String zwCn="";
    private String zw="";
    private String rzsj="";
    private String csd="";
    private String zylb="";
    private String txszwj="";
    private String ssjg="";
    private String  ssjgid;
    private String sjzh="";
    private String rylb="";
    private String zjxy="";
    private String rwmbtz="";
    private String gj="";
    private String gjCn="";
    private String gz="";
    private String jj="";
    private String jy="";
    private String fxjl="";
    private String jiangxiang="";
    private String cj="";
    private String tx="";
    private String lj="";
    private Integer gdbUsed;
    private String yxrq="";
    private String rksj="";
    private byte[] txpic;
    private String shgx="";

    public int getRenwuid() {
        return renwuid;
    }

    public void setRenwuid(int renwuid) {
        this.renwuid = renwuid;
    }

    public String getZwxm() {
        return zwxm;
    }

    public void setZwxm(String zwxm) {
        this.zwxm = zwxm;
    }

    public String getYwxm() {
        return ywxm;
    }

    public void setYwxm(String ywxm) {
        this.ywxm = ywxm;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTwoWordName() {
        return twoWordName;
    }

    public void setTwoWordName(String twoWordName) {
        this.twoWordName = twoWordName;
    }

    public String getJx() {
        return jx;
    }

    public void setJx(String jx) {
        this.jx = jx;
    }

    public String getJxCn() {
        return jxCn;
    }

    public void setJxCn(String jxCn) {
        this.jxCn = jxCn;
    }

    public String getZwCn() {
        return zwCn;
    }

    public void setZwCn(String zwCn) {
        this.zwCn = zwCn;
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    public String getCsd() {
        return csd;
    }

    public void setCsd(String csd) {
        this.csd = csd;
    }

    public String getZylb() {
        return zylb;
    }

    public void setZylb(String zylb) {
        this.zylb = zylb;
    }

    public String getTxszwj() {
        return txszwj;
    }

    public void setTxszwj(String txszwj) {
        this.txszwj = txszwj;
    }

    public String getSsjg() {
        return ssjg;
    }

    public void setSsjg(String ssjg) {
        this.ssjg = ssjg;
    }

    public String getSsjgid() {
        return ssjgid;
    }

    public void setSsjgid(String ssjgid) {
        this.ssjgid = ssjgid;
    }

    public String getSjzh() {
        return sjzh;
    }

    public void setSjzh(String sjzh) {
        this.sjzh = sjzh;
    }

    public String getRylb() {
        return rylb;
    }

    public void setRylb(String rylb) {
        this.rylb = rylb;
    }

    public String getZjxy() {
        return zjxy;
    }

    public void setZjxy(String zjxy) {
        this.zjxy = zjxy;
    }

    public String getRwmbtz() {
        return rwmbtz;
    }

    public void setRwmbtz(String rwmbtz) {
        this.rwmbtz = rwmbtz;
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj;
    }

    public String getGjCn() {
        return gjCn;
    }

    public void setGjCn(String gjCn) {
        this.gjCn = gjCn;
    }

    public String getGz() {
        return gz;
    }

    public void setGz(String gz) {
        this.gz = gz;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getJy() {
        return jy;
    }

    public void setJy(String jy) {
        this.jy = jy;
    }

    public String getFxjl() {
        return fxjl;
    }

    public void setFxjl(String fxjl) {
        this.fxjl = fxjl;
    }

    public String getJiangxiang() {
        return jiangxiang;
    }

    public void setJiangxiang(String jiangxiang) {
        this.jiangxiang = jiangxiang;
    }

    public String getCj() {
        return cj;
    }

    public void setCj(String cj) {
        this.cj = cj;
    }

    public String getTx() {
        return tx;
    }

    public void setTx(String tx) {
        this.tx = tx;
    }

    public String getLj() {
        return lj;
    }

    public void setLj(String lj) {
        this.lj = lj;
    }

    public Integer getGdbUsed() {
        return gdbUsed;
    }

    public void setGdbUsed(Integer gdbUsed) {
        this.gdbUsed = gdbUsed;
    }

    public String getYxrq() {
        return yxrq;
    }

    public void setYxrq(String yxrq) {
        this.yxrq = TimeUtil.formateStringTime(yxrq);
    }

    public byte[] getTxpic() {
        return txpic;
    }

    public void setTxpic(byte[] txpic) {
        this.txpic = txpic;
    }

    public String getShgx() {
        return shgx;
    }

    public void setShgx(String shgx) {
        this.shgx = shgx;
    }

    public String getRzsj() {
        return rzsj;
    }

    public void setRzsj(String rzsj) {
        this.rzsj = TimeUtil.formateStringTime(rzsj);
    }


    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }


    @Override
    public String toString() {
        return "PersonOutput{" +
                "renwuid='" + renwuid + '\'' +
                ", zwxm='" + zwxm + '\'' +
                ", ywxm='" + ywxm + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", twoWordName='" + twoWordName + '\'' +
                ", jx='" + jx + '\'' +
                ", jxCn='" + jxCn + '\'' +
                ", zwCn='" + zwCn + '\'' +
                ", zw='" + zw + '\'' +
                ", rzsj='" + rzsj + '\'' +
                ", csd='" + csd + '\'' +
                ", zylb='" + zylb + '\'' +
                ", txszwj='" + txszwj + '\'' +
                ", ssjg='" + ssjg + '\'' +
                ", ssjgid='" + ssjgid + '\'' +
                ", sjzh='" + sjzh + '\'' +
                ", rylb='" + rylb + '\'' +
                ", zjxy='" + zjxy + '\'' +
                ", rwmbtz='" + rwmbtz + '\'' +
                ", gj='" + gj + '\'' +
                ", gjCn='" + gjCn + '\'' +
                ", gz='" + gz + '\'' +
                ", jj='" + jj + '\'' +
                ", jy='" + jy + '\'' +
                ", fxjl='" + fxjl + '\'' +
                ", jiangxiang='" + jiangxiang + '\'' +
                ", cj='" + cj + '\'' +
                ", tx='" + tx + '\'' +
                ", lj='" + lj + '\'' +
                ", gdbUsed=" + gdbUsed +
                ", yxrq='" + yxrq + '\'' +
                ", rksj='" + rksj + '\'' +
                ", txpic=" + Arrays.toString(txpic) +
                ", shgx='" + shgx + '\'' +
                '}';
    }
}
