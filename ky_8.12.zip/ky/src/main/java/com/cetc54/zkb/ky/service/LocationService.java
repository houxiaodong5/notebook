package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.EventQueryByID;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonOrShipsInput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.ship.ObjectShipOutput;
import com.cetc54.zkb.ky.dao.entity.*;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by Administrator on 2019/5/25/025.
 */
public interface LocationService {

    //查询所有事件的location
    List<ObjectLocation> queryAllLocation();
    //根据地点ID查询对应区域事件
    List<ObjectEventOutput> queryAllEventByLocationID(String locationID);
    //查询所有基地
    List<ObjectBaseBasicInfoEntity> queryAllBase();
    //根据基地ID查询事件
    List<ObjectEventOutput> queryAllEventByBaseID(EventQueryByID input);
    //查询所有人物（有事件的）
    List<ObjectPerson> queryAllPerson();
    //根据人物ID或姓名查找事件
    List<ObjectEventOutput> queryAllEventByPersonID(Integer renwuid,String name);
    //查询所有船舶
    List<ObjectShipBasicInfoEntity> queryAllShip();
    //根据船舶ID查询事件--包含进出港
    List<ObjectEventOutput> queryEventByShipID(Integer shipID);
    //查询舰船所有事件
    List<ObjectEventOutput> queryAllEventByShipID(int shipID);
    //根据基地id查询基地
    ObjectBaseBasicInfoEntity queryBaseByBaseID(int baseID);
    ObjectBaseBasicInfoEntity queryOtherBaseByBaseID(int baseID);
    //根据人员id查询人员
    ObjectPerson queryPersonByPersonID(int personID);

    List<ObjectPerson> queryPersonByPersonIDs(QueryPersonOrShipsInput input);

}
