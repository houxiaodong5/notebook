package com.cetc54.zkb.ky.controller.output.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("舰船时间统计输出类")
public class ShipTimeStatisticOutput {
    @ApiModelProperty("时间")
    private String time;
    @ApiModelProperty("进港数量")
    private Integer jgNumber;
    @ApiModelProperty("离港数量")
    private Integer lgNumber;
    @ApiModelProperty("在港数量")
    private Integer zgNumber;

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getJgNumber() {
        return this.jgNumber;
    }

    public void setJgNumber(Integer jgNumber) {
        this.jgNumber = jgNumber;
    }

    public Integer getLgNumber() {
        return this.lgNumber;
    }

    public void setLgNumber(Integer lgNumber) {
        this.lgNumber = lgNumber;
    }

    public Integer getZgNumber() {
        return this.zgNumber;
    }

    public void setZgNumber(Integer zgNumber) {
        this.zgNumber = zgNumber;
    }
}
