package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonByConditionsInput;
import com.cetc54.zkb.ky.controller.output.person.ConditionsOfFilter;
import com.cetc54.zkb.ky.controller.output.person.HistoryOfWork;
import com.cetc54.zkb.ky.controller.output.person.PersonOutput;
import com.cetc54.zkb.ky.controller.output.person.PersonRelationMsg;
import com.cetc54.zkb.ky.dao.entity.ObjectHonor;
import com.cetc54.zkb.ky.dao.entity.ObjectMilitaryActivity;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;
import com.cetc54.zkb.ky.dao.entity.ObjectSchool;
import com.cetc54.zkb.ky.elasticsearch.document.Person;
import com.cetc54.zkb.ky.elasticsearch.repository.PersonRepository;
import com.cetc54.zkb.ky.service.PersonService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.List;

@Api("人员筛选相关controller")
@RestController
public class PersonController extends BaseController {
    @Autowired
    private PersonService personService;
    @Autowired
    private PersonRepository personRepository;

    @ApiOperation("返回人选筛选筛选条件")
    @GetMapping({"/query/conditions/of/filter"})
    public DataResponse<ConditionsOfFilter> queryConditionsOfFilter(){
        return this.success(personService.queryConditionsOfFilter());
    }

    @ApiOperation("根据条件进行人物筛选")
    @PostMapping({"/query/person/by/conditions"})
    public DataResponse<PageInfo<ObjectPerson>> queryPersonByConditions(@RequestBody QueryPersonByConditionsInput input){
        PageInfo<ObjectPerson> pageInfo = personService.queryPersonByConditions(input);
        return this.success(pageInfo);
    }

    @ApiOperation("查询人物学校信息")
    @PostMapping("/query/school/by/userID")
    //@ApiImplicitParam(name = "userID",value = "用户ID")
    public DataResponse<List<ObjectSchool>> querySchoolByUserID(int userID){
        return this.success(personService.querySchoolByUserID(userID));
    }

    @ApiOperation("查询人物作战经历")
    @PostMapping("/query/activity/of/military/by/userID")
    @ApiImplicitParam(name = "userID",value = "用户ID")
    public DataResponse<List<ObjectMilitaryActivity>> queryActivitiesOfMilitaryByUserID(int userID){
        return this.success(personService.queryActivitiesOfMilitaryByUserID(userID));
    }

    @ApiOperation("查询人物嘉奖情况")
    @PostMapping("/query/honor/by/userID")
    @ApiImplicitParam(name = "userID",value = "用户ID")
    public DataResponse<List<ObjectHonor>> queryHonorByUserID(int userID){
        return this.success(personService.queryHonorByUserID(userID));
    }

    @ApiOperation("查询人物工作经历")
    @PostMapping("/query/history/of/work/by/userID")
    @ApiImplicitParam(name = "userID",value = "用户ID")
    public DataResponse<HistoryOfWork> queryHistoryOfWorkByUserID(int userID){
        return this.success(personService.queryHistoryOfWorkByUserID(userID));
    }

    @ApiOperation("查询人物经历")
    @PostMapping("/query/history/of/person/by/userID")
    @ApiImplicitParam(name = "userID",value = "用户ID")
    public DataResponse<PersonRelationMsg> queryHistoryOfPersonByUserID(int userID){
        PersonRelationMsg msg = new PersonRelationMsg();
        try {
            List<ObjectSchool> schoolList = personService.querySchoolByUserID(userID);
            List<ObjectMilitaryActivity> militaryActivityList = personService.queryActivitiesOfMilitaryByUserID(userID);
            List<ObjectHonor> honorList = personService.queryHonorByUserID(userID);
            HistoryOfWork historyOfWork = personService.queryHistoryOfWorkByUserID(userID);
            msg.setXx(schoolList);
            msg.setZzjl(militaryActivityList);
            msg.setJjqk(honorList);
            msg.setGzjl(historyOfWork);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            return this.success(msg);
        }

    }

    /*@ApiOperation("根据人名检索")
    @PostMapping("/query/person/by/name")
    public DataResponse<List<PersonOutput>> queryPersonByName(@RequestBody QueeryPersonByName person){
        //List<Person> people = personRepository.queryPersonByZwxm(person.getName());
        List<PersonOutput> list=personService.queryPersonByName(person.getName());
        return this.success(list);
    }*/

    @ApiOperation("查询所有人名")
    @PostMapping("/query/all/person/name")
    public DataResponse<HashSet<String>> queryAllPerson(){
        //List<Person> people = personRepository.queryPersonByZwxm(person.getName());
        HashSet<String> list=personService.queryAllPerson();
        return this.success(list);
    }

    @ApiOperation("查询所有人简要信息")
    @PostMapping("/query/all/person/simple/message")
    public DataResponse<List<Person>> queryAllPersonSimpleMsg(){
        //List<Person> people = personRepository.queryPersonByZwxm(person.getName());
        List<Person> list=personService.queryAllPersonSimpleMsg();
        return this.success(list);
    }

    @ApiOperation("查询所有人物信息-分页展示")
    @PostMapping("/query/all/person/message")
    public DataResponse<PageInfo<PersonOutput>> queryAllPersonMessage(@RequestBody QueryByPage input){
        return this.success(personService.queryAllPersonMessage(input));
    }

    @ApiOperation("用户编辑人物信息")
    @PostMapping("/update/person/message")
    public DataResponse<String>  updatePersonMessage(HttpServletRequest request, @RequestBody PersonOutput personOutput){
        return this.success(this.success(personService.updatePersonMessage(request,personOutput)));
    }

    @ApiOperation("用户修改库中人物图像")
    @PostMapping(value = "/update/person/img",headers = "content-type=multipart/form-data")
    public DataResponse<String> updatePersonImg( @RequestParam(value = "userID") int userID,@RequestParam(value = "personID") int personID, @RequestParam(value = "file") MultipartFile file){
        return this.success(personService.updatePersonImg(userID,personID,file));
    }






}
