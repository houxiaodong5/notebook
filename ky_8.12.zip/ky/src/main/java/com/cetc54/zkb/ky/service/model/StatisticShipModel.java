package com.cetc54.zkb.ky.service.model;

public class StatisticShipModel {
    private String time;
    private Integer zgzt;
    private String format;
    private String jdid;

    public String getTime() {
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getZgzt() {
        return this.zgzt;
    }

    public void setZgzt(Integer zgzt) {
        this.zgzt = zgzt;
    }

    public String getFormat() {
        return this.format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getJdid() {
        return this.jdid;
    }

    public void setJdid(String jdid) {
        this.jdid = jdid;
    }
}
