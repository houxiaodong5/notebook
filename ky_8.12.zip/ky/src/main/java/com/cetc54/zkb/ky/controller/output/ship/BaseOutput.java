package com.cetc54.zkb.ky.controller.output.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("基地输出类")
public class BaseOutput {
    @ApiModelProperty("基地ID")
    private Integer jdid;
    @ApiModelProperty("中心点经度")
    private Float zxdjd;
    @ApiModelProperty("中心点纬度")
    private Float zxdwd;
    @ApiModelProperty("基地中文名")
    private String jdzwm;
    @ApiModelProperty("基地英文名")
    private String jdywm;

    public Integer getJdid() {
        return this.jdid;
    }

    public void setJdid(Integer jdid) {
        this.jdid = jdid;
    }

    public Float getZxdjd() {
        return this.zxdjd;
    }

    public void setZxdjd(Float zxdjd) {
        this.zxdjd = zxdjd;
    }

    public Float getZxdwd() {
        return this.zxdwd;
    }

    public void setZxdwd(Float zxdwd) {
        this.zxdwd = zxdwd;
    }

    public String getJdzwm() {
        return this.jdzwm;
    }

    public void setJdzwm(String jdzwm) {
        this.jdzwm = jdzwm;
    }

    public String getJdywm() {
        return this.jdywm;
    }

    public void setJdywm(String jdywm) {
        this.jdywm = jdywm;
    }
}

