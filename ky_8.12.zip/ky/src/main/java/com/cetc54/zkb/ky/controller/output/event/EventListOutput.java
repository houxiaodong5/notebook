package com.cetc54.zkb.ky.controller.output.event;

import io.swagger.annotations.ApiModelProperty;

public class EventListOutput {
    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("uuid")
    private String uuid;
    @ApiModelProperty("标题")
    //private String bt;
    private String label;
    @ApiModelProperty("坐标纬度")
    private String zbwd;
    @ApiModelProperty("坐标经度")
    private String zbjd;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   /* public String getBt() {
        return this.bt;
    }

    public void setBt(String bt) {
        this.bt = bt;
    }*/

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getZbwd() {
        return this.zbwd;
    }

    public void setZbwd(String zbwd) {
        this.zbwd = zbwd;
    }

    public String getZbjd() {
        return this.zbjd;
    }

    public void setZbjd(String zbjd) {
        this.zbjd = zbjd;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }
}
