package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
import java.util.List;

/**
 *  西太地区：所有基地按时间统计演习事件
 * */
public class StatisticsManoeuvreOutput implements Serializable {

    private  String type="演习";
    private  String timeType;
    private List<String> time;
    private List<Integer> num;
    private int baseID;
    private String zwmc;
    private String ywmc;



    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public List<String> getTime() {
        return time;
    }

    public void setTime(List<String> time) {
        this.time = time;
    }

    public List<Integer> getNum() {
        return num;
    }

    public void setNum(List<Integer> num) {
        this.num = num;
    }

    public int getBaseID() {
        return baseID;
    }

    public void setBaseID(int baseID) {
        this.baseID = baseID;
    }

    public String getZwmc() {
        return zwmc;
    }

    public void setZwmc(String zwmc) {
        this.zwmc = zwmc;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTimeType() {
        return timeType;
    }

    @Override
    public String toString() {
        return "StatisticsManoeuvreOutput{" +
                "type='" + type + '\'' +
                ", timeType='" + timeType + '\'' +
                ", time=" + time +
                ", num=" + num +
                ", baseID=" + baseID +
                ", zwmc='" + zwmc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                '}';
    }
}
