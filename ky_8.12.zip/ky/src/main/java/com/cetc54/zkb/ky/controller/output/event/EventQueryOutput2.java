package com.cetc54.zkb.ky.controller.output.event;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class EventQueryOutput2 {
    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("uuid")
    private String uuid;
    @ApiModelProperty("国家")
    private String country;
    @ApiModelProperty("威胁等级")
    private String wxdj;
    @ApiModelProperty("事件类型")
    private String type;
    @ApiModelProperty("标题")
    private String label;
    @ApiModelProperty("坐标纬度")
    private String zbwd;
    @ApiModelProperty("坐标经度")
    private String zbjd;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getWxdj() {
        return wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getZbwd() {
        return zbwd;
    }

    public void setZbwd(String zbwd) {
        this.zbwd = zbwd;
    }

    public String getZbjd() {
        return zbjd;
    }

    public void setZbjd(String zbjd) {
        this.zbjd = zbjd;
    }

    @Override
    public String toString() {
        return "EventQueryOutput2{" +
                "id=" + id +
                ", uuid='" + uuid + '\'' +
                ", country='" + country + '\'' +
                ", wxdj='" + wxdj + '\'' +
                ", type='" + type + '\'' +
                ", label='" + label + '\'' +
                ", zbwd='" + zbwd + '\'' +
                ", zbjd='" + zbjd + '\'' +
                '}';
    }
}
