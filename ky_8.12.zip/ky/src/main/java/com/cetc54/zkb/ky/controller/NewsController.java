package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.QueryDataPage;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.NewsOutputByPage;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutputByPage;
import com.cetc54.zkb.ky.controller.output.source.OutputSource;
import com.cetc54.zkb.ky.dao.entity.NewsEntitry;
import com.cetc54.zkb.ky.dao.entity.NewsEntity;
import com.cetc54.zkb.ky.service.NewsService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntBinaryOperator;


@Api("最新爬取数据controller")
@RestController
public class NewsController extends BaseController {
    private final static ConcurrentHashMap<Integer, Integer> map = new ConcurrentHashMap<>();
    public static NewsEntitry newsEntitrie;
    @Resource
    private NewsService newsService;

    @ApiOperation("实时推送最新爬取的数据")
    @GetMapping("/news/latest/query")
    public DataResponse<NewsEntitry> queryLatestNews() {
        if (newsEntitrie == null) {
            queryNews();
        }
        return this.success(this.newsEntitrie);
    }

    //定时查询数据库(5s)
    @Scheduled(cron = "*/5 * * * * ?")
    public synchronized void queryNews() {
        NewsEntitry news = newsService.queryLatestNews();
        if(null!=news){
            newsEntitrie = news;
        }

    }

    @ApiOperation("查询所有爬取网站")
    @GetMapping("/all/source/query")
    public DataResponse<List<OutputSource>> queryAllSource() {
        return this.success(newsService.queryAllSource());
    }

    @ApiOperation("依据爬取网站查询已爬数据")
    @PostMapping("/query/data/by/source")
    public DataResponse<ObjectEventOutput> queryDataBySource(@RequestBody QueryDataPage queryDataPage) {
        PageInfo<ObjectEventOutput> pageInfo = newsService.queryDataBySource(queryDataPage);
        return this.success(pageInfo);
    }

    @ApiOperation("依据爬取网站查询已爬数据分页")
    @PostMapping("/query/data/by/source1")
    public DataResponse<ObjectEventOutput> queryDataBySource1(@RequestBody QueryDataPage queryDataPage) {
        ObjectEventOutputByPage output = newsService.queryDataBySource1(queryDataPage);
        return this.success(output);
    }

    @ApiOperation("查看最新新闻-图片专栏")
    @PostMapping("/query/latest/image/news")
    public DataResponse<NewsOutputByPage> queryImageNewsTimely(@RequestBody QueryByPage page){
        return this.success(newsService.queryImageNewsTimely(page));
    }

    @ApiOperation("查看最新新闻-视频专栏")
    @PostMapping("/query/latest/video/news")
    public DataResponse<NewsOutputByPage> queryVideoNewsTimely(@RequestBody QueryByPage page){
        return this.success(newsService.queryVideoNewsTimely(page));
    }

    @ApiOperation("查看最新新闻-杂志专栏")
    @PostMapping("/query/latest/pdf/news")
    public DataResponse<NewsOutputByPage> queryPdfNewsTimely(@RequestBody QueryByPage page){
        return this.success(newsService.queryPdfNewsTimely(page));
    }


}
