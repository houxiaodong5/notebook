package com.cetc54.zkb.ky.service.impl;

import com.cetc54.zkb.ky.controller.output.country.ObjectCountryOutput;
import com.cetc54.zkb.ky.dao.CountryDao;
import com.cetc54.zkb.ky.service.CountryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class CountryImpl implements CountryService {
    @Resource
    private CountryDao countryDao;

    public List<ObjectCountryOutput> queryAllCountry(String country) {
        return this.countryDao.queryAllCountry(country);
    }

}