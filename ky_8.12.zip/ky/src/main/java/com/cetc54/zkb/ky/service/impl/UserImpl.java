package com.cetc54.zkb.ky.service.impl;

import com.cetc54.zkb.ky.controller.input.user.UserInput;
import com.cetc54.zkb.ky.controller.input.user.UserViewRecord;
import com.cetc54.zkb.ky.controller.output.user.UserOutput;
import com.cetc54.zkb.ky.dao.UserDao;
import com.cetc54.zkb.ky.dao.entity.UserInfoEntity;
import com.cetc54.zkb.ky.dao.entity.UserViewRecordEntity;
import com.cetc54.zkb.ky.service.UserService;
import com.cetc54.zkb.ky.util.MD5Util;
import com.cetc54.zkb.ky.util.StringUtil;
import com.cetc54.zkb.ky.util.TimeUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;

@Service
@Transactional
public class UserImpl implements UserService {
    @Autowired
    private UserDao userDao;
    private Logger logger = LoggerFactory.getLogger(UserImpl.class);

    @Override
    public String registerUser(UserInput input) {
        if (StringUtils.isEmpty(input.getName()) || StringUtils.isEmpty(input.getPassword())) {
            return "用户名和密码不可为空";
        }
        //密码处理
        try {
            String salt = StringUtil.getRandomString(6);
            String realPWD = MD5Util.md5(input.getPassword() + salt);
            UserInfoEntity userInfoEntity = new UserInfoEntity(input.getName(), realPWD, salt);

            if (null == userDao.selectByName(input.getName())) {
                userDao.registerUser(userInfoEntity);
                return "注册成功";
            }

            return "该用户名已存在！";
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            logger.error("用户注册失败");
            return "操作失败";
        }
    }

    @Override
    public UserOutput login(HttpServletRequest request, UserInput input) throws Exception {
        try {
            String name = input.getName();
            if (StringUtils.isNotBlank(input.getPassword()) && StringUtils.isNotBlank(name)) {
                UserInfoEntity userInfoEntity = userDao.selectByName(name);
                String salt = userInfoEntity.getSalt();
                if ((MD5Util.md5(input.getPassword() + salt)).equals(userInfoEntity.getPassword())) {
                    UserOutput userOutput = new UserOutput();
                    BeanUtils.copyProperties(userInfoEntity, userOutput);
                    request.getSession().setAttribute("user", userInfoEntity);
                    request.getSession().setMaxInactiveInterval(30 * 60);//该session不使用 则30分钟后过期
                    return userOutput;
                }else {
                    throw new Exception("用户名或密码有误");

                }
            }
            return null;
        } catch (Exception e) {
            logger.error("操作失败");
            throw new Exception("操作失败");
        }
    }

    @Override
    public Boolean logout(HttpServletRequest request) {
        try {
            request.getSession().invalidate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public String userViewRecord(UserViewRecord userViewRecord) throws Exception {
        if (StringUtils.isBlank(userViewRecord.getEventID()) || 0 == userViewRecord.getUserID()
                ||StringUtils.isBlank(userViewRecord.getEventType())) {
            return "参数不可为空";
        }
        try {
            UserViewRecordEntity insertData = new UserViewRecordEntity();
            BeanUtils.copyProperties(userViewRecord, insertData);
            insertData.setUpdateTime(TimeUtil.dateTimeFormatter.format(new Date()));
            //根据事件id和用户id查询查看记录
            UserViewRecordEntity recordEntity = userDao.queryViewRecordByEventIDAndUserID(userViewRecord);

            if (recordEntity == null) {
                insertData.setViewNumber(1);
                userDao.insertUserViewRecord(insertData);
            } else {
                insertData.setViewNumber(recordEntity.getViewNumber() + 1);
                userDao.updateUserViewRecord(insertData);
            }
            return "操作成功";
        } catch (Exception e) {
            logger.error("操作失败");
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new RuntimeException("操作失败");

        }
    }
}
