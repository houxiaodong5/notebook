package com.cetc54.zkb.ky.controller.output.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel("事件查询输出类")
public class EventQueryOutput {
    @ApiModelProperty("国家")
    private String label;
    @ApiModelProperty("威胁等级对象")
    private List<Wxdj> children;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<Wxdj> getChildren() {
        return children;
    }

    public void setChildren(List<Wxdj> children) {
        this.children = children;
    }

    public class Wxdj {
        @ApiModelProperty("威胁等级")
        private String label;
        @ApiModelProperty("事件类型对象")
        private List<EventTag> children;

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public List<EventTag> getChildren() {
            return children;
        }

        public void setChildren(List<EventTag> children) {
            this.children = children;
        }

        public class EventTag {
            @ApiModelProperty("事件类型")
            private String label;
            @ApiModelProperty("事件类型")
            private List<EventListOutput> children;

            public String getLabel() {
                return label;
            }

            public void setLabel(String label) {
                this.label = label;
            }

            public List<EventListOutput> getChildren() {
                return children;
            }

            public void setChildren(List<EventListOutput> children) {
                this.children = children;
            }
        }
    }
}
