package com.cetc54.zkb.ky.constraint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class BaseController {
    protected SuccessResponse success = SuccessResponse.getInstance();

    protected <T> DataResponse success(T t){
        return new DataResponse(t);
    }

    public static final Logger logger = LoggerFactory.getLogger(BaseController.class);
}
