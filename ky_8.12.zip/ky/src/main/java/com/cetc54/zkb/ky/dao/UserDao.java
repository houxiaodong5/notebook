package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.input.user.UserViewRecord;
import com.cetc54.zkb.ky.dao.entity.UserInfoEntity;
import com.cetc54.zkb.ky.dao.entity.UserViewRecordEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

public interface UserDao {

    //@SelectProvider(type = UserSql.class,method = "registerUser")
    @Insert("INSERT INTO ky_user(name,password,salt)  values (#{name},#{password},#{salt}) ")
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="id", before=false, resultType=int.class)
    void registerUser(UserInfoEntity user);


    //根据用户名查询用户信息
    @Select("select * from ky_user where name=#{name}")
    UserInfoEntity selectByName(String name);

    //根据事件id和用户id查看事件观看次数
    @Select("select * from relation_ky_user_event where user_id=#{userID} and event_id=#{eventID}")
    UserViewRecordEntity queryViewRecordByEventIDAndUserID(UserViewRecord userViewRecord);

    //插入用户观看事件
    @Insert("insert into relation_ky_user_event(user_id,event_id,view_number,update_time,event_type) values(#{userID},#{eventID},#{viewNumber},#{updateTime},#{eventType})")
    void insertUserViewRecord(UserViewRecordEntity entity);

    @Update("update relation_ky_user_event set view_number=#{viewNumber},update_time=#{updateTime} where  user_id=#{userID} and event_id=#{eventID}")
    void updateUserViewRecord(UserViewRecordEntity entity);


}
