package com.cetc54.zkb.ky.controller.input.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel("根据id查询事件输入类")
public class EventQueryByID {
    @ApiModelProperty(value = "id")
    private Integer id;
    @ApiModelProperty(value = "每页展示数量")
    private int pageSize;
    @ApiModelProperty(value = "当前页码")
    private int pageNum;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    @Override
    public String toString() {
        return "EventQueryByID{" +
                "id=" + id +
                ", pageSize=" + pageSize +
                ", pageNum=" + pageNum +
                '}';
    }
}
