package com.cetc54.zkb.ky.controller.output.country;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("国家返回结果")
public class ObjectCountryOutput {
    @ApiModelProperty("主键")
    private Integer id;
    @ApiModelProperty("国家中文")
    private String gjCn;
    @ApiModelProperty("国家英文")
    private String gjEn;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGjCn() {
        return this.gjCn;
    }

    public void setGjCn(String gjCn) {
        this.gjCn = gjCn;
    }

    public String getGjEn() {
        return this.gjEn;
    }

    public void setGjEn(String gjEn) {
        this.gjEn = gjEn;
    }
}
