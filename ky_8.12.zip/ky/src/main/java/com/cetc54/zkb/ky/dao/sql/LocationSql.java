package com.cetc54.zkb.ky.dao.sql;

import com.cetc54.zkb.ky.dao.entity.ObjectBaseBasicInfoEntity;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

/**
 * Created by Administrator on 2019/5/25/025.
 */
public class LocationSql {

    //保证返回location处所有事件
    public static String queryAllLocation(){
        return "SELECT t1.*  FROM `object_location` t1,`relation_location_event` t2 where   t1.`ddid` = t2.`location_id` and t2.`event_id` IS NOT NULL and t2.`event_id`  !=''  and t2.location_name is not null";
    }

    public static String queryAllEventByLocationID(String locationID){
        return "SELECT t2.id,t2.uuid,t2.bt,t2.gjc,t2.fssj,t2.jssj,t2.zbjd,t2.zbwd,t2.tag1,t2.gjmc,t2.gjid,t2.dd,t2.wxdj,t2.rksj from relation_location_event t1 LEFT JOIN object_event t2 on t1.`event_id` =t2.`uuid` where t1.`location_id`='"+locationID+"'";

    }

    //查询所有基地
    public static String queryAllBase(){
        return "SELECT * FROM `object_base_basic_info` ORDER BY jdid ";
    }

    //根据基地ID查询基地事件
    public static String queryAllEventByBaseID(Integer jdid){
        return "select c.* from( SELECT t2.id,t2.uuid,t2.bt,t2.gjc,t2.fssj,t2.jssj,t2.zbjd,t2.zbwd,t2.tag1,t2.gjmc,t2.gjid,t2.dd,t2.wxdj,t2.rksj  from `relation_base_event`  t1 LEFT JOIN `object_event`   t2 on t1.`event_id` =t2.`uuid` where t1.`base_id` ="+jdid+" and t2.id is not null ) c ORDER BY c.fssj  DESC";
    }

    //查询所有人物（有事件的）
    public static String queryAllPerson(){
        //return "SELECT  DISTINCT  t1.* from `object_person`  t1 LEFT JOIN `relation_person_event`  t2 on t1.renwuid=t2.person_id  order by t1.ywxm";
        return "SELECT  DISTINCT  t1.renwuid,t1.zwxm,t1.ywxm,t1.jx,t1.zw,t1.rzsj,t1.csd,t1.zylb,t1.txpic,t1.txszwj,t1.ssjg,t1.ssjgid,t1.sjzh,t1.rylb,t1.zjxy,t1.rwmbtz,t1.gj,t1.gz,t1.jy,t1.fxjl,t1.jiangxiang,t1.cj,t1.tx,t1.lj,t1.rksj,t1.gdb_used,t1.yxrq from `object_person`  t1  order by t1.ywxm";
    }

    //根据人物ID查询所有事件
    public static String queryAllEventByPersonID(Integer renwuid,String name){
        if(renwuid!=null&&0!=renwuid) {
            return "SELECT t2.id,t2.uuid,t2.bt,t2.gjc,t2.fssj,t2.jssj,t2.zbjd,t2.zbwd,t2.tag1,t2.gjmc,t2.gjid,t2.dd,t2.wxdj,t2.rksj from `relation_person_event`  t1 LEFT JOIN object_event t2 on t1.`event_id` =t2.`uuid` where t1.`person_id`=" + renwuid+"   order by t2.`fssj` desc" ;
        }

        if(null!=name){
            return "SELECT t2.id,t2.uuid,t2.bt,t2.gjc,t2.fssj,t2.jssj,t2.zbjd,t2.zbwd,t2.tag1,t2.gjmc,t2.gjid,t2.dd,t2.wxdj,t2.rksj from `relation_person_event`  t1 LEFT JOIN object_event t2 on t1.`event_id` =t2.`uuid` where t1.`person_name` ='"+name+"' order by t2.`fssj` desc";
        }
        else return null;

    }

    //查询所有船舶信息
    public static String queryAllShip(){
        return "SELECT id,mc,bh,tp,ssgj,tp_blob tpBlob FROM `object_ship_basic_info` ORDER BY `mc` ";
    }

    //根据船舶ID查询事件   含有进出港数据的事件
    public static String queryEventByShipID(Integer shipID){
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj ,t2.`gxlx`as shipTag  FROM `object_event` t1 ");
        buffer.append("LEFT join relation_ship_location t2 on t1.`uuid` =t2.`event_id` ");
        buffer.append("where t1.`uuid` in  ( ");
        buffer.append("SELECT  distinct event_id   from `relation_ship_location`  WHERE `ship_id` ="+shipID+"  ORDER BY `event_id` ) ");
        buffer.append("ORDER BY t1.`fssj` DESC  ");
        //return "SELECT t2.* from `relation_ship_event` t1 LEFT JOIN object_event t2 on t1.`event_id` =t2.`uuid` where t1.`ship_id` ="+shipID;
        return buffer.toString();
    }

    //查询基地
    public static String queryBaseByBaseID(Integer bridgeID){
        return "SELECT * FROM `object_base_basic_info` WHERE bridgeID="+bridgeID;
    }

    //查询基地联队基础信息
    public static String queryBaseUnitsInfoByBaseID(@Param("realBaseID") String realBaseID){
        return "SELECT id,name FROM `object_unit_info` WHERE id in(select unitID FROM `relation_base_unit` where jdID="+realBaseID+")";
    }

    //查询人员
    public static String queryPersonByPersonID(Integer personID){
        return  "SELECT *  FROM `object_person` WHERE `renwuid` ="+personID;
    }

    public static String queryPersonByPersonIDs(String sql){
        return sql;
    }

    //根据基地id查询基地信息
    public static String  queryBaseByID(@Param("baseID") int baseID){
        return "SELECT * FROM `object_base_basic_info` WHERE  jdid=" + baseID;
    }


}
