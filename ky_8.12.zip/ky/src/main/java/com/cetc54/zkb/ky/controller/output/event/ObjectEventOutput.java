package com.cetc54.zkb.ky.controller.output.event;

import com.cetc54.zkb.ky.util.TimeUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.format.annotation.DateTimeFormat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@ApiModel("事件详情")
public class ObjectEventOutput {
    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("uuid")
    private String uuid;
    @ApiModelProperty("标题")
    private String bt;
    @ApiModelProperty("简介")
    private String jj;
    @ApiModelProperty("关键词")
    private String gjc;
    @ApiModelProperty("发生时间")
    private String fssj;
    @ApiModelProperty("结束时间")
    private String jssj;
    @ApiModelProperty("坐标纬度")
    private String zbwd;
    @ApiModelProperty("坐标经度")
    private String zbjd;
    @ApiModelProperty("标签1")
    private String tag1;
    @ApiModelProperty("标签2")
    private String tag2;
    @ApiModelProperty("标签3")
    private String tag3;
    @ApiModelProperty("国家名称")
    private String gjmc;
    @ApiModelProperty("国家id")
    private String gjid;
    @ApiModelProperty("地点")
    private String dd;
    @ApiModelProperty("威胁等级")
    private String wxdj;
    @ApiModelProperty("入库时间")
    private String rksj;
    @ApiModelProperty("id")
    private Integer gdbUsed;
    private List<String> tags=new ArrayList<>();
    private String shipTag;
    private String xwly;
    private String xwlyCn;

    public String getXwly() {
        return xwly;
    }

    public void setXwly(String xwly) {
        this.xwly = xwly;
    }

    public String getXwlyCn() {
        return xwlyCn;
    }

    public void setXwlyCn(String xwlyCn) {
        this.xwlyCn = xwlyCn;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getBt() {
        return bt;
    }

    public void setBt(String bt) {
        this.bt = bt;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getGjc() {
        return gjc;
    }

    public void setGjc(String gjc) {
        this.gjc = gjc;
    }

    public String getFssj() {
        return fssj;
    }

    public void setFssj(String fssj) {
        this.fssj = TimeUtil.formateStringTime(fssj);
    }

    public String getJssj() {
        return jssj;
    }

    public void setJssj(String jssj) {
        this.jssj = TimeUtil.formateStringTime(jssj);
    }

    public String getZbwd() {
        return zbwd;
    }

    public void setZbwd(String zbwd) {
        this.zbwd = zbwd;
    }

    public String getZbjd() {
        return zbjd;
    }

    public void setZbjd(String zbjd) {
        this.zbjd = zbjd;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getGjmc() {
        return gjmc;
    }

    public void setGjmc(String gjmc) {
        this.gjmc = gjmc;
    }

    public String getGjid() {
        return gjid;
    }

    public void setGjid(String gjid) {
        this.gjid = gjid;
    }

    public String getDd() {
        return dd;
    }

    public void setDd(String dd) {
        this.dd = dd;
    }

    public String getWxdj() {
        return wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }

    public Integer getGdbUsed() {
        return gdbUsed;
    }

    public void setGdbUsed(Integer gdbUsed) {
        this.gdbUsed = gdbUsed;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getShipTag() {
        return shipTag;
    }

    public void setShipTag(String shipTag) {
        this.shipTag = shipTag;
    }

    @Override
    public String toString() {
        return "ObjectEventOutput{" +
                "id=" + id +
                ", uuid='" + uuid + '\'' +
                ", bt='" + bt + '\'' +
                ", jj='" + jj + '\'' +
                ", gjc='" + gjc + '\'' +
                ", fssj='" + fssj + '\'' +
                ", jssj='" + jssj + '\'' +
                ", zbwd='" + zbwd + '\'' +
                ", zbjd='" + zbjd + '\'' +
                ", tag1='" + tag1 + '\'' +
                ", tag2='" + tag2 + '\'' +
                ", tag3='" + tag3 + '\'' +
                ", gjmc='" + gjmc + '\'' +
                ", gjid='" + gjid + '\'' +
                ", dd='" + dd + '\'' +
                ", wxdj='" + wxdj + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdbUsed=" + gdbUsed +
                ", tags=" + tags +
                ", shipTag='" + shipTag + '\'' +
                ", xwly='" + xwly + '\'' +
                ", xwlyCn='" + xwlyCn + '\'' +
                '}';
    }
}
