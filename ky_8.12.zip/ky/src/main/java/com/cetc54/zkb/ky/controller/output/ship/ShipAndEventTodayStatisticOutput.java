package com.cetc54.zkb.ky.controller.output.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("当前船舶及事件情况统计")
public class ShipAndEventTodayStatisticOutput {
    @ApiModelProperty("基地ID")
    private Integer jdid;
    @ApiModelProperty("中心点经度")
    private Float zxdjd;
    @ApiModelProperty("中心点纬度")
    private Float zxdwd;
    @ApiModelProperty("基地中文名")
    private String jdzwm;
    @ApiModelProperty("基地英文名")
    private String jdywm;
    @ApiModelProperty("舰船数量")
    private Integer jcNumber;
    @ApiModelProperty("事件数量")
    private Integer eventNumber;
    @ApiModelProperty("在港舰船数量")
    private Integer zgNum;
    @ApiModelProperty("进港舰船数量")
    private Integer jgNum;
    @ApiModelProperty("离港舰船数量")
    private Integer lgNum;

    public Integer getJdid() {
        return this.jdid;
    }

    public void setJdid(Integer jdid) {
        this.jdid = jdid;
    }

    public Float getZxdjd() {
        return this.zxdjd;
    }

    public void setZxdjd(Float zxdjd) {
        this.zxdjd = zxdjd;
    }

    public Float getZxdwd() {
        return this.zxdwd;
    }

    public void setZxdwd(Float zxdwd) {
        this.zxdwd = zxdwd;
    }

    public String getJdzwm() {
        return this.jdzwm;
    }

    public void setJdzwm(String jdzwm) {
        this.jdzwm = jdzwm;
    }

    public String getJdywm() {
        return this.jdywm;
    }

    public void setJdywm(String jdywm) {
        this.jdywm = jdywm;
    }

    public Integer getJcNumber() {
        return this.jcNumber;
    }

    public void setJcNumber(Integer jcNumber) {
        this.jcNumber = jcNumber;
    }

    public Integer getEventNumber() {
        return this.eventNumber;
    }

    public void setEventNumber(Integer eventNumber) {
        this.eventNumber = eventNumber;
    }

    public Integer getZgNum() {
        return this.zgNum;
    }

    public void setZgNum(Integer zgNum) {
        this.zgNum = zgNum;
    }

    public Integer getJgNum() {
        return this.jgNum;
    }

    public void setJgNum(Integer jgNum) {
        this.jgNum = jgNum;
    }

    public Integer getLgNum() {
        return this.lgNum;
    }

    public void setLgNum(Integer lgNum) {
        this.lgNum = lgNum;
    }
}

