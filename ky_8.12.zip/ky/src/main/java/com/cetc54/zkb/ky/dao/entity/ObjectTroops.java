package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;
import java.util.Arrays;

/**
 *      部队信息表
 * */
public class ObjectTroops implements Serializable {
    private String id;
    private String zwm;
    private String ywm;
    private String jc;
    private String nickname;
    private byte[] logo;
    private String founded;
    private String country;
    private int country_id;
    private String location;
    private int location_id;
    private String commander;
    private int commander_id;
    private String history;
    private String from_urls;
    private String rksj;
    private int gdb_used;
    private String branch;
    private String activeTime;
    private String f_type;
    private String  part;
    private String motto;
    private String engagements;
    private String decorations;
    private String insignia_period;
    private String insignia_period_img_url;
    private byte[] insignia_period_img;
    private String garrison;
    private int parentID;
    private String headquarters;
    private int airmenSize;
    private int aircraftSize;
    private String jlsj;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getZwm() {
        return zwm;
    }

    public void setZwm(String zwm) {
        this.zwm = zwm;
    }

    public String getYwm() {
        return ywm;
    }

    public void setYwm(String ywm) {
        this.ywm = ywm;
    }

    public String getJc() {
        return jc;
    }

    public void setJc(String jc) {
        this.jc = jc;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public String getFounded() {
        return founded;
    }

    public void setFounded(String founded) {
        this.founded = founded;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getCountry_id() {
        return country_id;
    }

    public void setCountry_id(int country_id) {
        this.country_id = country_id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    public String getCommander() {
        return commander;
    }

    public void setCommander(String commander) {
        this.commander = commander;
    }

    public int getCommander_id() {
        return commander_id;
    }

    public void setCommander_id(int commander_id) {
        this.commander_id = commander_id;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getFrom_urls() {
        return from_urls;
    }

    public void setFrom_urls(String from_urls) {
        this.from_urls = from_urls;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = rksj;
    }

    public int getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(int gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(String activeTime) {
        this.activeTime = activeTime;
    }

    public String getF_type() {
        return f_type;
    }

    public void setF_type(String f_type) {
        this.f_type = f_type;
    }

    public String getPart() {
        return part;
    }

    public void setPart(String part) {
        this.part = part;
    }

    public String getMotto() {
        return motto;
    }

    public void setMotto(String motto) {
        this.motto = motto;
    }

    public String getEngagements() {
        return engagements;
    }

    public void setEngagements(String engagements) {
        this.engagements = engagements;
    }

    public String getDecorations() {
        return decorations;
    }

    public void setDecorations(String decorations) {
        this.decorations = decorations;
    }

    public String getInsignia_period() {
        return insignia_period;
    }

    public void setInsignia_period(String insignia_period) {
        this.insignia_period = insignia_period;
    }

    public String getInsignia_period_img_url() {
        return insignia_period_img_url;
    }

    public void setInsignia_period_img_url(String insignia_period_img_url) {
        this.insignia_period_img_url = insignia_period_img_url;
    }

    public byte[] getInsignia_period_img() {
        return insignia_period_img;
    }

    public void setInsignia_period_img(byte[] insignia_period_img) {
        this.insignia_period_img = insignia_period_img;
    }

    public String getGarrison() {
        return garrison;
    }

    public void setGarrison(String garrison) {
        this.garrison = garrison;
    }

    public int getParentID() {
        return parentID;
    }

    public void setParentID(int parentID) {
        this.parentID = parentID;
    }

    public String getHeadquarters() {
        return headquarters;
    }

    public void setHeadquarters(String headquarters) {
        this.headquarters = headquarters;
    }

    public int getAirmenSize() {
        return airmenSize;
    }

    public void setAirmenSize(int airmenSize) {
        this.airmenSize = airmenSize;
    }

    public int getAircraftSize() {
        return aircraftSize;
    }

    public void setAircraftSize(int aircraftSize) {
        this.aircraftSize = aircraftSize;
    }

    public String getJlsj() {
        return jlsj;
    }

    public void setJlsj(String jlsj) {
        this.jlsj = TimeUtil.formateStringTime(jlsj);
    }

    @Override
    public String toString() {
        return "ObjectTroops{" +
                "id='" + id + '\'' +
                ", zwm='" + zwm + '\'' +
                ", ywm='" + ywm + '\'' +
                ", jc='" + jc + '\'' +
                ", nickname='" + nickname + '\'' +
                ", logo=" + Arrays.toString(logo) +
                ", founded='" + founded + '\'' +
                ", country='" + country + '\'' +
                ", country_id=" + country_id +
                ", location='" + location + '\'' +
                ", location_id=" + location_id +
                ", commander='" + commander + '\'' +
                ", commander_id=" + commander_id +
                ", history='" + history + '\'' +
                ", from_urls='" + from_urls + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdb_used=" + gdb_used +
                ", branch='" + branch + '\'' +
                ", activeTime='" + activeTime + '\'' +
                ", f_type='" + f_type + '\'' +
                ", part='" + part + '\'' +
                ", motto='" + motto + '\'' +
                ", engagements='" + engagements + '\'' +
                ", decorations='" + decorations + '\'' +
                ", insignia_period='" + insignia_period + '\'' +
                ", insignia_period_img_url='" + insignia_period_img_url + '\'' +
                ", insignia_period_img=" + Arrays.toString(insignia_period_img) +
                ", garrison='" + garrison + '\'' +
                ", parentID=" + parentID +
                ", headquarters='" + headquarters + '\'' +
                ", airmenSize=" + airmenSize +
                ", aircraftSize=" + aircraftSize +
                ", jlsj='" + jlsj + '\'' +
                '}';
    }
}
