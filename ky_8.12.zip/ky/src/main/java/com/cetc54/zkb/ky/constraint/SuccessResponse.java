package com.cetc54.zkb.ky.constraint;

/**
 * 说明:成功响应封装
 */
public class SuccessResponse extends Response {
    private static SuccessResponse successResponse = new SuccessResponse();

    public static SuccessResponse getInstance(){
        return successResponse;
    }

    private SuccessResponse(){
    }
}
