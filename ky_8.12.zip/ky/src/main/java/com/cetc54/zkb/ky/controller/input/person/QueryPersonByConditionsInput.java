package com.cetc54.zkb.ky.controller.input.person;

public class QueryPersonByConditionsInput {
    private String country;
    private String country_CN;
    private String militaryRank;
    private String militaryRank_CN;
    private String post;
    private String post_CN;
    private String category;
    private int pageSize;
    private int pageNum;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCountry_CN() {
        return country_CN;
    }

    public void setCountry_CN(String country_CN) {
        this.country_CN = country_CN;
    }

    public String getMilitaryRank() {
        return militaryRank;
    }

    public void setMilitaryRank(String militaryRank) {
        this.militaryRank = militaryRank;
    }

    public String getMilitaryRank_CN() {
        return militaryRank_CN;
    }

    public void setMilitaryRank_CN(String militaryRank_CN) {
        this.militaryRank_CN = militaryRank_CN;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getPost_CN() {
        return post_CN;
    }

    public void setPost_CN(String post_CN) {
        this.post_CN = post_CN;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }


    @Override
    public String toString() {
        return "QueryPersonByConditionsInput{" +
                "country='" + country + '\'' +
                ", country_CN='" + country_CN + '\'' +
                ", militaryRank='" + militaryRank + '\'' +
                ", militaryRank_CN='" + militaryRank_CN + '\'' +
                ", post='" + post + '\'' +
                ", post_CN='" + post_CN + '\'' +
                ", category='" + category + '\'' +
                ", pageSize=" + pageSize +
                ", pageNum=" + pageNum +
                '}';
    }
}
