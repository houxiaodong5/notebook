package com.cetc54.zkb.ky.controller.output.unit;

import java.io.Serializable;
import java.util.Arrays;

public class SimpleUnitPersonOutput implements Serializable {
    private int id;     //联队id
    private int pid;      //联队父id
    private String zwm;//联队中文名
    private String ywm;//联队英文名
    private int personID;  //personid
    private String personName; //commander字段

    private String zw;//person职位
    private byte[] txpic;//二次查询
    private String tx;//二次查询

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getZwm() {
        return zwm;
    }

    public void setZwm(String zwm) {
        this.zwm = zwm;
    }

    public String getYwm() {
        return ywm;
    }

    public void setYwm(String ywm) {
        this.ywm = ywm;
    }

    public int getPersonID() {
        return personID;
    }

    public void setPersonID(int personID) {
        this.personID = personID;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    public byte[] getTxpic() {
        return txpic;
    }

    public void setTxpic(byte[] txpic) {
        this.txpic = txpic;
    }

    public String getTx() {
        return tx;
    }

    public void setTx(String tx) {
        this.tx = tx;
    }

    @Override
    public String toString() {
        return "SimpleUnitPersonOutput{" +
                "id=" + id +
                ", pid=" + pid +
                ", zwm='" + zwm + '\'' +
                ", ywm='" + ywm + '\'' +
                ", personID=" + personID +
                ", personName='" + personName + '\'' +
                ", zw='" + zw + '\'' +
                ", txpic=" + Arrays.toString(txpic) +
                ", tx='" + tx + '\'' +
                '}';
    }
}
