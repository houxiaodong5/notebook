package com.cetc54.zkb.ky.dao.entity;

public class ObjectCountryEntity {
    private Integer id;
    private String gjCn;
    private String gjEn;
    private String pm;
    private String zs;
    private String sm;
    private String gs;
    private String zrk;
    private String kyrl;
    private String kfwrl;
    private String ndjlrl;
    private String zjrs;
    private String hyry;
    private String cbry;
    private String zfjys;
    private String zdl;
    private String gjl;
    private String ys;
    private String xl;
    private String zsjzsl;
    private String zsjgjl;
    private String zdtk;
    private String zjzc;
    private String zxhp;
    private String qyp;
    private String hjfsq;
    private String hjzzc;
    private String hkmj;
    private String hwj;
    private String qzj;
    private String qt;
    private String xxjj;
    private String xlt;
    private String dlz;
    private String sycl;
    private String hyl;
    private String tmcl;
    private String ldl;
    private String scqd;
    private String zygk;
    private String dlfgm;
    private String tlfgm;
    private String kfwjc;
    private String gfys;
    private String wz;
    private String whhhjcb;
    private String pjgml;
    private String gcydmj;
    private String hax;
    private String gxgj;
    private String sd;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return this.id;
    }

    public void setGjCn(String gjCn) {
        this.gjCn = gjCn;
    }

    public String getGjCn() {
        return this.gjCn;
    }

    public void setGjEn(String gjEn) {
        this.gjEn = gjEn;
    }

    public String getGjEn() {
        return this.gjEn;
    }

    public void setPm(String pm) {
        this.pm = pm;
    }

    public String getPm() {
        return this.pm;
    }

    public void setZs(String zs) {
        this.zs = zs;
    }

    public String getZs() {
        return this.zs;
    }

    public void setSm(String sm) {
        this.sm = sm;
    }

    public String getSm() {
        return this.sm;
    }

    public void setGs(String gs) {
        this.gs = gs;
    }

    public String getGs() {
        return this.gs;
    }

    public void setZrk(String zrk) {
        this.zrk = zrk;
    }

    public String getZrk() {
        return this.zrk;
    }

    public void setKyrl(String kyrl) {
        this.kyrl = kyrl;
    }

    public String getKyrl() {
        return this.kyrl;
    }

    public void setKfwrl(String kfwrl) {
        this.kfwrl = kfwrl;
    }

    public String getKfwrl() {
        return this.kfwrl;
    }

    public void setNdjlrl(String ndjlrl) {
        this.ndjlrl = ndjlrl;
    }

    public String getNdjlrl() {
        return this.ndjlrl;
    }

    public void setZjrs(String zjrs) {
        this.zjrs = zjrs;
    }

    public String getZjrs() {
        return this.zjrs;
    }

    public void setHyry(String hyry) {
        this.hyry = hyry;
    }

    public String getHyry() {
        return this.hyry;
    }

    public void setCbry(String cbry) {
        this.cbry = cbry;
    }

    public String getCbry() {
        return this.cbry;
    }

    public void setZfjys(String zfjys) {
        this.zfjys = zfjys;
    }

    public String getZfjys() {
        return this.zfjys;
    }

    public void setZdl(String zdl) {
        this.zdl = zdl;
    }

    public String getZdl() {
        return this.zdl;
    }

    public void setGjl(String gjl) {
        this.gjl = gjl;
    }

    public String getGjl() {
        return this.gjl;
    }

    public void setYs(String ys) {
        this.ys = ys;
    }

    public String getYs() {
        return this.ys;
    }

    public void setXl(String xl) {
        this.xl = xl;
    }

    public String getXl() {
        return this.xl;
    }

    public void setZsjzsl(String zsjzsl) {
        this.zsjzsl = zsjzsl;
    }

    public String getZsjzsl() {
        return this.zsjzsl;
    }

    public void setZsjgjl(String zsjgjl) {
        this.zsjgjl = zsjgjl;
    }

    public String getZsjgjl() {
        return this.zsjgjl;
    }

    public void setZdtk(String zdtk) {
        this.zdtk = zdtk;
    }

    public String getZdtk() {
        return this.zdtk;
    }

    public void setZjzc(String zjzc) {
        this.zjzc = zjzc;
    }

    public String getZjzc() {
        return this.zjzc;
    }

    public void setZxhp(String zxhp) {
        this.zxhp = zxhp;
    }

    public String getZxhp() {
        return this.zxhp;
    }

    public void setQyp(String qyp) {
        this.qyp = qyp;
    }

    public String getQyp() {
        return this.qyp;
    }

    public void setHjfsq(String hjfsq) {
        this.hjfsq = hjfsq;
    }

    public String getHjfsq() {
        return this.hjfsq;
    }

    public void setHjzzc(String hjzzc) {
        this.hjzzc = hjzzc;
    }

    public String getHjzzc() {
        return this.hjzzc;
    }

    public void setHkmj(String hkmj) {
        this.hkmj = hkmj;
    }

    public String getHkmj() {
        return this.hkmj;
    }

    public void setHwj(String hwj) {
        this.hwj = hwj;
    }

    public String getHwj() {
        return this.hwj;
    }

    public void setQzj(String qzj) {
        this.qzj = qzj;
    }

    public String getQzj() {
        return this.qzj;
    }

    public void setQt(String qt) {
        this.qt = qt;
    }

    public String getQt() {
        return this.qt;
    }

    public void setXxjj(String xxjj) {
        this.xxjj = xxjj;
    }

    public String getXxjj() {
        return this.xxjj;
    }

    public void setXlt(String xlt) {
        this.xlt = xlt;
    }

    public String getXlt() {
        return this.xlt;
    }

    public void setDlz(String dlz) {
        this.dlz = dlz;
    }

    public String getDlz() {
        return this.dlz;
    }

    public void setSycl(String sycl) {
        this.sycl = sycl;
    }

    public String getSycl() {
        return this.sycl;
    }

    public void setHyl(String hyl) {
        this.hyl = hyl;
    }

    public String getHyl() {
        return this.hyl;
    }

    public void setTmcl(String tmcl) {
        this.tmcl = tmcl;
    }

    public String getTmcl() {
        return this.tmcl;
    }

    public void setLdl(String ldl) {
        this.ldl = ldl;
    }

    public String getLdl() {
        return this.ldl;
    }

    public void setScqd(String scqd) {
        this.scqd = scqd;
    }

    public String getScqd() {
        return this.scqd;
    }

    public void setZygk(String zygk) {
        this.zygk = zygk;
    }

    public String getZygk() {
        return this.zygk;
    }

    public void setDlfgm(String dlfgm) {
        this.dlfgm = dlfgm;
    }

    public String getDlfgm() {
        return this.dlfgm;
    }

    public void setTlfgm(String tlfgm) {
        this.tlfgm = tlfgm;
    }

    public String getTlfgm() {
        return this.tlfgm;
    }

    public void setKfwjc(String kfwjc) {
        this.kfwjc = kfwjc;
    }

    public String getKfwjc() {
        return this.kfwjc;
    }

    public void setGfys(String gfys) {
        this.gfys = gfys;
    }

    public String getGfys() {
        return this.gfys;
    }

    public void setWz(String wz) {
        this.wz = wz;
    }

    public String getWz() {
        return this.wz;
    }

    public void setWhhhjcb(String whhhjcb) {
        this.whhhjcb = whhhjcb;
    }

    public String getWhhhjcb() {
        return this.whhhjcb;
    }

    public void setPjgml(String pjgml) {
        this.pjgml = pjgml;
    }

    public String getPjgml() {
        return this.pjgml;
    }

    public void setGcydmj(String gcydmj) {
        this.gcydmj = gcydmj;
    }

    public String getGcydmj() {
        return this.gcydmj;
    }

    public void setHax(String hax) {
        this.hax = hax;
    }

    public String getHax() {
        return this.hax;
    }

    public void setGxgj(String gxgj) {
        this.gxgj = gxgj;
    }

    public String getGxgj() {
        return this.gxgj;
    }

    public void setSd(String sd) {
        this.sd = sd;
    }

    public String getSd() {
        return this.sd;
    }
}
