package com.cetc54.zkb.ky.service.model;

public class EventQueryModel {
    private String country;
    private String wxdj;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getWxdj() {
        return wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }
}
