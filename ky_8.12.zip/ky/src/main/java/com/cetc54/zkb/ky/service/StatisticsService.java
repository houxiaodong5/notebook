package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.EventQueryByIDAndTime;
import com.cetc54.zkb.ky.controller.input.event.ExtraMessageQueryInput;
import com.cetc54.zkb.ky.controller.input.ship.QueryShipAndEventsParam;
import com.cetc54.zkb.ky.controller.output.event.EventAllMessageOutput;
import com.cetc54.zkb.ky.controller.output.event.EventAllMsgs;
import com.cetc54.zkb.ky.controller.output.event.HotWord;
import com.cetc54.zkb.ky.controller.output.ship.StatisticsOfShipState;
import com.cetc54.zkb.ky.controller.output.statistics.*;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 统计相关service
 */
public interface StatisticsService {
    //人员查询统计
    List<OutputOfStatistics> queryHottestPerson();

    //舰船查询统计
    List<OutputOfStatistics> queryHottestShip();

    //基地查询统计
    List<OutputOfStatistics> queryHottestBase();

    //热词统计
    List<HotWord> queryHottestWords();

    //统计昨日事件总数
    Integer statisticsYesterdayEvent();

    //西太区域：基地事件按照类型进行统计
    List<StatisticsOfBaseEventByType> statisticsEventOfBaseByType();

    //西太区域：所有基地按时间统计演习事件
    List<StatisticsManoeuvreOutput> statisticsManoeuvreOfBaseByTime();

    //西太地区：演习事件地点发生事件统计
    StatisticsLocationOfManoeuvreOutput statisticsLocationOfManoeuvre();

    //西太地区：按时间统计舰船事件
    List<StatisticsEventOutput> statisticsEventOfShipByTime();

    //西太地区：按时间统计人物事件
    List<StatisticsEventOutput> statisticsEventOfPersonByTime();

    //西太地区：按时间统计基地事件
    List<StatisticsEventOutput> statisticsEventOfBaseByTime();
    //西太地区：按时间及基地id查询基地事件详情
    List<EventAllMsgs> queryEventsByTimeAndBaseID( EventQueryByIDAndTime input);

    //根据数据源统计事件
    List<StatisticsOfOutputSource> statisticsEventByDatasource();

    //统计西太地区舰船进出港数量
    List<StatisticsOfShipState> statisticsQuantityOfShipByState();

    //西太地区：按事件类型统计一定时间内的事件
    List<StatisticsManoeuvreOutput> statisticsEventGroupByTypeByTime();

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>,携带相关人物、舰船、基地
    List<EventAllMsgs> queryEventsByTypeAndTime(EventQueryByIDAndTime input);

    List<StatisticsStateOfShip> statisticsStateOfShipByTime();

    List<ShipAndEvents> queryShipAndeventsByTime(QueryShipAndEventsParam param);

    //根据事件uuid查询事件对应人物、舰船、基地简要信息
    EventAllMsgs queryExtraMessageBrieflyByUUID( ExtraMessageQueryInput input) throws RuntimeException;

    //西太地区：根据事件类型及基地id查询相关事件
    List<EventAllMsgs> queryEventsByTypeAndBaseID( EventQueryByIDAndTime input)throws RuntimeException;

    //统计用户查看数量最多的新闻
    List<EventAllMsgs> statisticsMostEventsOfViewed();
}
