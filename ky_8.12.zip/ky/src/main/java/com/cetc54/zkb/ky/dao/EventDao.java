package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.input.event.EventQueryByPage;
import com.cetc54.zkb.ky.controller.input.event.EventQueryInput;
import com.cetc54.zkb.ky.controller.input.event.EventTagInput;
import com.cetc54.zkb.ky.controller.output.event.*;
import com.cetc54.zkb.ky.dao.entity.ObjectEventEntity;
import com.cetc54.zkb.ky.dao.sql.EventSql;
import com.cetc54.zkb.ky.service.model.EventQueryModel;
import com.cetc54.zkb.ky.service.model.SliceOfTime;
import com.cetc54.zkb.ky.service.model.StatisticEventModel;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;
import org.springframework.stereotype.Service;

import javax.annotation.security.PermitAll;
import java.util.List;

public interface EventDao {

    /**
     * 查询所有事件
     * */
    @SelectProvider(type = EventSql.class,method = "queryAllEvent")
    List<EventAllMessageOutput> queryAllEvent();


    //分页查询最新事件(前500条,不过滤)
    @SelectProvider(type = EventSql.class,method = "queryAllEventByPage")
    List<EventAllMessageOutput> queryAllEventByPage();
    /**
     * 查询所有事件等级
     * */
    @SelectProvider(type = EventSql.class,method = "queryAllEventGrade")
    List<String> queryAllEventGrade();

    /**
     * 查询所有事件类型
     * */
    @SelectProvider(type = EventSql.class,method = "queryAllEventType")
    List<String> queryAllEventType();

    /**
     * 根据事件类型时间统计
     * */
    @SelectProvider(type = EventSql.class,method = "statisticEventByTimeAndWxdjAndTag")
    Integer statisticEventByTimeAndWxdjAndTag(StatisticEventModel model);

    /**
     * 查询当天事件
     * */
    @SelectProvider(type = EventSql.class,method = "queryEventToday")
    List<ObjectEventOutput> queryEventToday();

    /**
     * 根据不同条件统计事件总数、实时推送、当天事件
     * */
    @SelectProvider(type = EventSql.class,method = "statisticEvent")
    List<EventStatisticOutput> statisticEvent();

    /**
     * 通过事件ID查询事件
     * */
    @SelectProvider(type = EventSql.class,method = "queryEventById")
    List<ObjectEventOutput> queryEventById(String eventId);

    /**
     * 查询威胁等级
     * */
    @SelectProvider(type = EventSql.class,method = "queryEventWxdj")
    List<String> queryEventWxdj();

    /**
     * 查询当前数据库中所有事件年份
     * */
    @SelectProvider(type = EventSql.class,method = "queryEventYear")
    List<String> queryEventYear();

    /**
     * 通过条件查询事件
     * */
    @SelectProvider(type = EventSql.class,method = "queryEvent")
    List<EventListOutput> queryEvent(EventQueryInput input);

    /**
     * 通过国家查询所有威胁等级
     * */
    @SelectProvider(type = EventSql.class,method = "queryWxdjByCountry")
    List<String> queryWxdjByCountry(String country);

    /**
     * 通过条件查询事件类型
     * */
    @SelectProvider(type = EventSql.class,method = "queryTagByCountryAndWxdj")
    List<String> queryTagByCountryAndWxdj(EventQueryModel model);

    @SelectProvider(type = EventSql.class,method = "queryAllWxdj")
    List<String> queryAllWxdj();

    /**
     *      按照事件类型统计
     * */
    @SelectProvider(type = EventSql.class,method = "statisticByEventType")
    List<Long> statisticByEventType(String sql);

    //查询事件标签
    @SelectProvider(type = EventSql.class,method = "queryEventByID")
    ObjectEventEntity queryEventByID(int id);

    //自定义标签
    @SelectProvider(type = EventSql.class,method = "diyTagForEvent")
    void diyTagForEvent(String sql);

    //根据时间查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventByTime1")
    List<ObjectEventOutput> queryEventByTime1(@Param("sql") String sql);
    //根据时间查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventByTime")
    List<ObjectEventOutput> queryEventByTime(EventQueryByPage input);

    //根据标签查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventByTag")
    List<ObjectEventOutput> queryEventByTag(String tag);

    @SelectProvider(type = EventSql.class,method = "queryEventByShipName")
    List<ObjectEventOutput> queryEventByShipName(String tag);

    //查询最新事件
    @SelectProvider(type = EventSql.class,method = "queryLatestEvent")
    List<EventAllMessageOutput> queryLatestEvent(String sql);

    //根据事件类型及事件地点查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventByLocationAndEventType")
    List<ObjectEventOutput> queryEventByLocationAndEventType(@Param("input") EventQueryByPage input,@Param("baseIDs") List<Integer> baseIDs);

    //根据事件id集合查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventsByEventIDs")
    List<ObjectEventOutput> queryEventsByEventIDs(@Param("eventIds") List<String> eventIds);

    //根据舰船id和时间点查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventByShipIDAndTime")
    List<ObjectEventOutput> queryEventByShipIDAndTime(@Param("id") Integer id,@Param("slice") SliceOfTime slice, @Param("baseIDs") List<Integer> baseIDs);

    //根据人物id和时间点查询事件
    @SelectProvider(type = EventSql.class,method = "queryEventByPersonIDAndTime")
    List<ObjectEventOutput> queryEventByPersonIDAndTime(@Param("id") Integer id,@Param("slice") SliceOfTime slice, @Param("baseIDs") List<Integer> baseIDs);

    //根据事件类型查询西太地区事件
    @SelectProvider(type = EventSql.class,method = "queryEventByBaseIdsGroupByType")
    List<EventAllMsgs> queryEventByBaseIdsGroupByType(@Param("baseIDs") List<Integer>baseIDs, @Param("type") String type);

}
