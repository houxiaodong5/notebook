package com.cetc54.zkb.ky.controller.input.ship;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("通过基地统计船舶")
public class StatisticShipByBaseInput {
    @ApiModelProperty("时间类型")
    private String timeType;
    @ApiModelProperty("基地")
    private String base;

    public String getTimeType() {
        return this.timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public String getBase() {
        return this.base;
    }

    public void setBase(String base) {
        this.base = base;
    }
}