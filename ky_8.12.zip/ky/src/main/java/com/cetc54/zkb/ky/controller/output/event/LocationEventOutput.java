package com.cetc54.zkb.ky.controller.output.event;

import java.util.Date;

/**
 * Created by Administrator on 2019/5/25/025.
 *   地点对应事件
 */
public class LocationEventOutput extends  ObjectEventOutput{
   /* private Integer location_id=0;
    private String event_id="";
    private String gxlx="";
    private Date kssj;
    private Date jssj;
    private Integer gdb_used;
    private String location_name;
    //private ObjectEventOutput event;

    public Integer getLocation_id() {
        return location_id;
    }

    public void setLocation_id(Integer location_id) {
        this.location_id = location_id;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getGxlx() {
        return gxlx;
    }

    public void setGxlx(String gxlx) {
        this.gxlx = gxlx;
    }

    public Date getKssj() {
        return kssj;
    }

    public void setKssj(Date kssj) {
        this.kssj = kssj;
    }

    public Date getJssj() {
        return jssj;
    }

    public void setJssj(Date jssj) {
        this.jssj = jssj;
    }

    public Integer getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(Integer gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getLocation_name() {
        return location_name;
    }

    public void setLocation_name(String location_name) {
        this.location_name = location_name;
    }

    public ObjectEventOutput getEvent() {
        return event;
    }

    public void setEvent(ObjectEventOutput event) {
        this.event = event;
    }

    @Override
    public String toString() {
        return "LocationEventOutput{" +
                "location_id=" + location_id +
                ", event_id='" + event_id + '\'' +
                ", gxlx='" + gxlx + '\'' +
                ", kssj=" + kssj +
                ", jssj=" + jssj +
                ", gdb_used=" + gdb_used +
                ", location_name='" + location_name + '\'' +
                ", event=" + event +
                '}';
    }*/
}
