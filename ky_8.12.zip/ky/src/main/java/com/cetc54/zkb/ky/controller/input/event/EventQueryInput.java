package com.cetc54.zkb.ky.controller.input.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("事件查询输入类")
public class EventQueryInput {
    @ApiModelProperty("国家")
    private String country;
    @ApiModelProperty("事件等级")
    private String eventDj;
    @ApiModelProperty("事件类型")
    private String eventTag;
    @ApiModelProperty("开始时间")
    private String startTime;
    @ApiModelProperty("结束时间")
    private String endTime;

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEventDj() {
        return this.eventDj;
    }

    public void setEventDj(String eventDj) {
        this.eventDj = eventDj;
    }

    public String getEventTag() {
        return this.eventTag;
    }

    public void setEventTag(String eventTag) {
        this.eventTag = eventTag;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return this.endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "EventQueryInput{" +
                "country='" + country + '\'' +
                ", eventDj='" + eventDj + '\'' +
                ", eventTag='" + eventTag + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                '}';
    }
}
