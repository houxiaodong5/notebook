package com.cetc54.zkb.ky.controller.output.event;

import java.util.List;

public class EventOutputGroupByType {
    private String type;
    private List<EventAllMsgs> data;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<EventAllMsgs> getData() {
        return data;
    }

    public void setData(List<EventAllMsgs> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "EventOutputGroupByType{" +
                "type='" + type + '\'' +
                ", data=" + data +
                '}';
    }
}
