package com.cetc54.zkb.ky.controller.output.person;

public class OrigConditions {

    private String jx;
    private String zwjx;
    private String zw;
    private String zwzw;//中文职位
    private String rylb;
    private String gj;
    private String zwgjm;

    public String getJx() {
        return jx;
    }

    public void setJx(String jx) {
        this.jx = jx;
    }

    public String getZwjx() {
        return zwjx;
    }

    public void setZwjx(String zwjx) {
        this.zwjx = zwjx;
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    public String getZwzw() {
        return zwzw;
    }

    public void setZwzw(String zwzw) {
        this.zwzw = zwzw;
    }

    public String getRylb() {
        return rylb;
    }

    public void setRylb(String rylb) {
        this.rylb = rylb;
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj;
    }

    public String getZwgjm() {
        return zwgjm;
    }

    public void setZwgjm(String zwgjm) {
        this.zwgjm = zwgjm;
    }

    @Override
    public String toString() {
        return "OrigConditions{" +
                "jx='" + jx + '\'' +
                ", zwjx='" + zwjx + '\'' +
                ", zw='" + zw + '\'' +
                ", zwzw='" + zwzw + '\'' +
                ", rylb='" + rylb + '\'' +
                ", gj='" + gj + '\'' +
                ", zwgjm='" + zwgjm + '\'' +
                '}';
    }
}
