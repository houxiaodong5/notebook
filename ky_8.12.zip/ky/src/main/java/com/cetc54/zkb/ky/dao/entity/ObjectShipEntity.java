package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.util.Arrays;
import java.util.Date;

public class ObjectShipEntity {
    private Integer id;
    private String mc;
    private String ywmc;
    private String ssgj;
    private String lx;
    private byte[] tpBlob;
    private String jb;
    private String bh;
    private String fysj;
    private String ssbd;
    private String tptz;
    private String tp;
    private String jj;
    private String ccrq;
    private String xssj;
    private String rksj;
    private int gdb_used;
    private String jlsj;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return this.id;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getMc() {
        return this.mc;
    }

    public void setLx(String lx) {
        this.lx = lx;
    }

    public String getLx() {
        return this.lx;
    }

    public void setJb(String jb) {
        this.jb = jb;
    }

    public String getJb() {
        return this.jb;
    }

    public void setBh(String bh) {
        this.bh = bh;
    }

    public String getBh() {
        return this.bh;
    }

    public void setFysj(String fysj) {

        this.fysj = TimeUtil.formateStringTime(fysj);
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getSsgj() {
        return ssgj;
    }

    public void setSsgj(String ssgj) {
        this.ssgj = ssgj;
    }

    public byte[] getTpBlob() {
        return tpBlob;
    }

    public void setTpBlob(byte[] tpBlob) {
        this.tpBlob = tpBlob;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }

    public int getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(int gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getFysj() {
        return this.fysj;
    }

    public void setSsbd(String ssbd) {
        this.ssbd = ssbd;
    }

    public String getSsbd() {
        return this.ssbd;
    }

    public void setTptz(String tptz) {
        this.tptz = tptz;
    }

    public String getTptz() {
        return this.tptz;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getTp() {
        return this.tp;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getJj() {
        return this.jj;
    }

    public void setCcrq(String ccrq) {
        this.ccrq = TimeUtil.formatTime(ccrq);
    }

    public String getCcrq() {
        return this.ccrq;
    }

    public void setXssj(String xssj) {
        this.xssj = TimeUtil.formateStringTime(xssj);
    }

    public String getXssj() {
        return this.xssj;
    }

    public String getJlsj() {
        return jlsj;
    }

    public void setJlsj(String jlsj) {
        this.jlsj = TimeUtil.formateStringTime(jlsj);
    }

    @Override
    public String toString() {
        return "ObjectShipEntity{" +
                "id=" + id +
                ", mc='" + mc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", ssgj='" + ssgj + '\'' +
                ", lx='" + lx + '\'' +
                ", tpBlob=" + Arrays.toString(tpBlob) +
                ", jb='" + jb + '\'' +
                ", bh='" + bh + '\'' +
                ", fysj='" + fysj + '\'' +
                ", ssbd='" + ssbd + '\'' +
                ", tptz='" + tptz + '\'' +
                ", tp='" + tp + '\'' +
                ", jj='" + jj + '\'' +
                ", ccrq='" + ccrq + '\'' +
                ", xssj='" + xssj + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdb_used=" + gdb_used +
                ", jlsj='" + jlsj + '\'' +
                '}';
    }
}
