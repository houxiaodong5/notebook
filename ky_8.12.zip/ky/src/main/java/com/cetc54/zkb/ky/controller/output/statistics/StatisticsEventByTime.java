package com.cetc54.zkb.ky.controller.output.statistics;

import java.util.List;

public class StatisticsEventByTime{
    private String timeType;
    private List<Integer> num;
    private List<String> time;

    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public List<Integer> getNum() {
        return num;
    }

    public void setNum(List<Integer> num) {
        this.num = num;
    }

    public List<String> getTime() {
        return time;
    }

    public void setTime(List<String> time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "StatisticsEventByTime{" +
                "timeType='" + timeType + '\'' +
                ", num=" + num +
                ", time=" + time +
                '}';
    }
}