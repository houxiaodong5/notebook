package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
import java.util.List;

/**
 *
 *      西太地区：舰船在、不在港统计
 * */
public class StatisticsStateOfShip implements Serializable {
    private String timeType;
    private String state;//在港、离港
    private List<String> time;
    private List<Integer> num;


    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public List<String> getTime() {
        return time;
    }

    public void setTime(List<String> time) {
        this.time = time;
    }

    public List<Integer> getNum() {
        return num;
    }

    public void setNum(List<Integer> num) {
        this.num = num;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "StatisticsStateOfShip{" +
                "timeType='" + timeType + '\'' +
                ", state='" + state + '\'' +
                ", time=" + time +
                ", num=" + num +
                '}';
    }
}
