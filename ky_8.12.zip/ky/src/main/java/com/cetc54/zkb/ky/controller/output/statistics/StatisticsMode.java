package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
//人名。基地。舰船统计模型
public class StatisticsMode implements Serializable {
    private String name;
    private Long num;
    private Long id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getNum() {
        return num;
    }

    public void setNum(Long num) {
        this.num = num;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "StatisticsMode{" +
                "name='" + name + '\'' +
                ", num=" + num +
                ", id=" + id +
                '}';
    }
}
