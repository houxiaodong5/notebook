package com.cetc54.zkb.ky.constraint;

public abstract class Response {

    //统一约束
    public static String SUCCESS_CODE = "200";

    private String code = SUCCESS_CODE;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
