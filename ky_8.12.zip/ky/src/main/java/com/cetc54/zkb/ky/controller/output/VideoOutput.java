package com.cetc54.zkb.ky.controller.output;

public class VideoOutput {
    private String name="";
    private String url="";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "VideoOutput{" +
                "name='" + name + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
