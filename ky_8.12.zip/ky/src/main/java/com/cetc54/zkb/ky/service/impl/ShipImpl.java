package com.cetc54.zkb.ky.service.impl;

import com.cetc54.zkb.ky.controller.input.person.QueryPersonOrShipsInput;
import com.cetc54.zkb.ky.controller.input.ship.BaseShipInput;
import com.cetc54.zkb.ky.controller.input.ship.BaseShipMsg;
import com.cetc54.zkb.ky.controller.input.ship.StatisticShipByBaseInput;
import com.cetc54.zkb.ky.controller.output.ship.*;
import com.cetc54.zkb.ky.dao.ShipDao;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;
import com.cetc54.zkb.ky.enums.TimeTypeEnum;
import com.cetc54.zkb.ky.service.ShipService;
import com.cetc54.zkb.ky.service.model.ShipTrajectoryModel;
import com.cetc54.zkb.ky.service.model.StatisticShipModel;
import com.cetc54.zkb.ky.util.StringUtil;
import com.cetc54.zkb.ky.util.TimeUtil;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ShipImpl implements ShipService {
    @Resource
    private ShipDao shipDao;
    private static Logger logger= LoggerFactory.getLogger(ShipImpl.class);

    public List<ShipAndEventTodayStatisticOutput> shipAndEventStatistic(String time) {
        //在港1，进港3，离港4
        //根据时间查询所有在港舰船
        StatisticShipModel model = new StatisticShipModel();
        model.setTime(time);
        model.setZgzt(1);
        List<ShipBaseNumOutput> zgs = this.shipDao.shipQueryByTimeAndZgzt(model);
        //Map<港口ID，舰船数量>
        Map<Integer, Integer> zgMap = new HashMap();
        for (ShipBaseNumOutput zg : zgs){
            zgMap.put(zg.getGkid(), zg.getNumber());
        }

        //根据时间查询所有在港舰船
        model.setZgzt(3);
        List<ShipBaseNumOutput> jgs = this.shipDao.shipQueryByTimeAndZgzt(model);
        //Map<港口ID，舰船数量>
        Map<Integer, Integer> jgMap = new HashMap();
        for (ShipBaseNumOutput jg : jgs){
            jgMap.put(jg.getGkid(), jg.getNumber());
        }

        //根据时间查询所有在港舰船
        model.setZgzt(4);
        List<ShipBaseNumOutput> lgs = this.shipDao.shipQueryByTimeAndZgzt(model);
        //Map<港口ID，舰船数量>
        Map<Integer, Integer> lgMap = new HashMap();
        for (ShipBaseNumOutput lg : lgs){
            lgMap.put(lg.getGkid(), lg.getNumber());
        }

        //放入各个基地在港、进港、离港数量
        List<ShipAndEventTodayStatisticOutput> bases = this.shipDao.baseAllQuery();
        for (ShipAndEventTodayStatisticOutput base : bases){
            base.setZgNum(zgMap.get(base.getJdid()));
            base.setJgNum(jgMap.get(base.getJdid()));
            base.setLgNum(lgMap.get(base.getJdid()));
        }

        return bases;
    }

    public ShipTodayStatisticOutput shipTodayStatistic() {
        return this.shipDao.shipTodayStatistic();
    }

    public List<ShipTimeStatisticOutput> statisticShipByBase(StatisticShipByBaseInput input) {
        List<String> years = new ArrayList();
        //若当前选择时间类型为年，则查询所有当前数据库中所有年份
        if (TimeTypeEnum.Year.name().equals(input.getTimeType())) {
            years = this.shipDao.queryShiptYear();
        }

        //增加港口状态list
        List<Integer> zgztList = new ArrayList();
        zgztList.add(1);
        zgztList.add(3);
        zgztList.add(4);
        List<ShipTimeStatisticOutput> output = new ArrayList();
        SimpleDateFormat dateFormat;
        //按周统计
        if (TimeTypeEnum.Week.name().equals(input.getTimeType())) {
            //定义格式化年-月-日
            dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            //定义格式化星期
            SimpleDateFormat dateFormatWeek = new SimpleDateFormat("E");
            //获取当前周一到周五
            for (Date date : TimeUtil.getWeekDay() ){
                ShipTimeStatisticOutput statisticOutput = new ShipTimeStatisticOutput();
                //比较是否大于当前日期
                if (date.compareTo(new Date()) > 0) {
                    break;
                }

                //循环在港状态，分别查询在港、进港、离港数量
                for (Integer zgzt : zgztList){
                    StatisticShipModel statisticShipModel = new StatisticShipModel();
                    statisticShipModel.setZgzt(zgzt);
                    statisticShipModel.setFormat("%Y-%m-%d");
                    statisticShipModel.setTime(dateFormat.format(date));
                    Integer number = this.shipDao.statisticShipByTimeAndZgqk(statisticShipModel);
                    if (1 == zgzt) {
                        statisticOutput.setZgNumber(number);
                    } else if (3 == zgzt) {
                        statisticOutput.setJgNumber(number);
                    } else if (4 == zgzt) {
                        statisticOutput.setLgNumber(number);
                    }
                }
                output.add(statisticOutput);
            }
        } else if (TimeTypeEnum.Month.name().equals(input.getTimeType())) {
            dateFormat = new SimpleDateFormat("yyyy-MM");

            for(Date date : TimeUtil.getMonthDay()) {
                //比较是否大于当前日期
                ShipTimeStatisticOutput statisticOutput = new ShipTimeStatisticOutput();
                if (date.compareTo(new Date()) > 0) {
                    break;
                }

                //循环在港状态，分别查询在港、进港、离港数量
                for (Integer zgzt : zgztList){
                    StatisticShipModel statisticShipModel = new StatisticShipModel();
                    statisticShipModel.setZgzt(zgzt);
                    statisticShipModel.setFormat("%Y-%m");
                    statisticShipModel.setTime(dateFormat.format(date));
                    Integer number = this.shipDao.statisticShipByTimeAndZgqk(statisticShipModel);
                    if (1 == zgzt) {
                        statisticOutput.setZgNumber(number);
                    } else if (3 == zgzt) {
                        statisticOutput.setJgNumber(number);
                    } else if (4 == zgzt) {
                        statisticOutput.setLgNumber(number);
                    }
                }
                output.add(statisticOutput);
            }
        } else if (TimeTypeEnum.Year.name().equals(input.getTimeType())) {
            for (String year :years ){
                ShipTimeStatisticOutput statisticOutput = new ShipTimeStatisticOutput();

                //循环在港状态，分别查询在港、进港、离港数量
                for (Integer zgzt : zgztList){
                    StatisticShipModel statisticShipModel = new StatisticShipModel();
                    statisticShipModel.setZgzt(zgzt);
                    statisticShipModel.setFormat("%Y");
                    statisticShipModel.setTime(year);
                    Integer number = this.shipDao.statisticShipByTimeAndZgqk(statisticShipModel);
                    if (1 == zgzt) {
                        statisticOutput.setZgNumber(number);
                    } else if (3 == zgzt) {
                        statisticOutput.setJgNumber(number);
                    } else if (4 == zgzt) {
                        statisticOutput.setLgNumber(number);
                    }
                }
                output.add(statisticOutput);
            }
        }

        return output;
    }

    public List<ShipTrajectoryOutput> queryShipTrajectory(String time) {
        //通过时间查询所有舰船ID
        List<ObjectShipBasicInfoEntity> jcIds = this.shipDao.queryShipByTime(time);
        List<ShipTrajectoryOutput> trajectorys = new ArrayList();
        for (ObjectShipBasicInfoEntity ship : jcIds){
            ShipTrajectoryModel model = new ShipTrajectoryModel();
            model.setJcid(ship.getId());
            model.setTime(time);
            //通过时间及舰船ID查询舰船轨迹
            List<Trajectory> output = this.shipDao.queryShipTrajectoryByTime(model);
            ShipTrajectoryOutput shipTrajectoryOutput = new ShipTrajectoryOutput();
            shipTrajectoryOutput.setJcid(ship.getId());
            shipTrajectoryOutput.setTrajectory(output);
            shipTrajectoryOutput.setJcName(ship.getMc());
            //将轨迹及舰船ID放入list
            trajectorys.add(shipTrajectoryOutput);
        }

        return trajectorys;
    }

    public List<ObjectShipBasicInfoEntity> queryShipByBase(BaseShipInput input) {
        return this.shipDao.queryShipByBase(input);
    }

    @Override
    public ObjectShipBasicInfoEntity queryShipByID(BaseShipMsg baseShipMsg) {
        //查询舰船详细信息

        return this.shipDao.queryShipByID(baseShipMsg.getShipID());
    }

    @Override
    public List<ShipAllEvents> queryAllShipEvents() {

        List<ShipAllEvents> shipAllEvents = new ArrayList<>();
        //查询所有拥有事件的舰船ID
        List<ShipAllEvents> baseMsg = shipDao.queryShipsWhereHaveEvents();
        //查询所偶遇舰船事件
        //List<ShipEvent> list = shipDao.queryAllEventsOfShips();queryAllEventsOfShips_NEW
        List<ShipEvent> list = shipDao.queryAllEventsOfShips_NEW();
        for(ShipAllEvents shipEvents:baseMsg){
            List<ShipEvent> shipEventList=new ArrayList<>();
            for(int i=0;i<list.size();i++){

                ShipEvent shipEvent = list.get(i);
                if(shipEvent.getShipID()!=shipEvents.getShipID()){
                    break;
                }
                if(shipEvent.getShipID()==shipEvents.getShipID()){
                    List<String> tags = new ArrayList<>();
                    String tag1 = shipEvent.getTag1();
                    if(tag1.contains(";")){
                        StringTokenizer tokenizer = new StringTokenizer(tag1, ";");
                        while (tokenizer.hasMoreTokens()){
                            String str = tokenizer.nextToken();
                            tags.add(str);
                        }
                    }
                    if(tag1.contains("；")){
                        StringTokenizer tokenizer1 = new StringTokenizer(tag1, "；");
                        while (tokenizer1.hasMoreTokens()){
                            String str = tokenizer1.nextToken();
                            tags.add(str);
                        }
                    }


                    shipEvent.setTags(tags);
                    shipEventList.add(shipEvent);
                    list.remove(shipEvent);
                    i--;
                }

            }

            shipEvents.setShipEvents(shipEventList);
            shipAllEvents.add(shipEvents);

        }
        return shipAllEvents;
    }

    @Override
    public List<ShipEvent> queryAllShipEvents_NEW() {
        List<ShipEvent> list = shipDao.queryAllEventsOfShips_NEW();
       /* for(ShipEvent shipEvent:list){
            String tag1 = shipEvent.getTag1();
            shipEvent.setTags(StringUtil.splitStr(tag1));
        }*/
        return list;
    }

    @Override
    public List<ObjectShipBasicInfoEntity> queryShipsByIDs(QueryPersonOrShipsInput input) {
        List<Integer> ids = input.getIds();
        if(ids.size()==0){
            return new ArrayList<>();
        }

        try {
            String sql="SELECT  id,mc,ywmc,lx,lb,bh,ssgj,tp_blob tpBlob,tp FROM `object_ship_basic_info` where id in(  ";
            StringBuffer buffer = new StringBuffer();
            for (Integer id:ids) {
                buffer.append(id+",");
            }
            String substring = buffer.substring(0, buffer.lastIndexOf(","));
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(sql);
            stringBuffer.append(substring);
            stringBuffer.append(")");
            List<ObjectShipBasicInfoEntity> list = shipDao.queryShipsByIDs(stringBuffer.toString());
            return list;
        } catch (Exception e) {
            logger.error("操作失败");
            return null;
        }
    }

    @Override
    public ObjectShipBasicInfoEntity queryShipByIDForOther(BaseShipMsg baseShipMsg) {
        if(baseShipMsg.getShipID()==0){
            return null;
        }
        return shipDao.queryShipByIDForOther(baseShipMsg.getShipID());
    }
}