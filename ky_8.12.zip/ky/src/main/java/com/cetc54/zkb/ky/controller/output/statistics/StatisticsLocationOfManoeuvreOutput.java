package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
import java.util.List;

/**
 *      西太地区：演习地点及对应演习数量统计
 * */
public class StatisticsLocationOfManoeuvreOutput implements Serializable {

    private List<Long> num;
    private List<String> name;

    public List<Long> getNum() {
        return num;
    }

    public void setNum(List<Long> num) {
        this.num = num;
    }

    public List<String> getName() {
        return name;
    }

    public void setName(List<String> name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "StatisticsLocationOfManoeuvreOutput{" +
                "num=" + num +
                ", name=" + name +
                '}';
    }
}
