package com.cetc54.zkb.ky.controller.output.base;
/**
 *      基地包含的联队基础信息
 * */
public class SimpleUnitMsg {
    private Integer id=0;
    private String zwm="";
    private String ywm="";

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getZwm() {
        return zwm;
    }

    public void setZwm(String zwm) {
        this.zwm = zwm;
    }

    public String getYwm() {
        return ywm;
    }

    public void setYwm(String ywm) {
        this.ywm = ywm;
    }

    @Override
    public String toString() {
        return "SimpleUnitMsg{" +
                "id=" + id +
                ", zwm='" + zwm + '\'' +
                ", ywm='" + ywm + '\'' +
                '}';
    }
}
