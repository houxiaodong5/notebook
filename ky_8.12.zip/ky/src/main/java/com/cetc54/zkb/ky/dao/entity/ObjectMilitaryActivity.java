package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;

/**
 *      人物作战经历信息
 * */
public class ObjectMilitaryActivity implements Serializable {
    private int id;
    private String zwmc;
    private String ywmc;
    private String jj;
    private String fssj;
    private String jssj;
    private String wk;
    private String jlsj;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getZwmc() {
        return zwmc;
    }

    public void setZwmc(String zwmc) {
        this.zwmc = zwmc;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getFssj() {
        return fssj;
    }

    public void setFssj(String fssj) {
        this.fssj = TimeUtil.formateStringTime(fssj);
    }

    public String getJssj() {
        return jssj;
    }

    public void setJssj(String jssj) {
        this.jssj = TimeUtil.formateStringTime(jssj);
    }

    public String getWk() {
        return wk;
    }

    public void setWk(String wk) {
        this.wk = wk;
    }

    public String getJlsj() {
        return jlsj;
    }

    public void setJlsj(String jlsj) {
        this.jlsj = TimeUtil.formateStringTime(jlsj);
    }

    @Override
    public String toString() {
        return "ObjectMilitaryActivity{" +
                "id=" + id +
                ", zwmc='" + zwmc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", jj='" + jj + '\'' +
                ", fssj='" + fssj + '\'' +
                ", jssj='" + jssj + '\'' +
                ", wk='" + wk + '\'' +
                ", jlsj='" + jlsj + '\'' +
                '}';
    }
}
