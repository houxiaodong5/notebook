package com.cetc54.zkb.ky.service.impl;

import com.cetc54.zkb.ky.controller.input.event.*;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.event.*;
import com.cetc54.zkb.ky.dao.EventDao;
import com.cetc54.zkb.ky.dao.entity.ObjectEventEntity;
import com.cetc54.zkb.ky.enums.BaseEnum;
import com.cetc54.zkb.ky.enums.TimeTypeEnum;
import com.cetc54.zkb.ky.service.EventService;
import com.cetc54.zkb.ky.service.model.EventQueryModel;
import com.cetc54.zkb.ky.service.model.SliceOfTime;
import com.cetc54.zkb.ky.service.model.StatisticEventModel;
import com.cetc54.zkb.ky.util.StringUtil;
import com.cetc54.zkb.ky.util.TimeUtil;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.models.auth.In;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class EventImpl implements EventService {
    private String time;
    private String time1;
    @Resource
    private EventDao eventDao;
    @Resource
    @Qualifier("secondaryJdbcTemplate")
    private JdbcTemplate secJdbctemplate;

    @Resource
    @Qualifier("primaryJdbcTemplate")
    private JdbcTemplate primaryJdbcTemplate;

    public EventImpl() {
    }

    public List<EventAllMessageOutput> queryAllEvent() {

        return this.eventDao.queryAllEvent();
    }

    public List<String> queryAllEventGrade() {
        List<String> list = this.eventDao.queryAllEventGrade();
        if (list.size() > 0) {
            if (list.contains("")) {
                list.remove("");
                list.add(0, "0");
            }
        }

        return list;
    }

    public List<String> queryAllEventType() {
        HashSet<String> set = new HashSet<>();
        List<String> list = this.eventDao.queryAllEventType();
        Boolean flag = false;
        for (String str : list) {
            if (str == null) {
                flag=true;
            } else if (str.equals("")) {
                flag=true;
            }
            set.addAll(StringUtil.splitStr(str));
        }

        list.clear();
        list.addAll(set);
        Collections.sort(list);
        if(flag){
            list.add("其他");
        }
       /*
        Boolean flag = false;
        for (int i = 0; i < list.size(); i++) {
            if ((list.get(i)) == null) {
                list.remove(list.get(i));
                i--;
                continue;
            } else if ("".equals(list.get(i))) {
                flag = true;
                list.remove(list.get(i));
                i--;
                continue;
            }
        }
        if (flag) {
            list.add("其他");
        }*/

        return list;
    }

    public List<EventTimeStatisticListOutput> statisticEventByTimeType(StatisticEventByTimeInput input) {
        List<String> years = new ArrayList();
        //查询数据库中所有年份
        if (TimeTypeEnum.Year.name().equals(input.getTimeType())) {
            years = this.eventDao.queryEventYear();
        }

        List<EventTimeStatisticListOutput> timeStatisticListOutputs = new ArrayList();
        //查询所有威胁等级
        List<String> wxdjs = this.eventDao.queryEventWxdj();

        //根据威胁等级 分别按 周、月、年统计
        for (String wxdj : wxdjs) {
            List<EventTimeStatisticOutput> outputs = new ArrayList();
            SimpleDateFormat dateFormat;
            if (TimeTypeEnum.Week.name().equals(input.getTimeType())) {
                dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat dateFormatWeek = new SimpleDateFormat("E");
                for (Date date : TimeUtil.getWeekDay()) {
                    EventTimeStatisticOutput eventOutput = new EventTimeStatisticOutput();
                    if (date.compareTo(new Date()) > 0) {
                        break;
                    }
                    StatisticEventModel model = new StatisticEventModel();
                    model.setTag(input.getEventType());
                    model.setTime(dateFormat.format(date));
                    model.setWxdj(wxdj);
                    model.setFormat("%Y-%m-%d");
                    Integer eventNum = this.eventDao.statisticEventByTimeAndWxdjAndTag(model);
                    eventOutput.setNumber(eventNum);
                    eventOutput.setTime(dateFormatWeek.format(date));
                    outputs.add(eventOutput);
                }
            } else if (TimeTypeEnum.Month.name().equals(input.getTimeType())) {
                dateFormat = new SimpleDateFormat("yyyy-MM");
                for (Date date : TimeUtil.getMonthDay()) {

                    EventTimeStatisticOutput eventOutput = new EventTimeStatisticOutput();
                    if (date.compareTo(new Date()) > 0) {
                        break;
                    }
                    StatisticEventModel model = new StatisticEventModel();
                    model.setTag(input.getEventType());
                    model.setTime(dateFormat.format(date));
                    model.setWxdj(wxdj);
                    model.setFormat("%Y-%m");
                    Integer eventNum = this.eventDao.statisticEventByTimeAndWxdjAndTag(model);
                    eventOutput.setNumber(eventNum);
                    eventOutput.setTime(dateFormat.format(date));
                    outputs.add(eventOutput);
                }
            } else if (TimeTypeEnum.Year.name().equals(input.getTimeType())) {
                for (String year : years) {

                    EventTimeStatisticOutput eventOutput = new EventTimeStatisticOutput();
                    StatisticEventModel model = new StatisticEventModel();
                    model.setTag(input.getEventType());
                    model.setTime(year);
                    model.setWxdj(wxdj);
                    model.setFormat("%Y");
                    Integer eventNum = this.eventDao.statisticEventByTimeAndWxdjAndTag(model);
                    eventOutput.setNumber(eventNum);
                    eventOutput.setTime(year);
                    outputs.add(eventOutput);
                }
            }

            EventTimeStatisticListOutput output = new EventTimeStatisticListOutput();
            output.setWxdj(wxdj);
            output.setDatas(outputs);
            timeStatisticListOutputs.add(output);
        }

        return timeStatisticListOutputs;
    }

    public List<EventStatisticOutput> statisticEvent() {
        return this.eventDao.statisticEvent();
    }

    public List<ObjectEventOutput> queryEventToday() {
        return this.eventDao.queryEventToday();
    }

    public List<ObjectEventOutput> queryEventById(String eventId) {
        List<ObjectEventOutput> list = eventDao.queryEventById(eventId);
        for(ObjectEventOutput event:list){
            String tag1 = event.getTag1();
            List<String> tags = event.getTags();
            if(tag1.contains(";")){
                StringTokenizer stringTokenizer = new StringTokenizer(tag1, ";");
                while (stringTokenizer.hasMoreTokens()){
                    tags.add(stringTokenizer.nextToken());
                }
            }

            if(tag1.contains("；")){
                StringTokenizer stringTokenizer = new StringTokenizer(tag1, "；");
                while (stringTokenizer.hasMoreTokens()){
                    tags.add(stringTokenizer.nextToken());
                }
            }
            String sql="SELECT `vc_origin` xwlyCn,`vc_domain` xwly FROM `tb_news_new` where `vc_uuid` ='"+event.getUuid()+"'";
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
            if(maps.size()>0){
                Map<String, Object> map = maps.get(0);
                event.setXwlyCn((String) map.get("xwlyCn"));
                event.setXwly((String)map.get("xwly"));
            }


        }
        return list;
    }

    /**
     * 通过条件查询事件
     */
    public List<EventQueryOutput2> queryEvent(EventQueryInput input) {
        EventQueryOutput output = new EventQueryOutput();
        List<EventQueryOutput2> list = new ArrayList<>();
        output.setLabel(input.getCountry());

        //根据国家查询出所有的威胁等级
        List<String> wxdjs = new ArrayList<>();
        if (StringUtils.isBlank(input.getEventDj())) {
            wxdjs.addAll(eventDao.queryWxdjByCountry(input.getCountry()));
        } else {
            wxdjs.add(input.getEventDj());
        }

        //放入时间查询条件
        if (StringUtils.isNotBlank(input.getStartTime())) {
            input.setStartTime(input.getStartTime() + " 00:00:00");
        }

        if (StringUtils.isNotBlank(input.getEndTime())) {
            input.setEndTime(input.getEndTime() + " 23:59:59");
        }

        List<EventQueryOutput.Wxdj> wxdjList = new ArrayList<>();
        //循环威胁等级
        for (String wxdj : wxdjs) {
            EventQueryOutput.Wxdj wxdj1 = output.new Wxdj();
            //根据事件等级及国家查询事件类型
            List<String> tags = new ArrayList<>();
            if (StringUtils.isBlank(input.getEventTag())) {
                EventQueryModel model = new EventQueryModel();
                model.setCountry(input.getCountry());
                model.setWxdj(input.getEventDj());
                tags.addAll(eventDao.queryTagByCountryAndWxdj(model));
            } else {
                tags.add(input.getEventTag());
            }

            //放入事件类型
            List<EventQueryOutput.Wxdj.EventTag> eventTags = new ArrayList<>();
            for (String tag : tags) {
                EventQueryOutput.Wxdj.EventTag tag1 = wxdj1.new EventTag();
                input.setEventTag(tag);
                input.setEventDj(wxdj);
                List<EventListOutput> eventListOutputs = this.eventDao.queryEvent(input);
                for (EventListOutput listOutput : eventListOutputs) {
                    EventQueryOutput2 output2 = new EventQueryOutput2();
                    output2.setCountry(input.getCountry());
                    output2.setLabel(listOutput.getLabel());//bt
                    output2.setId(listOutput.getId());
                    output2.setType(input.getEventDj());//事件类型
                    output2.setUuid(listOutput.getUuid());
                    output2.setWxdj(wxdj);//威胁等级
                    output2.setZbjd(listOutput.getZbjd());
                    output2.setZbwd(listOutput.getZbwd());
                    list.add(output2);
                }
               /* tag1.setLabel(tag);
                tag1.setChildren(eventListOutputs);
                eventTags.add(tag1);*/
            }

            //放入威胁等级
         /*   wxdj1.setLabel(wxdj);
            wxdj1.setChildren(eventTags);
            wxdjList.add(wxdj1);*/
        }

        //output.setChildren(wxdjList);

        return list;
    }
    /*public EventQueryOutput queryEvent(EventQueryInput input) {
        EventQueryOutput output = new EventQueryOutput();
        output.setLabel(input.getCountry());

        //根据国家查询出所有的威胁等级
        List<String> wxdjs = new ArrayList<>();
        if (StringUtils.isBlank(input.getEventDj())){
            wxdjs.addAll(eventDao.queryWxdjByCountry(input.getCountry()));
        }else {
            wxdjs.add(input.getEventDj());
        }

        //放入时间查询条件
        if (StringUtils.isNotBlank(input.getStartTime())) {
            input.setStartTime(input.getStartTime() + " 00:00:00");
        }

        if (StringUtils.isNotBlank(input.getEndTime())) {
            input.setEndTime(input.getEndTime() + " 23:59:59");
        }

        List<EventQueryOutput.Wxdj> wxdjList = new ArrayList<>();
        //循环威胁等级
        for (String wxdj : wxdjs){
            EventQueryOutput.Wxdj wxdj1 = output.new Wxdj();
            //根据事件等级及国家查询事件类型
            List<String> tags = new ArrayList<>();
            if (StringUtils.isBlank(input.getEventTag())){
                EventQueryModel model = new EventQueryModel();
                model.setCountry(input.getCountry());
                model.setWxdj(input.getEventDj());
                tags.addAll(eventDao.queryTagByCountryAndWxdj(model));
            }else {
                tags.add(input.getEventTag());
            }

            //放入事件类型
            List<EventQueryOutput.Wxdj.EventTag> eventTags = new ArrayList<>();
            for (String tag : tags ){
                EventQueryOutput.Wxdj.EventTag tag1 = wxdj1.new EventTag();
                input.setEventTag(tag);
                input.setEventDj(wxdj);
                List<EventListOutput> eventListOutputs = this.eventDao.queryEvent(input);
                tag1.setLabel(tag);
                tag1.setChildren(eventListOutputs);
                eventTags.add(tag1);
            }

            //放入威胁等级
            wxdj1.setLabel(wxdj);
            wxdj1.setChildren(eventTags);
            wxdjList.add(wxdj1);
        }

        output.setChildren(wxdjList);

        return output;
    }*/

    @Override
    public List<String> queryAllWxdj() {
        List<String> list = eventDao.queryAllWxdj();
        return list;
    }

    //通过事件类型统计
    @Override
    public EventStatisticByTypeOutput statisticByEventType() {
        EventStatisticByTypeOutput output = new EventStatisticByTypeOutput();
        //查询所有事件类型
        List<String> types = queryAllEventType();
        types.remove("其他");
        StringBuffer buffer = new StringBuffer();
        for (String str : types) {
            buffer.append(" SELECT count(*)  FROM object_event where `tag1` like '%" +str+"%' UNION ");
        }

        buffer.append("SELECT count(*)  FROM object_event where `tag1` ='' or tag1 is null ");

        String sql = buffer.toString();
        List<Long> list = eventDao.statisticByEventType(sql);
        types.add("其他");
        output.setType(types);
        output.setCount(list);
        return output;
    }

    //自定义标签
    @Override
    public String diyTagForEvent(EventTagInput input) {
        try {
            int id = input.getId();
            List<String> tags = input.getTags();
            //查询当前事件标签情况
            ObjectEventEntity event = eventDao.queryEventByID(id);
            String sql = "";
            String tag1 = event.getTag1();
            String tag2 = event.getTag2();
            String tag3 = event.getTag3();

            if (tags.size() == 3) {
                sql = "UPDATE object_event SET tag1='" + tags.get(0) + "',tag2='" + tags.get(1) + "',tag3='" + tags.get(2) + "' where id=" + id;
            } else if (tags.size() == 2) {
                if (StringUtils.isEmpty(tag1) && StringUtils.isEmpty(tag2)) {
                    sql = "UPDATE object_event SET tag1='" + tags.get(0) + "',tag2='" + tags.get(1) + "' where id=" + id;
                } else if (StringUtils.isEmpty(tag1) && StringUtils.isEmpty(tag3)) {
                    sql = "UPDATE object_event SET tag1='" + tags.get(0) + "',tag3='" + tags.get(1) + "' where id=" + id;
                } else if (StringUtils.isEmpty(tag2) && StringUtils.isEmpty(tag3)) {
                    sql = "UPDATE object_event SET tag2='" + tags.get(0) + "',tag3='" + tags.get(1) + "' where id=" + id;
                }

            } else if (tags.size() == 1) {
                if (StringUtils.isEmpty(tag1)) {
                    sql = "UPDATE object_event SET tag1='" + tags.get(0) + "' where id=" + id;
                } else if (StringUtils.isEmpty(tag2)) {
                    sql = "UPDATE object_event SET tag2='" + tags.get(0) + "' where id=" + id;
                } else if (StringUtils.isEmpty(tag3)) {
                    sql = "UPDATE object_event SET tag3='" + tags.get(0) + "' where id=" + id;
                }
            }
            eventDao.diyTagForEvent(sql);
            return "标签保存成功";

        } catch (Exception e) {
            e.printStackTrace();
            return "操作失败";
        }

    }


    @Override
    public List<ObjectEventOutput> queryEventByTime1(EventQueryInput input) {
        String sql = "select distinct id,uuid,bt,fssj,jssj,zbjd,zbwd,tag1,gjmc,gjid,dd,wxdj,rksj from object_event where fssj between '" + input.getStartTime() + "' and '" + input.getEndTime() + "' order by fssj desc";
        List<ObjectEventOutput> list = eventDao.queryEventByTime1(sql);

        return list;
    }

    @Override
    public PageInfo<ObjectEventOutput> queryEventByTime(EventQueryByPage input) {
        PageHelper.startPage(input.getPageNum(), input.getPageSize());
        List<ObjectEventOutput> list = eventDao.queryEventByTime(input);
     /*   public PageInfo<ObjectEventOutput> queryDataBySource(QueryDataPage queryDataPage) {
            //根据source查询对应数据uuid

        */
        PageInfo<ObjectEventOutput> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public List<ObjectEventOutput> queryEventByTag(String tag) {
        //PageHelper.startPage(input.getPageNum(),input.getPageSize());
        List<ObjectEventOutput> list = eventDao.queryEventByTag(tag);
        if (list.size() == 0) {
            list = eventDao.queryEventByShipName(tag);
        }
        //PageInfo<ObjectEventOutput> pageInfo = new PageInfo<>(list);
        return list;
    }

    //查询最新事件
    @Override
    public List<EventAllMessageOutput> queryLatestEvent() {
        StringBuffer buffer = new StringBuffer();
        if (time == null) {
            buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj,t2.person_name personName ,t2.person_id personID,t3.ship_id shipID ,t3.ship_name shipName ,t4.base_id baseID ,t4.base_name  baseName FROM `object_event` t1 ");
            buffer.append("left join  `relation_person_event` t2 on t1. uuid=t2.`event_id`  ");
            buffer.append("LEFT JOIN `relation_ship_event` t3 on t1.`uuid` =t3.`event_id` ");
            buffer.append("LEFT JOIN `relation_base_event` t4 on t1.`uuid` =t4.`event_id`");
            buffer.append("where t1.`uuid` in (  select uuid from ");
            buffer.append("( SELECT  uuid FROM object_event where zbjd is not null and `zbjd` !='' order by fssj desc  limit 5 ) a)");
            buffer.append("  order by t1.fssj desc  limit 5 ");

        } else {

            buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj,t2.person_name personName ,t2.person_id personID,t3.ship_id shipID ,t3.ship_name shipName ,t4.base_id baseID ,t4.base_name  baseName FROM `object_event` t1 ");
            buffer.append("left join  `relation_person_event` t2 on t1. uuid=t2.`event_id`  ");
            buffer.append("LEFT JOIN `relation_ship_event` t3 on t1.`uuid` =t3.`event_id` ");
            buffer.append("LEFT JOIN `relation_base_event` t4 on t1.`uuid` =t4.`event_id`");
            buffer.append("where t1.`uuid` in (  select uuid from ");
            buffer.append("( SELECT  uuid FROM object_event where zbjd is not null and `zbjd` !='' order by fssj desc  limit 5 ) a)");
            buffer.append(" and t1.fssj> '" + time + "' order by t1.fssj   limit 5 ");

        }

        List<EventAllMessageOutput> list = eventDao.queryLatestEvent(buffer.toString());
        if (list.size() > 0) {
            time = list.get(0).getFssj();
        }
        return list;
    }

    //查询最新事件  不过滤经纬度
    @Override
    public List<EventAllMessageOutput> queryLatestEventNOFitlter() {
        StringBuffer buffer = new StringBuffer();
        if (time1 == null) {
            buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj,t2.person_name personName ,t2.person_id personID,t3.ship_id shipID ,t3.ship_name shipName ,t4.base_id baseID ,t4.base_name  baseName FROM `object_event` t1 ");
            buffer.append("left join  `relation_person_event` t2 on t1. uuid=t2.`event_id`  ");
            buffer.append("LEFT JOIN `relation_ship_event` t3 on t1.`uuid` =t3.`event_id` ");
            buffer.append("LEFT JOIN `relation_base_event` t4 on t1.`uuid` =t4.`event_id`");
            buffer.append("where t1.`uuid` in (  select uuid from ");
            buffer.append("( SELECT  uuid FROM object_event  order by fssj desc  limit 5 ) a)");
            buffer.append("  order by t1.fssj desc  limit 5 ");

        } else {

            buffer.append("SELECT  distinct t1.id,t1.uuid,t1.bt,t1.gjc,t1.fssj,t1.jssj,t1.zbjd,t1.zbwd,t1.tag1,t1.gjmc,t1.gjid,t1.dd,t1.wxdj,t1.rksj,t2.person_name personName ,t2.person_id personID,t3.ship_id shipID ,t3.ship_name shipName ,t4.base_id baseID ,t4.base_name  baseName FROM `object_event` t1 ");
            buffer.append("left join  `relation_person_event` t2 on t1. uuid=t2.`event_id`  ");
            buffer.append("LEFT JOIN `relation_ship_event` t3 on t1.`uuid` =t3.`event_id` ");
            buffer.append("LEFT JOIN `relation_base_event` t4 on t1.`uuid` =t4.`event_id`");
            buffer.append("where t1.`uuid` in (  select uuid from ");
            buffer.append("( SELECT  uuid FROM object_event order by fssj desc  limit 5 ) a)");
            buffer.append(" and t1.fssj> '" + time1 + "' order by t1.fssj   limit 5 ");

        }

        List<EventAllMessageOutput> list = eventDao.queryLatestEvent(buffer.toString());
        if (list.size() > 0) {
            time1 = list.get(0).getFssj();
        }
        return list;
    }

    @Override
    public PageInfo<EventAllMessageOutput> queryAllEventByPage(QueryByPage page) {
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<EventAllMessageOutput> list=eventDao.queryAllEventByPage();

        PageInfo<EventAllMessageOutput> pageInfo = new PageInfo<>(list);

        return pageInfo;
    }

    //根据事件地点及事件类型查询事件
    @Override
    public PageInfo<ObjectEventOutput> queryEventByLocationAndEventType(EventQueryByPage input) {
        PageHelper.startPage(input.getPageNum(), input.getPageSize());
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        List<ObjectEventOutput> list=eventDao.queryEventByLocationAndEventType(input,baseIDs);

        PageInfo<ObjectEventOutput> pageInfo = new PageInfo<>(list);

        return pageInfo;
    }

    //根据数据源<中文>查询对应事件
    @Override
    public PageInfo<ObjectEventOutput> queryEventByDatasource(EventQueryByDataSource input) {
        System.out.println(input);
       //接入库中查询事件ID
        if(input.getDatasource()==null){
            return null;
        }
        String sql="select DISTINCT `vc_uuid`  from tb_news_new where vc_origin ='"+input.getDatasource()+"'";
        List<String> eventIDs = secJdbctemplate.queryForList(sql, String.class);
      //开源库中查询具体事件
        PageHelper.startPage(input.getPageNum(), input.getPageSize());
        List<ObjectEventOutput> list = eventDao.queryEventsByEventIDs(eventIDs);
        PageInfo<ObjectEventOutput> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    //根据舰船或人物id和时间点查询事件
    @Override
    public List<ObjectEventOutput> queryEventByIDAndTime(EventQueryByIDAndTime input) {
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        String time = input.getTime();
        String type = input.getType();
        List<ObjectEventOutput> list=null;
        if(time==null||type==null){
            return null;
        }
        //格式化时间
        String flag="";
        if(time.contains("-")){
            flag="DAY";
        }else if(time.contains("时")){
            flag="HOUR";
        }
        SliceOfTime sliceOfTime = TimeUtil.getQueryTime(time);
        if(null==sliceOfTime){
            return null;
        }
        if(type.equals("舰船")){
            list = eventDao.queryEventByShipIDAndTime(input.getId(), sliceOfTime,baseIDs);

        }else if(type.equals("人物")){
            list = eventDao.queryEventByPersonIDAndTime(input.getId(), sliceOfTime,baseIDs);
        }
        return list;
    }

    @Override
    public List<EventOutputGroupByType> queryEventGroupByType() {
        List<EventOutputGroupByType> data=new ArrayList<>();
        List<Integer> baseIDs = BaseEnum.allOfBaseID();
        //查询所有事件类型
        List<String> types = queryAllEventType();
        types.remove("其他");
        HashSet<String> set=new LinkedHashSet<>();
        for(String type:types){
            EventOutputGroupByType output=new EventOutputGroupByType();
            output.setType(type);
            //根据事件类型查询西太地区事件
            List<EventAllMsgs> type_data = eventDao.queryEventByBaseIdsGroupByType(baseIDs, type);
            for(int i=0;i<type_data.size();i++){
                EventAllMsgs event = type_data.get(i);
                String bt = event.getBt();
                if(set.contains(bt)){
                    type_data.remove(i);
                    i--;
                }else {
                    set.add(bt);

                    //职务变动类型额外处理
                    if(type.equals("职务变动")){
                        String sql="SELECT new_leader newLeader,old_leader oldLeader,gjj from `relation_zwbd` where `event_id` ='"+event.getUuid()+"'";
                        //List<String> gjj = primaryJdbcTemplate.queryForList(sql, String.class);
                        List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(sql);
                        for(Map<String, Object> map:maps){
                            String oldLeader = (String) map.get("oldLeader");
                            String newLeader = (String) map.get("newLeader");
                            String gjjStr = (String) map.get("gjj");
                            event.setOldLeader(oldLeader);
                            event.setNewLeader(newLeader);
                            event.setGjj(gjjStr);
                            break;
                        }
                    }
                    //演习类型额外处理
                    if(type.equals("演习")){
                        String sql="SELECT `location_id` locationID,`location_name` locationName from `relation_location_event` where `event_id` ='"+event.getUuid()+"'";
                        //List<String> gjj = primaryJdbcTemplate.queryForList(sql, String.class);
                        List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(sql);
                        for(Map<String, Object> map:maps){
                            Integer locationID = (Integer) map.get("locationID");
                            String locationName = (String) map.get("locationName");
                            event.setLocationID(locationID);
                            event.setLocationName(locationName);
                            break;
                        }
                    }
                }

            }

            output.setData(type_data);
            data.add(output);
        }
        return data;
    }
}
