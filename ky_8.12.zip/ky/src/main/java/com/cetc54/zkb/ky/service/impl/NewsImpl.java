package com.cetc54.zkb.ky.service.impl;

import com.alibaba.fastjson.JSON;
import com.cetc54.zkb.ky.controller.input.event.QueryDataPage;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.NewsOutputByPage;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutputByPage;
import com.cetc54.zkb.ky.controller.output.source.OutputSource;
import com.cetc54.zkb.ky.dao.entity.NewsEntitry;
import com.cetc54.zkb.ky.dao.entity.NewsEntity;
import com.cetc54.zkb.ky.dao.sql.NewsSql;
import com.cetc54.zkb.ky.service.NewsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class NewsImpl implements NewsService {
    private String time = "";
    private static Logger logger = LoggerFactory.getLogger(NewsImpl.class);

    @Resource
    @Qualifier("secondaryJdbcTemplate")
    private JdbcTemplate secJdbctemplate;

    @Resource
    @Qualifier("primaryJdbcTemplate")
    private JdbcTemplate primaryJdbcTemplate;

    private List<ObjectEventOutput> list;
    private List<NewsEntity> imageNewsList;
    private List<NewsEntity> videoNewsList;
    private List<NewsEntity> pdfNewsList;

    @Override
    public NewsEntitry queryLatestNews() {
        try {
            String sql = "SELECT nm_id id,vc_uuid uuid, cast(vc_crawlDate as char) crawlTime,vc_domain source,vc_title title FROM tb_news_new  order by vc_crawlDate DESC limit 1 ";
            String sql2 = "SELECT nm_id id,vc_uuid uuid, cast(vc_crawlDate as char) crawlTime,vc_domain source,vc_title title FROM tb_news_new  where vc_crawlDate > '" + time + "' order by vc_crawlDate  limit 1 ";

            if (!time.equals("")) {
                sql = sql2;
            }
            //List<Map<String, Object>> maps = secJdbctemplate.queryForList(NewsSql.queryLatestNews());
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
            if (maps.size() > 0) {
                Map<String, Object> map = maps.get(0);
                time = (String) map.get("crawlTime");
                String s = JSON.toJSONString(map);
                NewsEntitry newsEntitry = JSON.toJavaObject(JSON.parseObject(s), NewsEntitry.class);
                return newsEntitry;
            }
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        return null;
    }

    @Override
    public List<OutputSource> queryAllSource() {
        List<OutputSource> list = new ArrayList<>();
        try {
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(NewsSql.queryAllSource());
            if (maps.size() > 0) {
                for (Map<String, Object> map:maps) {
                    OutputSource outputSource = new OutputSource();
                    String source = (String) map.get("source");
                    String name = (String) map.get("name");
                    outputSource.setName(name);
                    outputSource.setSoure(source);
                    list.add(outputSource);
                }

            }
        } catch (DataAccessException e) {
           logger.info(e.getMessage());
        }
        return list;
    }

    /**
     *          此接口未进行分页
     *          replaced by <code>NewsImpl.queryDataBySource1(QueryDataPage queryDataPage)</code>
     *          @see this.queryDataBySource1
     * */
    @Override
    public PageInfo<ObjectEventOutput> queryDataBySource(QueryDataPage queryDataPage) {
        //根据source查询对应数据uuid
        PageHelper.startPage(queryDataPage.getPageNum(), queryDataPage.getPageSize());
        List<String> uuids = secJdbctemplate.queryForList(NewsSql.queryAllUUIDBySource(queryDataPage.getSource()), String.class);
        List<ObjectEventOutput> list = new ArrayList<>();
        if (uuids.size() > 0) {
            List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(NewsSql.queryDataBySource(uuids));
            for (Map<String, Object> map : maps) {
                String s = JSON.toJSONString(map);
                ObjectEventOutput objectEventOutput = JSON.toJavaObject(JSON.parseObject(s), ObjectEventOutput.class);
                list.add(objectEventOutput);
            }
        }

        PageInfo<ObjectEventOutput> pageInfo = new PageInfo<>(list);


        return pageInfo;
    }

    /**
     *          完成分页
     * */
    @Override
    public ObjectEventOutputByPage queryDataBySource1(QueryDataPage queryDataPage) {

        ObjectEventOutputByPage outputByPage = new ObjectEventOutputByPage();
        List<ObjectEventOutput> responseList=new ArrayList<>();


        if (list==null) {
            list = new ArrayList<>();
            List<String> uuids = secJdbctemplate.queryForList(NewsSql.queryAllUUIDBySource(queryDataPage.getSource()), String.class);
            List<Map<String, Object>> maps = primaryJdbcTemplate.queryForList(NewsSql.queryDataBySource(uuids));
            for (Map<String, Object> map : maps) {
                String s = JSON.toJSONString(map);
                ObjectEventOutput objectEventOutput = JSON.toJavaObject(JSON.parseObject(s), ObjectEventOutput.class);
                list.add(objectEventOutput);
            }
        }
        int size = list.size();
        int currentPage = queryDataPage.getPageNum();
        int pageSize = queryDataPage.getPageSize();
        int totalPage;
        Boolean flag;
        if (size % pageSize == 0) {
            totalPage = size / pageSize;
            flag = false;
        } else {
            totalPage = size / pageSize + 1;
            flag = true;
        }
        //不能完整分页
        int begin=0;
        int end=0;
        if (flag) {
            if (currentPage < totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = currentPage * pageSize - 1;
            }

            if (currentPage == totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = begin + size % pageSize;
            }

        } else {
            begin = (currentPage - 1) * pageSize;
            end = currentPage * pageSize - 1;
        }

        for (int i=0;i<list.size();i++){
            if(i>=begin&&i<=end){
                responseList.add(list.get(i));
            }
        }
        outputByPage.setData(responseList);
        outputByPage.setCurrentPage(currentPage);
        outputByPage.setTotalPage(totalPage);
        outputByPage.setTotalData(list.size());
        return outputByPage;
    }

    @Override
    public NewsOutputByPage queryImageNewsTimely(QueryByPage page) {
        NewsOutputByPage output = new NewsOutputByPage();
        List<NewsEntity> data = new ArrayList<>();



        if (imageNewsList==null) {
            imageNewsList = new ArrayList<>();
            String sql="SELECT * FROM `tb_news_new` where vc_newsType='Image' and `vc_fileUrl` is not null and `vc_fileUrl` !=''  ORDER BY `vc_crawlDate` desc limit 1000 ";
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
            for(Map<String, Object> map:maps){
                String s = JSON.toJSONString(map);
                NewsEntity newsEntitry = JSON.toJavaObject(JSON.parseObject(s), NewsEntity.class);
                newsEntitry=NewsEntity.stardandNews(newsEntitry);
                imageNewsList.add(newsEntitry);
            }

        }
        int size = imageNewsList.size();
        int currentPage = page.getPageNum();
        int pageSize = page.getPageSize();
        int totalPage;
        Boolean flag;
        if (size % pageSize == 0) {
            totalPage = size / pageSize;
            flag = false;
        } else {
            totalPage = size / pageSize + 1;
            flag = true;
        }
        //不能完整分页
        int begin=0;
        int end=0;
        if (flag) {
            if (currentPage < totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = currentPage * pageSize - 1;
            }

            if (currentPage == totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = begin + size % pageSize;
            }

        } else {
            begin = (currentPage - 1) * pageSize;
            end = currentPage * pageSize - 1;
        }

        for (int i=0;i<imageNewsList.size();i++){
            if(i>=begin&&i<=end){
                data.add(imageNewsList.get(i));
            }
        }
        output.setData(data);
        output.setCurrentPage(currentPage);
        output.setTotalPage(totalPage);
        output.setTotalData(imageNewsList.size());
        return output;

    }

    @Override
    public NewsOutputByPage queryVideoNewsTimely(QueryByPage page) {
        NewsOutputByPage output = new NewsOutputByPage();
        List<NewsEntity> data = new ArrayList<>();



        if (videoNewsList==null) {
            videoNewsList = new ArrayList<>();
            String sql="SELECT * FROM `tb_news_new` where vc_newsType='Video' and `vc_fileUrl` is not null and `vc_fileUrl` !=''  ORDER BY `vc_crawlDate` desc limit 1000 ";
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
            for(Map<String, Object> map:maps){
                String s = JSON.toJSONString(map);
                NewsEntity newsEntitry = JSON.toJavaObject(JSON.parseObject(s), NewsEntity.class);
                newsEntitry=NewsEntity.stardandNews(newsEntitry);
                videoNewsList.add(newsEntitry);
            }

        }
        int size = videoNewsList.size();
        int currentPage = page.getPageNum();
        int pageSize = page.getPageSize();
        int totalPage;
        Boolean flag;
        if (size % pageSize == 0) {
            totalPage = size / pageSize;
            flag = false;
        } else {
            totalPage = size / pageSize + 1;
            flag = true;
        }
        //不能完整分页
        int begin=0;
        int end=0;
        if (flag) {
            if (currentPage < totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = currentPage * pageSize - 1;
            }

            if (currentPage == totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = begin + size % pageSize;
            }

        } else {
            begin = (currentPage - 1) * pageSize;
            end = currentPage * pageSize - 1;
        }

        for (int i=0;i<videoNewsList.size();i++){
            if(i>=begin&&i<=end){
                data.add(videoNewsList.get(i));
            }
        }
        output.setData(data);
        output.setCurrentPage(currentPage);
        output.setTotalPage(totalPage);
        output.setTotalData(videoNewsList.size());
        return output;

    }

    @Override
    public NewsOutputByPage queryPdfNewsTimely(QueryByPage page) {
        NewsOutputByPage output = new NewsOutputByPage();
        List<NewsEntity> data = new ArrayList<>();



        if (pdfNewsList==null) {
            pdfNewsList = new ArrayList<>();
            String sql="SELECT * FROM `tb_news_new` where vc_newsType='Pdf' and `vc_fileUrl` is not null and `vc_fileUrl` !=''  ORDER BY `vc_crawlDate` desc limit 1000 ";
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
            for(Map<String, Object> map:maps){
                String s = JSON.toJSONString(map);
                NewsEntity newsEntitry = JSON.toJavaObject(JSON.parseObject(s), NewsEntity.class);
                newsEntitry=NewsEntity.stardandNews(newsEntitry);
                pdfNewsList.add(newsEntitry);
            }

        }
        int size = pdfNewsList.size();
        int currentPage = page.getPageNum();
        int pageSize = page.getPageSize();
        int totalPage;
        Boolean flag;
        if (size % pageSize == 0) {
            totalPage = size / pageSize;
            flag = false;
        } else {
            totalPage = size / pageSize + 1;
            flag = true;
        }
        //不能完整分页
        int begin=0;
        int end=0;
        if (flag) {
            if (currentPage < totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = currentPage * pageSize - 1;
            }

            if (currentPage == totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = begin + size % pageSize;
            }

        } else {
            begin = (currentPage - 1) * pageSize;
            end = currentPage * pageSize - 1;
        }

        for (int i=0;i<pdfNewsList.size();i++){
            if(i>=begin&&i<=end){
                data.add(pdfNewsList.get(i));
            }
        }
        output.setData(data);
        output.setCurrentPage(currentPage);
        output.setTotalPage(totalPage);
        output.setTotalData(pdfNewsList.size());
        return output;

    }
}
