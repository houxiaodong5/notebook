package com.cetc54.zkb.ky.controller.output.unit;

import java.io.Serializable;

public class SimpleUnitInfo implements Serializable {

    private int id;
    private String zwm;
    private String ywm;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getZwm() {
        return zwm;
    }

    public void setZwm(String zwm) {
        this.zwm = zwm;
    }

    public String getYwm() {
        return ywm;
    }

    public void setYwm(String ywm) {
        this.ywm = ywm;
    }

    @Override
    public String toString() {
        return "SimpleUnitInfo{" +
                "id=" + id +
                ", zwm='" + zwm + '\'' +
                ", ywm='" + ywm + '\'' +
                '}';
    }
}
