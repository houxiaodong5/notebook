package com.cetc54.zkb.ky.controller.output.statistics;

import java.io.Serializable;
import java.util.List;
/**
 *      所有基地按事件类型进行统计输出model
 * */
public class StatisticsOfBaseEventByType implements Serializable {

    private String zwmc;
    private String ywmc;
    private int baseID;
    private List<String> type;
    private List<Long> num;

    public String getZwmc() {
        return zwmc;
    }

    public void setZwmc(String zwmc) {
        this.zwmc = zwmc;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public int getBaseID() {
        return baseID;
    }

    public void setBaseID(int baseID) {
        this.baseID = baseID;
    }

    public List<String> getType() {
        return type;
    }

    public void setType(List<String> type) {
        this.type = type;
    }

    public List<Long> getNum() {
        return num;
    }

    public void setNum(List<Long> num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "StatisticsOfBaseEventByType{" +
                "zwmc='" + zwmc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", baseID=" + baseID +
                ", type=" + type +
                ", num=" + num +
                '}';
    }
}
