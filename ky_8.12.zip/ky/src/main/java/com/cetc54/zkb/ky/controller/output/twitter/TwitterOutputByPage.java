package com.cetc54.zkb.ky.controller.output.twitter;


import java.io.Serializable;
import java.util.List;

public class TwitterOutputByPage implements Serializable {
    private int totalPage;
    private int currentPage;
    private int totalData;
    private List<TwitterOutput> data;

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getTotalData() {
        return totalData;
    }

    public void setTotalData(int totalData) {
        this.totalData = totalData;
    }

    public List<TwitterOutput> getData() {
        return data;
    }

    public void setData(List<TwitterOutput> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "TwitterOutputByPage{" +
                "totalPage=" + totalPage +
                ", currentPage=" + currentPage +
                ", totalData=" + totalData +
                ", data=" + data +
                '}';
    }
}
