package com.cetc54.zkb.ky.controller.output.unit;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public class UnitInfoOutput implements Serializable {

    private int id;//组织id（11美国01海军）
    private String zwm;//组织中文名
    private String ywm;//组织英文名
    private String jc;//组织简称
    private String nickname;//昵称
    private byte[] logo;//标志
    private String founded;//创建时间
    private String country;//所属国家
    private int country_id;//    所属国家id,对应location表
    private String location;//驻地
    private int location_id;//驻地_id
    private String commander;//指挥官
    private int commander_id;//person_id,对应person表
    private String history;//历史
    private String from_urls;//数据来源
    private String rksj;//入库时间
    private int gdb_used;//
    private String branch;//隶属于
    private String activeTime;//活跃时间
    private String f_type;//类型
    private String part;//part
    private String motto;//战略定位
    private String engagements;//参与战争
    private String decorations;//已获嘉奖
    private String insignia_period;//徽章所属时期
    private String insignia_period_img_url;//所属时期对应徽章url
    private byte[] insignia_period_img;//所属时期对应徽章
    private String garrison;//所在基地
    private int parentID;//上级组织

    private List<SimpleUnitInfo> children;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getZwm() {
        return zwm;
    }

    public void setZwm(String zwm) {
        this.zwm = zwm;
    }

    public String getYwm() {
        return ywm;
    }

    public void setYwm(String ywm) {
        this.ywm = ywm;
    }

    public String getJc() {
        return jc;
    }

    public void setJc(String jc) {
        this.jc = jc;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public String getFounded() {
        return founded;
    }

    public void setFounded(String founded) {
        this.founded = TimeUtil.formateStringTime(founded);
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getCountry_id() {
        return country_id;
    }

    public void setCountry_id(int country_id) {
        this.country_id = country_id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    public String getCommander() {
        return commander;
    }

    public void setCommander(String commander) {
        this.commander = commander;
    }

    public int getCommander_id() {
        return commander_id;
    }

    public void setCommander_id(int commander_id) {
        this.commander_id = commander_id;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getFrom_urls() {
        return from_urls;
    }

    public void setFrom_urls(String from_urls) {
        this.from_urls = from_urls;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }

    public int getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(int gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(String activeTime) {
        this.activeTime = activeTime;
    }

    public String getF_type() {
        return f_type;
    }

    public void setF_type(String f_type) {
        this.f_type = f_type;
    }

    public String getPart() {
        return part;
    }

    public void setPart(String part) {
        this.part = part;
    }

    public String getMotto() {
        return motto;
    }

    public void setMotto(String motto) {
        this.motto = motto;
    }

    public String getEngagements() {
        return engagements;
    }

    public void setEngagements(String engagements) {
        this.engagements = engagements;
    }

    public String getDecorations() {
        return decorations;
    }

    public void setDecorations(String decorations) {
        this.decorations = decorations;
    }

    public String getInsignia_period() {
        return insignia_period;
    }

    public void setInsignia_period(String insignia_period) {
        this.insignia_period = insignia_period;
    }

    public String getInsignia_period_img_url() {
        return insignia_period_img_url;
    }

    public void setInsignia_period_img_url(String insignia_period_img_url) {
        this.insignia_period_img_url = insignia_period_img_url;
    }

    public byte[] getInsignia_period_img() {
        return insignia_period_img;
    }

    public void setInsignia_period_img(byte[] insignia_period_img) {
        this.insignia_period_img = insignia_period_img;
    }

    public String getGarrison() {
        return garrison;
    }

    public void setGarrison(String garrison) {
        this.garrison = garrison;
    }

    public int getParentID() {
        return parentID;
    }

    public void setParentID(int parentID) {
        this.parentID = parentID;
    }

    public List<SimpleUnitInfo> getChildren() {
        return children;
    }

    public void setChildren(List<SimpleUnitInfo> children) {
        this.children = children;
    }

    @Override
    public String toString() {
        return "UnitInfoOutput{" +
                "id=" + id +
                ", zwm='" + zwm + '\'' +
                ", ywm='" + ywm + '\'' +
                ", jc='" + jc + '\'' +
                ", nickname='" + nickname + '\'' +
                ", logo=" + Arrays.toString(logo) +
                ", founded='" + founded + '\'' +
                ", country='" + country + '\'' +
                ", country_id=" + country_id +
                ", location='" + location + '\'' +
                ", location_id=" + location_id +
                ", commander='" + commander + '\'' +
                ", commander_id=" + commander_id +
                ", history='" + history + '\'' +
                ", from_urls='" + from_urls + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdb_used=" + gdb_used +
                ", branch='" + branch + '\'' +
                ", activeTime='" + activeTime + '\'' +
                ", f_type='" + f_type + '\'' +
                ", part='" + part + '\'' +
                ", motto='" + motto + '\'' +
                ", engagements='" + engagements + '\'' +
                ", decorations='" + decorations + '\'' +
                ", insignia_period='" + insignia_period + '\'' +
                ", insignia_period_img_url='" + insignia_period_img_url + '\'' +
                ", insignia_period_img=" + Arrays.toString(insignia_period_img) +
                ", garrison='" + garrison + '\'' +
                ", parentID=" + parentID +
                ", children=" + children +
                '}';
    }
}
