package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.input.ship.BaseShipInput;
import com.cetc54.zkb.ky.controller.output.ship.*;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;
import com.cetc54.zkb.ky.dao.sql.ShipSql;
import com.cetc54.zkb.ky.service.model.ShipTrajectoryModel;
import com.cetc54.zkb.ky.service.model.StatisticShipModel;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

public interface ShipDao {

    /**
     * 查询所有基地
     * */
    @SelectProvider(type = ShipSql.class,method = "baseAllQuery")
    List<ShipAndEventTodayStatisticOutput> baseAllQuery();

    /**
     *根据条件查询基地在港情况舰船
     * */
    @SelectProvider(type = ShipSql.class,method = "shipQueryByTimeAndZgzt")
    List<ShipBaseNumOutput> shipQueryByTimeAndZgzt(StatisticShipModel model);

    /**
     * 通过时间、港口ID及基地ID统计舰船
     * */
    @SelectProvider(type = ShipSql.class,method = "statisticShipByTimeAndZgqk")
    Integer statisticShipByTimeAndZgqk(StatisticShipModel model);

    /**
     * 根据港口查询船舶详情
     * */
    @SelectProvider(type = ShipSql.class,method = "queryShipByBase")
    List<ObjectShipBasicInfoEntity> queryShipByBase(BaseShipInput timeType);

    /**
     * 统计今日舰船在港、进港、离港总数
     * */
    @SelectProvider(type = ShipSql.class,method = "shipTodayStatistic")
    ShipTodayStatisticOutput shipTodayStatistic();

    /**
     * 通过时间查询所有舰船ID
     * */
    @SelectProvider(type = ShipSql.class,method = "queryShipByTime")
    List<ObjectShipBasicInfoEntity> queryShipByTime(String time);

    /**
     * 通过时间及舰船ID查询舰船轨迹
     * */
    @SelectProvider(type = ShipSql.class,method = "queryShipTrajectoryByTime")
    List<Trajectory> queryShipTrajectoryByTime(ShipTrajectoryModel model);

    /**
     * 查询舰船涉及年份
     * */
    @SelectProvider(type = ShipSql.class,method = "queryShiptYear")
    List<String> queryShiptYear();

    //根据船舶id查询船舶信息
    @SelectProvider(type = ShipSql.class,method = "queryShipByID")
    ObjectShipBasicInfoEntity queryShipByID(Integer shipID);

    @SelectProvider(type = ShipSql.class,method = "queryShipsWhereHaveEvents")
    List<ShipAllEvents> queryShipsWhereHaveEvents();

    @SelectProvider(type = ShipSql.class,method = "queryAllEventsOfShips")
    List<ShipEvent> queryAllEventsOfShips();

    @SelectProvider(type = ShipSql.class,method = "queryAllEventsOfShips_NEW")
    List<ShipEvent> queryAllEventsOfShips_NEW();

    @SelectProvider(type = ShipSql.class,method = "queryShipsByIDs")
    List<ObjectShipBasicInfoEntity> queryShipsByIDs(String sql);

    @SelectProvider(type = ShipSql.class,method = "queryShipByIDForOther")
    ObjectShipBasicInfoEntity queryShipByIDForOther(Integer shipID);
}
