package com.cetc54.zkb.ky.enums;

import java.util.ArrayList;
import java.util.List;

/**
 *      西太基地枚举
 * */
public enum BaseEnum {
    CFA_Chinhae(154),
    Osan(128),
    Kunsan(21),
    NAF_Misawa(10),
    NAF_Atsugi(75),
    CFA_Yokosuka(1),
    CFA_Sasebo(6),
    Kadena(11),
    Misawa(10),
    CFA_Okinawa(166),
    Yokota(9),
    Marianas(34),
    subic_bay_naval_station(32),
    navy_region_center_singapore(35),
    ;
    private int value;
    private static List<BaseEnum> list = new ArrayList<>();
    private static List<Integer> baseID = new ArrayList<>();
    static {
        list.add(CFA_Chinhae);
        baseID.add(CFA_Chinhae.value);
        list.add(Osan);
        baseID.add(Osan.value);
        list.add(Kunsan);
        baseID.add(Kunsan.value);
        list.add(NAF_Misawa);
        baseID.add(NAF_Misawa.value);
        list.add(NAF_Atsugi);
        baseID.add(NAF_Atsugi.value);
        list.add(CFA_Yokosuka);
        baseID.add(CFA_Yokosuka.value);
        list.add(CFA_Sasebo);
        baseID.add(CFA_Sasebo.value);
        list.add(Kadena);
        baseID.add(Kadena.value);
        list.add(Misawa);
        baseID.add(Misawa.value);
        list.add(Yokota);
        baseID.add(Yokota.value);
        list.add(Marianas);
        baseID.add(Marianas.value);
        list.add(subic_bay_naval_station);
        baseID.add(subic_bay_naval_station.value);
        list.add(navy_region_center_singapore);
        baseID.add(navy_region_center_singapore.value);
        list.add(CFA_Okinawa);
        baseID.add(CFA_Okinawa.value);
    }
    BaseEnum(int value){
        this.value=value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public static List<BaseEnum> allOf(){
        return list;
    }

    public static List<Integer> allOfBaseID(){
        return baseID;
    }

}
