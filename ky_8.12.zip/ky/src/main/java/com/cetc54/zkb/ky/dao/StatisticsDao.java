package com.cetc54.zkb.ky.dao;

import com.cetc54.zkb.ky.controller.input.event.EventQueryByIDAndTime;
import com.cetc54.zkb.ky.controller.output.event.*;
import com.cetc54.zkb.ky.controller.output.ship.StatisticsOfShipState;
import com.cetc54.zkb.ky.controller.output.statistics.StatisticsEventOutput;
import com.cetc54.zkb.ky.controller.output.statistics.StatisticsMode;
import com.cetc54.zkb.ky.dao.entity.ObjectBaseBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipBasicInfoEntity;
import com.cetc54.zkb.ky.dao.entity.ObjectShipEntity;
import com.cetc54.zkb.ky.dao.sql.StatisticsSql;
import com.cetc54.zkb.ky.service.model.QueryModel;
import com.cetc54.zkb.ky.service.model.SliceOfTime;
import com.cetc54.zkb.ky.service.model.StatisticOfWestPacificBaseEventModel;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;
import java.util.Map;

//统计相关dao
public interface StatisticsDao {

    //人名次数统计
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestPersonOneMonth")
    List<StatisticsMode> queryHottestPersonOneMonth();
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestPersonOneWeek")
    List<StatisticsMode> queryHottestPersonOneWeek();
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestPersonThreeDay")
    List<StatisticsMode> queryHottestPersonThreeDay();

    //舰船次数统计
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestShipOneMonth")
    List<StatisticsMode> queryHottestShipOneMonth();
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestShipOneWeek")
    List<StatisticsMode> queryHottestShipOneWeek();
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestShipThreeDay")
    List<StatisticsMode> queryHottestShipThreeDay();

    //基地次数统计
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestBaseOneMonth")
    List<StatisticsMode> queryHottestBaseOneMonth();
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestBaseOneWeek")
    List<StatisticsMode> queryHottestBaseOneWeek();
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestBaseThreeDay")
    List<StatisticsMode> queryHottestBaseThreeDay();

    //热词统计
    @SelectProvider(type = StatisticsSql.class,method = "queryHottestWords")
    List<Map<String,Object>> queryHottestWords();

    //昨日事件统计
    @SelectProvider(type = StatisticsSql.class,method = "statisticsYesterdayEvent")
    Integer statisticsYesterdayEvent(String time);

    //补充热词标签
    @SelectProvider(type = StatisticsSql.class,method = "selectHottestShip")
    List<HotWord> selectHottestShip(int num);

    /*//查询所有西太基地的标签集
    @SelectProvider(type = StatisticsSql.class,method = "queryTypesOfWestPacificBase")
    List<String> queryTypesOfWestPacificBase(List<Integer> baseIDS);*/

    @SelectProvider(type = StatisticsSql.class,method = "StatisticOfWestPacificBaseEvent")
    List<StatisticOfWestPacificBaseEventModel> StatisticOfWestPacificBaseEvent(int baseID,String type);

    @SelectProvider(type = StatisticsSql.class,method = "queryBaseByID")
    List<ObjectBaseBasicInfoEntity> queryBaseByID(@Param("baseIDs") List<Integer> baseIDs);

    //西太地区：统计某个基地的演习事件总数
    @SelectProvider(type = StatisticsSql.class,method = "statisticsManoeuvreOfBaseByTime")
    int statisticsManoeuvreOfBaseByTime(@Param("baseID") int baseID,@Param("slice") SliceOfTime slice);

    //查询所有西太地区舰船基本信息
    @SelectProvider(type = StatisticsSql.class,method = "queryBasicShipMsg")
    List<StatisticsEventOutput> queryBasicShipMsg(@Param("baseIDs") List<Integer> baseIDs);

    //追加舰船数据，扩充⬆信息  relation_ship_location  判断此表中qymc是否为空
    @SelectProvider(type = StatisticsSql.class,method = "queryBasicShipMsgExtra")
    List<StatisticsEventOutput> queryBasicShipMsgExtra();

    //按时间统计西太地区舰船事件数量
    @SelectProvider(type = StatisticsSql.class,method = "statisticsEventByTime")
    //int statisticsEventByTime(@Param("shipID") int shipID,@Param("slice")SliceOfTime slice);
    List<String> statisticsEventByTime(@Param("shipID") int shipID,@Param("slice")SliceOfTime slice,@Param("baseIDs") List<Integer> baseIDs);

    @SelectProvider(type = StatisticsSql.class,method = "statisticsEventByTime_Extra")
    List<String> statisticsEventByTime_Extra(@Param("shipID") int shipID,@Param("slice")SliceOfTime slice);

    //查询西太地区的人物
    @SelectProvider(type = StatisticsSql.class,method = "queryPersonByBase")
    List<StatisticsEventOutput> queryPersonByBase(@Param("baseIDs") List<Integer> baseIDs,@Param("time")String time);

    //统计人物事件
    @SelectProvider(type = StatisticsSql.class,method = "statisticsEventByTimeOfPerson")
    List<String> statisticsEventByTimeOfPerson(@Param("personID") int personID,@Param("slice") SliceOfTime slice);
    //统计人物事件
    @SelectProvider(type = StatisticsSql.class,method = "statisticsEventByTimeOfPerson_extra")
    List<String> statisticsEventByTimeOfPerson_extra(@Param("baseIDs") List<Integer> baseIDs, @Param("slice") SliceOfTime slice);

    //西太地区舰船进出港统计
    @SelectProvider(type = StatisticsSql.class,method = "statisticsQuantityOfShipByState")
    List<StatisticsOfShipState> statisticsQuantityOfShipByState(@Param("baseIDs")List<Integer> baseIDs);

    //西太地区:查询一段时间内事件最多的基地信息
    @SelectProvider(type = StatisticsSql.class,method = "queryMostEventOfBaseByTime")
    List<StatisticsEventOutput> queryMostEventOfBaseByTime(@Param("slice") SliceOfTime slice,@Param("baseIDs") List<Integer> baseIDs);

    //统计具体时间内某个基地事件总数
    @SelectProvider(type = StatisticsSql.class,method = "statisticsEventCountByBaseIDInSliceOfTime")
    Integer statisticsEventCountByBaseIDInSliceOfTime(@Param("baseID") Integer baseID,@Param("slice") SliceOfTime slice);

    //西太地区：根据标签统计一段时间内的事件数量
    @SelectProvider(type = StatisticsSql.class,method = "statisticsEventByTimeAndType")
    Integer statisticsEventByTimeAndType(@Param("baseIDs")List<Integer> baseIDs,@Param("slice") SliceOfTime slice,@Param("type") String type);

    //根据时间段统计西太地区舰船在港、离港数量
    @SelectProvider(type = StatisticsSql.class,method = "statisticsShipByStateAndSliceOfTime")
    List<Integer> statisticsShipByStateAndSliceOfTime(@Param("slice") SliceOfTime slice);//list[0]-在港,list[1]不在港

    //根据时间及舰船状态查询对应舰船
    @SelectProvider(type = StatisticsSql.class,method = "queryShipsByStateAndTime")
    List<ObjectShipBasicInfoEntity> queryShipsByStateAndTime(QueryModel model);

    //根据时间及舰船、舰船状态查询对应事件
    @SelectProvider(type = StatisticsSql.class,method = "queryEventsByStateAndTimeAndShipID")
    List<ObjectEventOutput> queryEventsByStateAndTimeAndShipID(QueryModel model);

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>,携带相关人物、舰船、基地
    @SelectProvider(type = StatisticsSql.class,method = "queryEventsByTypeAndTime")
    List<EventAllMsgs> queryEventsByTypeAndTime(@Param("type") String type, @Param("slice") SliceOfTime slice, @Param("flag") String flag);

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关人物  填充127数据
    @SelectProvider(type = StatisticsSql.class,method = "querySimplePersonByUUID")
    List<SimpleModel>  querySimplePersonByUUID(String uuid);

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关舰船  填充127数据
    @SelectProvider(type = StatisticsSql.class,method = "querySimpleShipByUUID")
    List<SimpleModel>  querySimpleShipByUUID(String uuid);

    //西太地区：根据事件类型及时间查询对应事件<1,3月,1年>相关基地  填充127数据
    @SelectProvider(type = StatisticsSql.class,method = "querySimpleBaseByUUID")
    List<SimpleModel>  querySimpleBaseByUUID(String uuid);

    //西太地区：根据基地id及时间查询事件信息
    @SelectProvider(type = StatisticsSql.class,method = "queryEventsByTimeAndBaseID")
    List<EventAllMsgs>  queryEventsByTimeAndBaseID(@Param("slice") SliceOfTime slice,@Param("id") Integer id);

    //西太地区：根据事件类型及基地id查询相关事件
    @SelectProvider(type = StatisticsSql.class,method = "queryEventsByTypeAndBaseID")
    List<EventAllMsgs> queryEventsByTypeAndBaseID(EventQueryByIDAndTime input);

    //统计用户查看最多的新闻(前20条)
    @SelectProvider(type = StatisticsSql.class,method = "statisticsMostEventsOfViewed")
    List<EventAllMsgs> statisticsMostEventsOfViewed();

}

