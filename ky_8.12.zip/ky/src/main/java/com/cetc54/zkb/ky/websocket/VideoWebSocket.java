package com.cetc54.zkb.ky.websocket;


import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.controller.TwitterController;
import com.cetc54.zkb.ky.controller.output.VideoOutput;
import com.cetc54.zkb.ky.util.YjsonUtil;
import org.springframework.stereotype.Component;


@ServerEndpoint("/websocket/video")
@Component
public class VideoWebSocket extends BaseController {
    private static ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();


    //静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
    private static int onlineCount = 0;
    //concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。
    private static CopyOnWriteArraySet<VideoWebSocket> webSocketSet = new CopyOnWriteArraySet<>();

    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;

    //接收sid
    //private String sid = "";

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session) {
        System.out.println("连接已建立");
        try {
            this.session = session;
            webSocketSet.add(this);     //加入set中
            addOnlineCount();           //在线数加1
            // this.sid = sid;
            //sendMSG(this.eventService.queryAllEvent());
            do {
                sendMSG(session, TwitterController.videoList);
                Thread.sleep(5000);
            } while (true);
        } catch (Exception e) {
        }
    }

    public void sendMSG(Session session, List<VideoOutput> videoList) {
        try {
            //发送事件及爬取日志
            for (VideoOutput output : videoList) {

                synchronized (this) {
                    if (session.isOpen()) {
                        sendMessage(session, YjsonUtil.toJson(this.success(output)));
                        System.out.println("Video："+output);
                        Thread.sleep(5000);
                    } else {
                        return;
                    }

                }


            }
        } catch (Exception e) {
        }
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        System.out.println("自动关闭连接");
        webSocketSet.remove(this);  //从set中删除
        subOnlineCount();           //在线数减1
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        //群发消息
       /* for (WebSocket item : webSocketSet) {
            try {
                item.sendMessage(session,message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }*/
    }

    /**
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    /**
     * 实现服务器主动推送
     */
    public void sendMessage(Session session, String message) throws IOException {
        try {

            if (session.isOpen()) {
                session.getBasicRemote().sendText(message);
            }

        } catch (Exception e) {
            throw new IOException("发送失败");
        }
    }


    /**
     * 群发自定义消息
     */
    public static void sendInfo(String message, @PathParam("sid") String sid) throws IOException {

    }

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        VideoWebSocket.onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        VideoWebSocket.onlineCount--;
    }
}

