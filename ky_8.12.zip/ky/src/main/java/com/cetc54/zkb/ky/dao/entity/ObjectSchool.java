package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.util.TimeUtil;

import java.io.Serializable;
/**
 *      学校信息表
 * */
public class ObjectSchool implements Serializable {
    private int id;
    private String jyjgnm;
    private String mc;
    private String ywmc;
    private String szdd;
    private String jj;
    private String lsy;
    private String cjsj;
    private int gdb_used;
    private String website;
    private String jlsj;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJyjgnm() {
        return jyjgnm;
    }

    public void setJyjgnm(String jyjgnm) {
        this.jyjgnm = jyjgnm;
    }

    public String getMc() {
        return mc;
    }

    public void setMc(String mc) {
        this.mc = mc;
    }

    public String getYwmc() {
        return ywmc;
    }

    public void setYwmc(String ywmc) {
        this.ywmc = ywmc;
    }

    public String getSzdd() {
        return szdd;
    }

    public void setSzdd(String szdd) {
        this.szdd = szdd;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getLsy() {
        return lsy;
    }

    public void setLsy(String lsy) {
        this.lsy = lsy;
    }

    public String getCjsj() {
        return cjsj;
    }

    public void setCjsj(String cjsj) {
        this.cjsj = TimeUtil.formateStringTime(cjsj);
    }

    public int getGdb_used() {
        return gdb_used;
    }

    public void setGdb_used(int gdb_used) {
        this.gdb_used = gdb_used;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getJlsj() {
        return jlsj;
    }

    public void setJlsj(String jlsj) {
        this.jlsj = TimeUtil.formateStringTime(jlsj);
    }

    @Override
    public String toString() {
        return "ObjectSchool{" +
                "id=" + id +
                ", jyjgnm='" + jyjgnm + '\'' +
                ", mc='" + mc + '\'' +
                ", ywmc='" + ywmc + '\'' +
                ", szdd='" + szdd + '\'' +
                ", jj='" + jj + '\'' +
                ", lsy='" + lsy + '\'' +
                ", cjsj='" + cjsj + '\'' +
                ", gdb_used=" + gdb_used +
                ", website='" + website + '\'' +
                ", jlsj='" + jlsj + '\'' +
                '}';
    }
}
