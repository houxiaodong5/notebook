package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.EventQueryByID;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonOrShipsInput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.ship.ObjectShipOutput;
import com.cetc54.zkb.ky.dao.entity.*;
import com.cetc54.zkb.ky.service.LocationService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by Administrator on 2019/5/25/025.
 */
@RestController
@Api("地点controller")
public class LocationController extends BaseController{

    @Autowired
    private LocationService locationService;

    @ApiOperation("查询所有地点")
    @GetMapping({"/location/all/query"})
    public DataResponse<List<ObjectLocation>> queryAllLocation(){


        return this.success(locationService.queryAllLocation());
    }

    @ApiOperation("根据地点id查询此地事件")
    @GetMapping({"/query/event/by/locationID"})
    public DataResponse<List<ObjectEventOutput>> queryEventByLocationID(String ddid){
        return this.success(locationService.queryAllEventByLocationID(ddid));
    }

    @ApiOperation("查询所有基地")
    @GetMapping({"/base/all/query"})
    public DataResponse<List<ObjectBaseBasicInfoEntity>> queryAllBase() {
        return this.success(locationService.queryAllBase());
    }

    @ApiOperation("根据基地ID查询此基地所发生的所有事件")
    @PostMapping({"/query/all/event/by/base"})
    public DataResponse<List<ObjectEventOutput>> queryAllEventByBaseID(@RequestBody EventQueryByID input) {
        return this.success(locationService.queryAllEventByBaseID(input));
    }

    @ApiOperation("查询所有人物")
    @GetMapping({"/query/all/person"})
    public DataResponse<ObjectPerson> queryAllPerson(){
        return this.success(locationService.queryAllPerson());
    }

    @ApiOperation("根据人物ID或姓名查询对应事件")
    @GetMapping({"/query/all/event/by/personID"})
    public DataResponse<List<ObjectEventOutput>> queryAllEventByPersonID(Integer renwuid,String name){
        return this.success(locationService.queryAllEventByPersonID(renwuid,name));
    }

    @ApiOperation("查询所有船舶")
    @GetMapping({"/query/all/ship"})
    public DataResponse<ObjectShipBasicInfoEntity> queryAllShip(){
        return this.success(locationService.queryAllShip());
    }

    @ApiOperation("根据船舶ID查询船舶事件--含有进出港数据的事件")
    @GetMapping({"/query/event/by/shipID"})
    public DataResponse<ObjectEventOutput> queryEventByShipID(Integer id){
        return this.success(locationService.queryEventByShipID(id));
    }

    @ApiOperation("根据船舶ID查询船舶所有事件")
    @GetMapping({"/query/all/event/by/shipID"})
    public DataResponse<ObjectEventOutput> queryAllEventByShipID(Integer id){
        return this.success(locationService.queryAllEventByShipID(id));
    }

    @ApiOperation("根据基地ID查询基地信息<三泽基地>")
    @GetMapping({"/query/base/by/baseID"})
    public DataResponse<ObjectBaseBasicInfoEntity> queryBaseByBaseID(int baseID){
        return this.success(locationService.queryBaseByBaseID(baseID));
    }

    @ApiOperation("根据基地ID查询基地信息<非三泽基地>")
    @GetMapping({"/query/other/base/by/baseID"})
    public DataResponse<ObjectBaseBasicInfoEntity> queryOtherBaseByBaseID(int baseID){
        return this.success(locationService.queryOtherBaseByBaseID(baseID));
    }

    @ApiOperation("根据人员ID查询人员")
    @GetMapping({"/query/person/by/personID"})
    public DataResponse<ObjectPerson> queryPersonByPersonID(int personID){
        return this.success(locationService.queryPersonByPersonID(personID));
    }


    @ApiOperation("根据人员id查询人员集合")
    @PostMapping({"/query/person/by/personIDs"})
    public DataResponse<ObjectPerson> queryPersonByPersonIDs(@RequestBody QueryPersonOrShipsInput input){
        return this.success(locationService.queryPersonByPersonIDs(input));
    }

}









