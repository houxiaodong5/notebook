package com.cetc54.zkb.ky.controller.input.user;

import java.io.Serializable;

/**
 *      接受用户观看记录实体
 * */
public class UserViewRecord implements Serializable {
    private int userID;
    private String eventID;
    private String eventType;

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @Override
    public String toString() {
        return "UserViewRecord{" +
                "userID=" + userID +
                ", eventID='" + eventID + '\'' +
                ", newsType='" + eventType + '\'' +
                '}';
    }
}
