package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.elasticsearch.document.Person;
import com.cetc54.zkb.ky.elasticsearch.document.Position;
import com.cetc54.zkb.ky.elasticsearch.repository.PosSearchRepository;
import com.cetc54.zkb.ky.util.ReadXML;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.awt.geom.Area;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;

@Api("elasticsearch查询位置信息controller")
@RestController
public class PositionController extends BaseController {
    private static Logger logger = LoggerFactory.getLogger(PositionController.class);
    private static ConcurrentHashMap<String, HashSet<String>> map = new ConcurrentHashMap<>();
    @Autowired
    private PosSearchRepository posSearchRepository;
    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Value("filePath")
    private String filePath;


    @ApiOperation("根据地名查询地理信息")
    @ApiImplicitParam(name = "name", value = "地名")
    @GetMapping("/query/position/by/name")
    public DataResponse<List<Position>> queryPositionByName(String name) {
        return this.success(posSearchRepository.queryAllByNameContains(name));
    }

    @ApiOperation("鼠标键入搜索")
    @ApiImplicitParam(name = "word", value = "关键词")
    @GetMapping("/query/name/by/word")
    public DataResponse<HashSet<String>> queryNameByWord(String word) {

        try {
            if (map.get(word) == null) {
                HashSet<String> dataSet = new HashSet<>();
                List<Position> list = posSearchRepository.queryNameByNameContains(word);
                for (Position pos : list) {
                    dataSet.add(pos.getName());
                }
                map.put(word, dataSet);
                return this.success(dataSet);
            } else return this.success(map.get(word));
        } catch (Exception e) {
           logger.info(e.getMessage());
           return null;
        }





        /*  有待优化
        SearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withIndices("geo_names")
                .withTypes("items")
                .withFields("name")
                .withSort(new FieldSortBuilder("name").order(SortOrder.ASC))
                .withPageable(new PageRequest(1,100))
                .build();
        List<Object> list = elasticsearchTemplate.queryForList(searchQuery, Object.class);
        System.out.println(list.size());
        return null;*/
    }

    @ApiOperation("解析XML返回JSON数据")
    //@ApiImplicitParam(name = "filePath", value = "文件路径")
/*    @PostMapping(value = "/read/xml",consumes = "multipart/*",headers = "content-type=multipart/form-data")
    public DataResponse<List<Area>> readXML(@ApiParam(value = "上传XML文件",required = true) MultipartFile file, HttpServletRequest request){*/
    @GetMapping(value = "/read/xml")
    public DataResponse<List<Area>> readXML() {
        //String originalFilename = file.getOriginalFilename();
        // System.out.println(originalFilename);
        //String filePath="C:\\Users\\Administrator.WIN-F64LG4L5QFQ\\Desktop\\openaip_airspace_japan_jp.xml";
        filePath= "D:\\data\\openaip_airspace_japan_jp.xml";
        System.out.println(filePath);
        return this.success(ReadXML.readXML(filePath));
    }

    /*@GetMapping("/test/1")
    public Object ss(){
        QueryBuilder queryBuilder = QueryBuilders.matchQuery("zwxm", "特朗普");
        NativeSearchQueryBuilder query = new NativeSearchQueryBuilder().withQuery(queryBuilder);
        SearchQuery searchQuery = new NativeSearchQueryBuilder().withQuery(queryStringQuery("特朗普")).build();
        List<Person> articles = elasticsearchTemplate.queryForList(searchQuery, Person.class);
        System.out.println(articles);
        return articles;

        //List<Person> list=elasticsearchTemplate.queryForList(queryBuilder, Person.class);
    }*/
}
