package com.cetc54.zkb.ky.dao.sql;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.jdbc.SQL;

public class CountrySql {

    /**
     * 查询所有国家
     * */
    public String queryAllCountry(String country) {
        return (new SQL() {
            {
                this.SELECT("*");
                this.FROM("object_country");
                if (StringUtils.isNotBlank(country)) {
                    this.WHERE("gj_cn LIKE '%' #{country} '%' OR gj_en LIKE '%' #{country} '%'");
                }

                this.ORDER_BY("cast(`pm` as SIGNED)");
            }
        }).toString();
    }

}
