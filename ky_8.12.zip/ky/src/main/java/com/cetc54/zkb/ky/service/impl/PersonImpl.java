package com.cetc54.zkb.ky.service.impl;

import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonByConditionsInput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.person.ConditionsOfFilter;
import com.cetc54.zkb.ky.controller.output.person.HistoryOfWork;
import com.cetc54.zkb.ky.controller.output.person.OrigConditions;
import com.cetc54.zkb.ky.controller.output.person.PersonOutput;
import com.cetc54.zkb.ky.dao.PersonDao;
import com.cetc54.zkb.ky.dao.entity.*;
import com.cetc54.zkb.ky.elasticsearch.document.Person;
import com.cetc54.zkb.ky.service.PersonService;
import com.cetc54.zkb.ky.util.OSSUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

@Service
public class PersonImpl implements PersonService {

    @Autowired
    private PersonDao personDao;
    private Logger logger = LoggerFactory.getLogger(PersonImpl.class);

    //人物筛选：筛选条件
    @Override
    public ConditionsOfFilter queryConditionsOfFilter() {
        ConditionsOfFilter conditions = new ConditionsOfFilter();
        List<OrigConditions> list = personDao.queryConditionsOfFilter();
        HashSet<String> country = new LinkedHashSet<>();
        HashSet<String> country_CN = new LinkedHashSet<>();
        HashSet<String> militaryRank = new LinkedHashSet<>();
        HashSet<String> militaryRank_CN = new LinkedHashSet<>();
        HashSet<String> post = new LinkedHashSet<>();
        HashSet<String> post_CN = new LinkedHashSet<>();
        HashSet<String> category = new LinkedHashSet<>();
        for (OrigConditions data : list) {
            if (StringUtils.isNotEmpty(data.getGj())) {
                country.add(data.getGj());
            }
            if (StringUtils.isNotEmpty(data.getZwgjm())) {
                country_CN.add(data.getZwgjm());
            }

            if (StringUtils.isNotEmpty(data.getJx())) {
                militaryRank.add(data.getJx());
            }
            if (StringUtils.isNotEmpty(data.getZwjx())) {
                militaryRank_CN.add(data.getZwjx());
            }

            if (StringUtils.isNotEmpty(data.getZw())) {
                post.add(data.getZw());
            }
            if (StringUtils.isNotEmpty(data.getZwzw())) {
                post_CN.add(data.getZwzw());
            }

            if (StringUtils.isNotEmpty(data.getRylb())) {
                category.add(data.getRylb());
            }

        }

        conditions.setCountry(country);
        conditions.setCountry_CN(country_CN);
        conditions.setMilitaryRank(militaryRank);
        conditions.setMilitaryRank_CN(militaryRank_CN);
        conditions.setPost(post);
        conditions.setPost_CN(post_CN);
        conditions.setCategory(category);
        return conditions;
    }

    @Override
    public PageInfo<ObjectPerson> queryPersonByConditions(QueryPersonByConditionsInput input) {
        PageHelper.startPage(input.getPageNum(), input.getPageSize());
        List<ObjectPerson> list = personDao.queryPersonByConditions(input);
        PageInfo<ObjectPerson> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public List<ObjectSchool> querySchoolByUserID(int userID) {
        try {
            List<ObjectSchool> list = personDao.querySchoolByUserID(userID);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("操作失败");
            return null;

        }
    }

    @Override
    public List<ObjectMilitaryActivity> queryActivitiesOfMilitaryByUserID(int userID) {
        try {
            List<ObjectMilitaryActivity> list = personDao.queryActivitiesOfMilitaryByUserID(userID);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("操作失败");
            return null;

        }
    }

    @Override
    public List<ObjectHonor> queryHonorByUserID(int userID) {
        try {
            List<ObjectHonor> list = personDao.queryHonorByUserID(userID);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("操作失败");
            return null;

        }
    }

    @Override
    public HistoryOfWork queryHistoryOfWorkByUserID(int userID) {
        HistoryOfWork work = new HistoryOfWork();
        try {
            List<ObjectTroops> troopsList = personDao.queryHistoryOfTroopsByUserID(userID);
            List<ObjectShipBasicInfoEntity> shipList = personDao.queryHistoryOfShipByUserID(userID);
            work.setTroopsList(troopsList);
            work.setShipList(shipList);
            return work;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("操作失败");
            return work;

        }
    }

    @Override
    public HashSet<String> queryAllPerson() {
        HashSet<String> data = new LinkedHashSet<>();
        List<PersonOutput> list = personDao.queryAllPerson();
        for (PersonOutput output : list) {
            String zwxm = output.getZwxm();
            String ywxm = output.getYwxm();
            if (StringUtils.isNotBlank(zwxm)) {
                data.add(zwxm);
            }

            if (StringUtils.isNotBlank(ywxm)) {
                data.add(ywxm);
            }
            continue;
        }
        return data;
    }


    @Override
    public List<Person> queryAllPersonSimpleMsg() {
        return personDao.queryAllPersonSimpleMsg();
    }

    @Override
    public PageInfo<PersonOutput> queryAllPersonMessage(QueryByPage input) {
        PageHelper.startPage(input.getPageNum(), input.getPageSize());
        List<PersonOutput> list = personDao.queryAllPersonMessage();
        PageInfo<PersonOutput> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public String updatePersonImg(int userID, int personID, MultipartFile file) {
        if(file.isEmpty()||userID==0||personID==0){
            return "参数不可为空";
        }
        try {
            String ossUrl = OSSUtil.updateImgToOSS("ky-person", "img/", file);
            byte[] img_bytes = file.getBytes();
            PersonOutput personOutput = new PersonOutput();
            personOutput.setTx(ossUrl);
            personOutput.setTxpic(img_bytes);
            personOutput.setRenwuid(personID);
            personDao.updatePersonImg(personOutput);
            logger.info("更新人物图像 <操作人ID:"+userID+"    人物ID:"+personID+"> ");
            return "操作成功";
        } catch (IOException e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            e.printStackTrace();
            return "操作失败";
        }

    }

    @Override
    public String updatePersonMessage(HttpServletRequest request,PersonOutput personOutput) {
        if(personOutput.getRenwuid()==0){
            return "参数不合法";
        }
        try {
            personDao.updatePersonMessage(personOutput);
            UserInfoEntity user = (UserInfoEntity) request.getSession().getAttribute("user");
            if (user!=null){
                logger.info("更新人物数据    操作人id："+user.getId());
            }
            return "操作成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "操作失败";
        }
    }
}
