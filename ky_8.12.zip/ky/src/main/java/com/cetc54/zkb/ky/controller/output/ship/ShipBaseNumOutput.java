package com.cetc54.zkb.ky.controller.output.ship;

public class ShipBaseNumOutput {
    private Integer number;
    private Integer gkid;

    public Integer getNumber() {
        return this.number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getGkid() {
        return this.gkid;
    }

    public void setGkid(Integer gkid) {
        this.gkid = gkid;
    }
}

