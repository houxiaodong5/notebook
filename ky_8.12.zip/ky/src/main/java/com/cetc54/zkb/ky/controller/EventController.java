package com.cetc54.zkb.ky.controller;

import com.cetc54.zkb.ky.constraint.BaseController;
import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.*;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.event.*;
import com.cetc54.zkb.ky.service.EventService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

@Api("事件controller")
@RestController
public class EventController extends BaseController {
    @Resource
    private EventService eventService;
    public static List<EventAllMessageOutput> list;
    private  List<EventOutputGroupByType>  typeList;

    @ApiOperation("查询所有事件")
    @GetMapping({"/event/all/query"})
    private DataResponse<ObjectEventOutput> queryAllEvent() {
        return this.success(this.eventService.queryAllEvent());
    }


    @ApiOperation("分页查询所有事件<不过滤>")//8-9
    @PostMapping("/query/event/by/page")
    private DataResponse<EventAllMessageOutput>  queryAllEventByPage(@RequestBody QueryByPage page){
        return this.success(eventService.queryAllEventByPage(page));
    }

    @ApiOperation("查询所有事件等级")
    @GetMapping({"/event/grade/query"})
    private DataResponse<List<String>> queryAllEventGrade() {
        return this.success(this.eventService.queryAllEventGrade());
    }

    @ApiOperation("查询所有事件类型")
    @GetMapping({"/event/all/type/query"})
    private DataResponse<List<String>> queryAllEventType() {
        return this.success(this.eventService.queryAllEventType());
    }

    @ApiOperation("根据事件类型及年、月、周统计")
    @GetMapping({"/event/by/time/type/statistic"})
    private DataResponse<List<EventTimeStatisticOutput>> statisticEventByTimeType(StatisticEventByTimeInput input) {
        return this.success(this.eventService.statisticEventByTimeType(input));
    }

    @ApiOperation("根据不同条件统计事件总数、实时推送、当天事件")
    @GetMapping({"/event/statistic"})
    private DataResponse<List<EventStatisticOutput>> statisticEvent() {
        return this.success(this.eventService.statisticEvent());
    }

    @ApiOperation("查询当天事件")
    @GetMapping({"/event/today/query"})
    private DataResponse<List<ObjectEventOutput>> queryEventToday() {
        return this.success(this.eventService.queryEventToday());
    }

    @ApiOperation("根据事件ID查询事件详情")
    @ApiImplicitParam(name = "id", value = "事件ID")
    @GetMapping({"/event/by/id/query"})
    private DataResponse<List<ObjectEventOutput>> queryEventById(String id) {
        return this.success(this.eventService.queryEventById(id));
    }

    @ApiOperation("通过条件查询事件")
    @GetMapping({"/event/query"})
    private DataResponse<EventQueryOutput2> queryEvent(EventQueryInput input) {
        return this.success(this.eventService.queryEvent(input));
    }

    @ApiOperation("所有威胁等级")
    @GetMapping({"/all/wxdj"})
    private DataResponse<String> queryAllWxdj() {
        return this.success(this.eventService.queryAllWxdj());
    }

    //更新事件
    //定时查询数据库(1分钟)   事件更新较慢，1分钟更新一次
    @Scheduled(fixedRate = 60 * 1000 )
    public void queryAllEventTimely() {
        //List<EventAllMessageOutput> event = eventService.queryLatestEvent();
        List<EventAllMessageOutput> event = eventService.queryLatestEventNOFitlter();
        int size = event.size();
        if(size==5){
            list = event;
        }else if(size>0&&size<5){
           list.addAll(event);
            Collections.sort(list);
            Collections.reverse(list);
            list=list.subList(0,5);
        }else return;

    }

    //
    @ApiOperation("根据事件类型进行统计事件")
    @GetMapping({"/statistic/by/eventType"})
    public DataResponse<EventStatisticByTypeOutput> statisticByEventType() {
        return this.success(eventService.statisticByEventType());
    }

    @ApiOperation("用户为事件自定义标签")
    @PostMapping({"/diy/tag/for/event"})
    public DataResponse<String> diyTagForEvent(@RequestBody EventTagInput input){
        return this.success(eventService.diyTagForEvent(input));
    }


    @ApiOperation("根据时间范围查询事件")
    @PostMapping({"/query/event/by/time1"})
    public DataResponse<PageInfo<ObjectEventOutput>> queryEventByTime1(@RequestBody EventQueryInput input ){
        return this.success(eventService.queryEventByTime1(input));
    }
    @ApiOperation("根据时间范围查询事件")
    @PostMapping({"/query/event/by/time"})
    public DataResponse<PageInfo<ObjectEventOutput>> queryEventByTime(@RequestBody EventQueryByPage input){
        System.out.println(input);
        return this.success(eventService.queryEventByTime(input));
    }

    @ApiOperation(value = "根据标签查询事件")
    @GetMapping({"/query/event/by/tag"})
    public DataResponse<List<ObjectEventOutput>> queryEventByTag(String tag){
        return this.success(eventService.queryEventByTag(tag));
    }

    @ApiOperation(value = "根据地点名称，事件类型<默认为演习>查询事件",notes = "**必填参数：pageSize,pageNum,location \n **可选参数：eventType")
    @PostMapping({"/query/event/by/location/and/eventType"})
    public DataResponse<PageInfo<ObjectEventOutput>> queryEventByLocationAndEventType(@RequestBody EventQueryByPage input){
        return this.success(eventService.queryEventByLocationAndEventType(input));
    }

    @ApiOperation("根据数据源查询对应事件")
    @PostMapping({"/query/event/by/datasource"})
    public  DataResponse<PageInfo<ObjectEventOutput>> queryEventByDatasource(@RequestBody EventQueryByDataSource input){
        return this.success(eventService.queryEventByDatasource(input));
    }

    @ApiOperation("根据舰船或人物id查询及时间点查询事件")
    @PostMapping("/query/event/by/ID/and/time")
    public DataResponse<List<ObjectEventOutput>> queryEventByIDAndTime(@RequestBody EventQueryByIDAndTime input){
        return this.success(eventService.queryEventByIDAndTime(input));
    }

    @ApiOperation("按类型查询西太地区所有事件")
    @GetMapping("/query/event/group/by/type")
    public DataResponse<List<EventOutputGroupByType>> queryEventGroupByType(){
        return this.success(typeList);
    }


    @Scheduled(fixedRate = 60 * 1000 * 5)
    public void updateQueryEventGroupByType(){
        List<EventOutputGroupByType> types = eventService.queryEventGroupByType();
        if(types.size()>0){
            typeList=types;
        }
    }



}
