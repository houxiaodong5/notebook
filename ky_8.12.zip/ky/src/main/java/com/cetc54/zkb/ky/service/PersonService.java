package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.input.person.QueryPersonByConditionsInput;
import com.cetc54.zkb.ky.controller.output.person.ConditionsOfFilter;
import com.cetc54.zkb.ky.controller.output.person.HistoryOfWork;
import com.cetc54.zkb.ky.controller.output.person.PersonOutput;
import com.cetc54.zkb.ky.dao.entity.ObjectHonor;
import com.cetc54.zkb.ky.dao.entity.ObjectMilitaryActivity;
import com.cetc54.zkb.ky.dao.entity.ObjectPerson;
import com.cetc54.zkb.ky.dao.entity.ObjectSchool;
import com.cetc54.zkb.ky.elasticsearch.document.Person;
import com.github.pagehelper.PageInfo;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.List;


public interface PersonService {
    ConditionsOfFilter queryConditionsOfFilter();

    PageInfo<ObjectPerson> queryPersonByConditions(QueryPersonByConditionsInput input);

    List<ObjectSchool> querySchoolByUserID(int userID);

    List<ObjectMilitaryActivity> queryActivitiesOfMilitaryByUserID(int userID);

    List<ObjectHonor> queryHonorByUserID(int userID);

    HistoryOfWork queryHistoryOfWorkByUserID(int userID);

    HashSet<String> queryAllPerson();

    List<Person> queryAllPersonSimpleMsg();

    PageInfo<PersonOutput> queryAllPersonMessage(QueryByPage input);

    String updatePersonImg(int userID, int personID, MultipartFile file);

    String updatePersonMessage(HttpServletRequest request,PersonOutput personOutput);

}
