package com.cetc54.zkb.ky.service;

import com.cetc54.zkb.ky.constraint.DataResponse;
import com.cetc54.zkb.ky.controller.input.event.QueryDataPage;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.NewsOutputByPage;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutputByPage;
import com.cetc54.zkb.ky.controller.output.source.OutputSource;
import com.cetc54.zkb.ky.dao.entity.NewsEntitry;
import com.cetc54.zkb.ky.dao.entity.NewsEntity;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface NewsService {
    NewsEntitry queryLatestNews();
    List<OutputSource> queryAllSource();
    PageInfo<ObjectEventOutput> queryDataBySource(QueryDataPage queryDataPage);
    ObjectEventOutputByPage queryDataBySource1(QueryDataPage queryDataPage);
    NewsOutputByPage queryImageNewsTimely(QueryByPage page);
    NewsOutputByPage queryVideoNewsTimely( QueryByPage page);
    NewsOutputByPage queryPdfNewsTimely( QueryByPage page);
}
