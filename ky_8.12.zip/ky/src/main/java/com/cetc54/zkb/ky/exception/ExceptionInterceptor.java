package com.cetc54.zkb.ky.exception;

import com.cetc54.zkb.ky.constraint.ErrorResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;

/**
 * 说明:异常拦截器
 * <br>@author lhx
 * <br>@date 2019/1/31 15:22
 * <p>
 * <br>UpdateNote:
 * <br>UpdateTime:
 * <br>UpdateUser:
 */
@ControllerAdvice
public class ExceptionInterceptor {
    /**
     * 拦截通用异常
     * @param e
     * @param response
     * @return
     */
    @ExceptionHandler(value = WebControlException.class)
    @ResponseBody
    public ErrorResponse dealException(WebControlException e, HttpServletResponse response) {

        response.setStatus(200);

        return new ErrorResponse(e.getCode(),e.getMsg());
    }
}
