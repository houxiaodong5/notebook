package com.cetc54.zkb.ky.service.impl;

import com.alibaba.fastjson.JSON;
import com.cetc54.zkb.ky.controller.input.person.QueryByPage;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;
import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutputByPage;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutput;
import com.cetc54.zkb.ky.controller.output.twitter.TwitterOutputByPage;
import com.cetc54.zkb.ky.dao.entity.ObjectDocument;
import com.cetc54.zkb.ky.dao.sql.NewsSql;
import com.cetc54.zkb.ky.service.TwitterService;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

@Service
public class TwitterImpl implements TwitterService {
    private String time = "";
    private static Logger logger= LoggerFactory.getLogger(TwitterImpl.class);
    @Resource
    @Qualifier("secondaryJdbcTemplate")
    private JdbcTemplate secJdbctemplate;
    private List<TwitterOutput> list;

    @Override
    public TwitterOutput queryLatestTwitter(){
        try {
            String sql2 = "SELECT vc_id,vc_nickname,vc_username,vc_retweet_username,vc_retweet_userid,vc_retweet_nickname,vc_photo_url,vc_photo_url_local,vc_tweetid,vc_tweet_url,vc_retweet_title,vc_retweet_content,vc_retweet_web,vc_retweet_url,text_tweet_content,text_picture_url,text_picture_url_local,cast(dt_pubdate as char) dt_pubdate  FROM gather_twitter_tweets  where dt_pubdate > '" + time + "' order by dt_pubdate  limit 1 ";
            String sql = "SELECT vc_id,vc_nickname,vc_username,vc_retweet_username,vc_retweet_userid,vc_retweet_nickname,vc_photo_url,vc_photo_url_local,vc_tweetid,vc_tweet_url,vc_retweet_title,vc_retweet_content,vc_retweet_web,vc_retweet_url,text_tweet_content,text_picture_url,text_picture_url_local,cast(dt_pubdate as char) dt_pubdate  FROM `gather_twitter_tweets` ORDER BY dt_pubdate DESC LIMIT 1 ";

            if (!time.equals("")) {
                sql = sql2;
            }

            List<Map<String, Object>> maps =secJdbctemplate.queryForList(sql);

            if (maps.size() > 0) {
                List<String> img=new ArrayList<>();
                Map<String, Object> map = maps.get(0);
                time = (String) map.get("dt_pubdate");
                String s = JSON.toJSONString(map);
                TwitterOutput output = JSON.toJavaObject(JSON.parseObject(s), TwitterOutput.class);
                String imgs=output.getText_picture_url_local();
                StringTokenizer tokenizer=new StringTokenizer(imgs,",");
                while (tokenizer.hasMoreTokens()){
                    img.add(tokenizer.nextToken());
                }
                if(img.size()==0){
                    img.add(output.getText_picture_url_local());
                }
                output.setImgs(img);
                return output;
            }else {
                return null;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return null;
        }
    }

    @Override
    public TwitterOutputByPage queryTwitterNewsByPage(QueryByPage page) {


        TwitterOutputByPage outputByPage = new TwitterOutputByPage();
        List<TwitterOutput> responseList=new ArrayList<>();
        //String sql="SELECT vc_id,vc_nickname,vc_username,vc_retweet_username,vc_retweet_userid,vc_retweet_nickname,vc_photo_url,vc_photo_url_local,vc_tweetid,vc_tweet_url,vc_retweet_title,vc_retweet_content,vc_retweet_web,vc_retweet_url,text_tweet_content,text_picture_url,text_picture_url_local,cast(dt_pubdate as char) dt_pubdate  FROM gather_twitter_tweets ORDER BY dt_pubdate DESC limit 500 ";
        String sql="SELECT *  FROM gather_twitter_tweets ORDER BY dt_pubdate DESC limit 500 ";
        if (list==null) {
            list = new ArrayList<>();
            List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
            for (Map<String, Object> map : maps) {
                String s = JSON.toJSONString(map);
                TwitterOutput objectEventOutput = JSON.toJavaObject(JSON.parseObject(s), TwitterOutput.class);
                objectEventOutput=TwitterOutput.standardData(objectEventOutput);
                list.add(objectEventOutput);
            }
        }
        int size = list.size();
        int currentPage = page.getPageNum();
        int pageSize = page.getPageSize();
        int totalPage;
        Boolean flag;
        if (size % pageSize == 0) {
            totalPage = size / pageSize;
            flag = false;
        } else {
            totalPage = size / pageSize + 1;
            flag = true;
        }
        //不能完整分页
        int begin=0;
        int end=0;
        if (flag) {
            if (currentPage < totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = currentPage * pageSize - 1;
            }

            if (currentPage == totalPage) {
                begin = (currentPage - 1) * pageSize;
                end = begin + size % pageSize;
            }

        } else {
            begin = (currentPage - 1) * pageSize;
            end = currentPage * pageSize - 1;
        }

        for (int i=0;i<list.size();i++){
            if(i>=begin&&i<=end){
                responseList.add(list.get(i));
            }
        }
        outputByPage.setData(responseList);
        outputByPage.setCurrentPage(currentPage);
        outputByPage.setTotalPage(totalPage);
        outputByPage.setTotalData(list.size());
        return outputByPage;
    }

    @Override
    public List<ObjectDocument> queryFile() {
        List<ObjectDocument> list = new ArrayList<>();
        String sql="SELECT * FROM `tb_document` ORDER BY `vc_publishDate` DESC limit 20";
        List<Map<String, Object>> maps = secJdbctemplate.queryForList(sql);
        for (Map<String, Object> map:maps) {
            String data = JSON.toJSONString(map);
            ObjectDocument document = JSON.toJavaObject(JSON.parseObject(data), ObjectDocument.class);
            list.add(document);
        }
        return list;
    }


}
