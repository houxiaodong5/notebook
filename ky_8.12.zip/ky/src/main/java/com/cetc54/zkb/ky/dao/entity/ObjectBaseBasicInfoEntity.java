package com.cetc54.zkb.ky.dao.entity;

import com.cetc54.zkb.ky.controller.output.base.SimpleUnitMsg;
import com.cetc54.zkb.ky.util.TimeUtil;
import com.mysql.jdbc.Blob;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 *      基地基础信息实体
 * */
public class ObjectBaseBasicInfoEntity implements Serializable {
    private int jdid;//  '基地id'
    private String jdywm;// '基地英文名'
    private String jdrwm;//  '基地日文名'
    private String jdzwm;//  '基地中文名'
    private String jdjj;//  '基地简介'
    private String jdszd;// '基地所在地'
    private String lsy;//  '隶属于'
    private String controlled;//'受控于
    private String openTime;//' 公众开放时间'
    private String cjsj;//'创建时间'
    private String useTime;//' 使用时间'
    private String garrison;//'驻军'
    private String garrisonSymbolUrl;//'驻军军标URL'
    private byte[] garrisonSymbol;//'驻军军标'
    private String coordinates;//'位置坐标'
    private float zxdjd;//'中心点经度'
    private float zxdwd;//'中心点纬度
    private String fType;//'type'
    private String area;//'区域占地'
    private String owner;//'所有权'
    private String fOperator;//'operator'
    private String condition;//'使用状况'
    private String website;//'网站'
    private String identifiers;//'标识符'
    private String ssgldm;//'设施管理代码'
    private String jdhtmldh;//'基地html代号'
    private String zyyt;//'主要用途'
    private float elevation;//'海拔高度'
    private String runways;//'跑道'
    private String rksj;//'入库时间'
    private int gdbUsed;//
    private int bridgeID;//
    private String jdszdyw;//'基地所在地英文'
    private String gj;//'国家'
    private String bdlb;//'部队类别'
    //基地包含联队基础信息
    private List<SimpleUnitMsg> units;

    public int getJdid() {
        return jdid;
    }

    public void setJdid(int jdid) {
        this.jdid = jdid;
    }

    public String getJdywm() {
        return jdywm;
    }

    public void setJdywm(String jdywm) {
        this.jdywm = jdywm;
    }

    public String getJdrwm() {
        return jdrwm;
    }

    public void setJdrwm(String jdrwm) {
        this.jdrwm = jdrwm;
    }

    public String getJdzwm() {
        return jdzwm;
    }

    public void setJdzwm(String jdzwm) {
        this.jdzwm = jdzwm;
    }

    public String getJdjj() {
        return jdjj;
    }

    public void setJdjj(String jdjj) {
        this.jdjj = jdjj;
    }

    public String getJdszd() {
        return jdszd;
    }

    public void setJdszd(String jdszd) {
        this.jdszd = jdszd;
    }

    public String getLsy() {
        return lsy;
    }

    public void setLsy(String lsy) {
        this.lsy = lsy;
    }

    public String getControlled() {
        return controlled;
    }

    public void setControlled(String controlled) {
        this.controlled = controlled;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public String getCjsj() {
        return cjsj;
    }

    public void setCjsj(String cjsj) {
        this.cjsj = TimeUtil.formateStringTime(cjsj);
    }

    public String getUseTime() {
        return useTime;
    }

    public void setUseTime(String useTime) {
        this.useTime = useTime;
    }

    public String getGarrison() {
        return garrison;
    }

    public void setGarrison(String garrison) {
        this.garrison = garrison;
    }

    public String getGarrisonSymbolUrl() {
        return garrisonSymbolUrl;
    }

    public void setGarrisonSymbolUrl(String garrisonSymbolUrl) {
        this.garrisonSymbolUrl = garrisonSymbolUrl;
    }

    public byte[] getGarrisonSymbol() {
        return garrisonSymbol;
    }

    public void setGarrisonSymbol(byte[] garrisonSymbol) {
        this.garrisonSymbol = garrisonSymbol;
    }

    public String getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(String coordinates) {
        this.coordinates = coordinates;
    }

    public float getZxdjd() {
        return zxdjd;
    }

    public void setZxdjd(float zxdjd) {
        this.zxdjd = zxdjd;
    }

    public float getZxdwd() {
        return zxdwd;
    }

    public void setZxdwd(float zxdwd) {
        this.zxdwd = zxdwd;
    }

    public String getfType() {
        return fType;
    }

    public void setfType(String fType) {
        this.fType = fType;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getfOperator() {
        return fOperator;
    }

    public void setfOperator(String fOperator) {
        this.fOperator = fOperator;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getIdentifiers() {
        return identifiers;
    }

    public void setIdentifiers(String identifiers) {
        this.identifiers = identifiers;
    }

    public String getSsgldm() {
        return ssgldm;
    }

    public void setSsgldm(String ssgldm) {
        this.ssgldm = ssgldm;
    }

    public String getJdhtmldh() {
        return jdhtmldh;
    }

    public void setJdhtmldh(String jdhtmldh) {
        this.jdhtmldh = jdhtmldh;
    }

    public String getZyyt() {
        return zyyt;
    }

    public void setZyyt(String zyyt) {
        this.zyyt = zyyt;
    }

    public float getElevation() {
        return elevation;
    }

    public void setElevation(float elevation) {
        this.elevation = elevation;
    }

    public String getRunways() {
        return runways;
    }

    public void setRunways(String runways) {
        this.runways = runways;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }

    public int getGdbUsed() {
        return gdbUsed;
    }

    public void setGdbUsed(int gdbUsed) {
        this.gdbUsed = gdbUsed;
    }

    public int getBridgeID() {
        return bridgeID;
    }

    public void setBridgeID(int bridgeID) {
        this.bridgeID = bridgeID;
    }

    public String getJdszdyw() {
        return jdszdyw;
    }

    public void setJdszdyw(String jdszdyw) {
        this.jdszdyw = jdszdyw;
    }

    public String getGj() {
        return gj;
    }

    public void setGj(String gj) {
        this.gj = gj;
    }

    public String getBdlb() {
        return bdlb;
    }

    public void setBdlb(String bdlb) {
        this.bdlb = bdlb;
    }

    public List<SimpleUnitMsg> getUnits() {
        return units;
    }

    public void setUnits(List<SimpleUnitMsg> units) {
        this.units = units;
    }

    @Override
    public String toString() {
        return "ObjectBaseBasicInfoEntity{" +
                "jdid=" + jdid +
                ", jdywm='" + jdywm + '\'' +
                ", jdrwm='" + jdrwm + '\'' +
                ", jdzwm='" + jdzwm + '\'' +
                ", jdjj='" + jdjj + '\'' +
                ", jdszd='" + jdszd + '\'' +
                ", lsy='" + lsy + '\'' +
                ", controlled='" + controlled + '\'' +
                ", openTime='" + openTime + '\'' +
                ", cjsj='" + cjsj + '\'' +
                ", useTime='" + useTime + '\'' +
                ", garrison='" + garrison + '\'' +
                ", garrisonSymbolUrl='" + garrisonSymbolUrl + '\'' +
                ", garrisonSymbol=" + Arrays.toString(garrisonSymbol) +
                ", coordinates='" + coordinates + '\'' +
                ", zxdjd=" + zxdjd +
                ", zxdwd=" + zxdwd +
                ", fType='" + fType + '\'' +
                ", area='" + area + '\'' +
                ", owner='" + owner + '\'' +
                ", fOperator='" + fOperator + '\'' +
                ", condition='" + condition + '\'' +
                ", website='" + website + '\'' +
                ", identifiers='" + identifiers + '\'' +
                ", ssgldm='" + ssgldm + '\'' +
                ", jdhtmldh='" + jdhtmldh + '\'' +
                ", zyyt='" + zyyt + '\'' +
                ", elevation=" + elevation +
                ", runways='" + runways + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdbUsed=" + gdbUsed +
                ", bridgeID=" + bridgeID +
                ", jdszdyw='" + jdszdyw + '\'' +
                ", gj='" + gj + '\'' +
                ", bdlb='" + bdlb + '\'' +
                ", units=" + units +
                '}';
    }
}
