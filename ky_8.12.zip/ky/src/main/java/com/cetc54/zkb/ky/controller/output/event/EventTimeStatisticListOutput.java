package com.cetc54.zkb.ky.controller.output.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel("事件时间统计输出类")
public class EventTimeStatisticListOutput {
    @ApiModelProperty("威胁等级")
    private String wxdj;
    @ApiModelProperty("事件")
    private List<EventTimeStatisticOutput> datas;


    public String getWxdj() {
        return this.wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }

    public List<EventTimeStatisticOutput> getDatas() {
        return this.datas;
    }

    public void setDatas(List<EventTimeStatisticOutput> datas) {
        this.datas = datas;
    }
}
