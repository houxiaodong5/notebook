package com.cetc54.zkb.ky.controller.output.ship;

import io.swagger.annotations.ApiModelProperty;

public class Trajectory {
    @ApiModelProperty("中心点经度")
    private Float zxdjd;
    @ApiModelProperty("中心点纬度")
    private Float zxdwd;
    @ApiModelProperty("在港状态")
    private Integer zgzt;
    @ApiModelProperty("状态时间")
    private String ztsj;

    public Float getZxdjd() {
        return this.zxdjd;
    }

    public void setZxdjd(Float zxdjd) {
        this.zxdjd = zxdjd;
    }

    public Float getZxdwd() {
        return this.zxdwd;
    }

    public void setZxdwd(Float zxdwd) {
        this.zxdwd = zxdwd;
    }

    public Integer getZgzt() {
        return this.zgzt;
    }

    public void setZgzt(Integer zgzt) {
        this.zgzt = zgzt;
    }

    public String getZtsj() {
        return this.ztsj;
    }

    public void setZtsj(String ztsj) {
        this.ztsj = ztsj;
    }
}
