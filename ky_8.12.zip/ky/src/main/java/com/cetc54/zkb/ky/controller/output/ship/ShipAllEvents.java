package com.cetc54.zkb.ky.controller.output.ship;

import com.cetc54.zkb.ky.controller.output.event.ObjectEventOutput;

import java.io.Serializable;
import java.util.List;

public class ShipAllEvents implements Serializable {

    private int shipID;
    private String shipName;
    private List<ShipEvent> shipEvents;

    public int getShipID() {
        return shipID;
    }

    public void setShipID(int shipID) {
        this.shipID = shipID;
    }

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    public List<ShipEvent> getShipEvents() {
        return shipEvents;
    }

    public void setShipEvents(List<ShipEvent> shipEvents) {
        this.shipEvents = shipEvents;
    }

    @Override
    public String toString() {
        return "ShipAllEvents{" +
                "shipID=" + shipID +
                ", shipName='" + shipName + '\'' +
                ", shipEvents=" + shipEvents +
                '}';
    }
}
