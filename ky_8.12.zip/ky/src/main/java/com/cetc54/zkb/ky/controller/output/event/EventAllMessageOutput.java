package com.cetc54.zkb.ky.controller.output.event;

import com.cetc54.zkb.ky.util.TimeUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.junit.Test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@ApiModel("事件详情(包含人、基地、舰船)")
public class EventAllMessageOutput  implements Comparable{
    @ApiModelProperty("id")
    private Integer id;
    @ApiModelProperty("uuid")
    private String uuid;
    @ApiModelProperty("标题")
    private String bt;
    @ApiModelProperty("简介")
    private String jj;
    @ApiModelProperty("关键词")
    private String gjc;
    @ApiModelProperty("发生时间")
    private String fssj;
    @ApiModelProperty("结束时间")
    private String jssj;
    @ApiModelProperty("坐标纬度")
    private String zbwd;
    @ApiModelProperty("坐标经度")
    private String zbjd;
    @ApiModelProperty("标签1")
    private String tag1;
    @ApiModelProperty("标签2")
    private String tag2;
    @ApiModelProperty("标签3")
    private String tag3;
    @ApiModelProperty("国家名称")
    private String gjmc;
    @ApiModelProperty("国家id")
    private String gjid;
    @ApiModelProperty("地点")
    private String dd;
    @ApiModelProperty("威胁等级")
    private String wxdj;
    @ApiModelProperty("入库时间")
    private String rksj;
    @ApiModelProperty("id")
    private Integer gdbUsed;
    @ApiModelProperty("涉及人员")
    private String personName="";
    @ApiModelProperty("涉及人员id")
    private Integer personID=0;
    @ApiModelProperty("涉及船舶")
    private String shipName="";
    @ApiModelProperty("涉及船舶id")
    private Integer shipID=0;
    @ApiModelProperty("涉及基地")
    private String baseName="";
    @ApiModelProperty("涉及基地id")
    private Integer baseID=0;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getBt() {
        return bt;
    }

    public void setBt(String bt) {
        this.bt = bt;
    }

    public String getJj() {
        return jj;
    }

    public void setJj(String jj) {
        this.jj = jj;
    }

    public String getGjc() {
        return gjc;
    }

    public void setGjc(String gjc) {
        this.gjc = gjc;
    }

    public String getFssj() {
        return fssj;
    }

    public void setFssj(String fssj) {
        this.fssj = TimeUtil.formateStringTime(fssj);
    }

    public String getJssj() {
        return jssj;
    }

    public void setJssj(String jssj) {
        this.jssj = TimeUtil.formateStringTime(jssj);
    }

    public String getZbwd() {
        return zbwd;
    }

    public void setZbwd(String zbwd) {
        this.zbwd = zbwd;
    }

    public String getZbjd() {
        return zbjd;
    }

    public void setZbjd(String zbjd) {
        this.zbjd = zbjd;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getGjmc() {
        return gjmc;
    }

    public void setGjmc(String gjmc) {
        this.gjmc = gjmc;
    }

    public String getGjid() {
        return gjid;
    }

    public void setGjid(String gjid) {
        this.gjid = gjid;
    }

    public String getDd() {
        return dd;
    }

    public void setDd(String dd) {
        this.dd = dd;
    }

    public String getWxdj() {
        return wxdj;
    }

    public void setWxdj(String wxdj) {
        this.wxdj = wxdj;
    }

    public String getRksj() {
        return rksj;
    }

    public void setRksj(String rksj) {
        this.rksj = TimeUtil.formateStringTime(rksj);
    }

    public Integer getGdbUsed() {
        return gdbUsed;
    }

    public void setGdbUsed(Integer gdbUsed) {
        this.gdbUsed = gdbUsed;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName=="null"?null:personName;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }

    public String getShipName() {
        return shipName;
    }

    public void setShipName(String shipName) {

        this.shipName = shipName=="null"?null:shipName;
    }

    public Integer getShipID() {
        return shipID;
    }

    public void setShipID(Integer shipID) {
        this.shipID = shipID;
    }

    public String getBaseName() {
        return baseName;
    }

    public void setBaseName(String baseName) {
        this.baseName = baseName=="null"?null:baseName;
    }

    public Integer getBaseID() {
        return baseID;
    }

    public void setBaseID(Integer baseID) {
        this.baseID = baseID;
    }

    @Override
    public String toString() {
        return "EventAllMessageOutput{" +
                "id=" + id +
                ", uuid='" + uuid + '\'' +
                ", bt='" + bt + '\'' +
                ", jj='" + jj + '\'' +
                ", gjc='" + gjc + '\'' +
                ", fssj='" + fssj + '\'' +
                ", jssj='" + jssj + '\'' +
                ", zbwd='" + zbwd + '\'' +
                ", zbjd='" + zbjd + '\'' +
                ", tag1='" + tag1 + '\'' +
                ", tag2='" + tag2 + '\'' +
                ", tag3='" + tag3 + '\'' +
                ", gjmc='" + gjmc + '\'' +
                ", gjid='" + gjid + '\'' +
                ", dd='" + dd + '\'' +
                ", wxdj='" + wxdj + '\'' +
                ", rksj='" + rksj + '\'' +
                ", gdbUsed=" + gdbUsed +
                ", personName='" + personName + '\'' +
                ", personID=" + personID +
                ", shipName='" + shipName + '\'' +
                ", shipID=" + shipID +
                ", baseName='" + baseName + '\'' +
                ", baseID=" + baseID +
                '}';
    }

    @Override
    public int compareTo(Object o) {
        EventAllMessageOutput o1 = (EventAllMessageOutput) o;
        if(TimeUtil.getTimeFromStringTime(this.getFssj())-TimeUtil.getTimeFromStringTime(o1.getFssj())>0){
            return 1;
        }else if(TimeUtil.getTimeFromStringTime(this.getFssj())-TimeUtil.getTimeFromStringTime(o1.getFssj())==0){
            return 0;
        }
        else return -1;
        //return 0;
    }

    @Test
    public void ss(){
        EventAllMessageOutput output = new EventAllMessageOutput();
        EventAllMessageOutput output1 = new EventAllMessageOutput();
        output.setFssj("2019-06-29 00:00:25");
        output1.setFssj("2019-07-01 00:00:25");
        System.out.println(output1.compareTo(output));
    }
}
