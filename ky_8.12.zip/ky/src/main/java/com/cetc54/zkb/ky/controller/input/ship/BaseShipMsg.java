package com.cetc54.zkb.ky.controller.input.ship;

public class BaseShipMsg {
    private int shipID;

    public int getShipID() {
        return shipID;
    }

    public void setShipID(int shipID) {
        this.shipID = shipID;
    }

    @Override
    public String toString() {
        return "BaseShipMsg{" +
                "shipID=" + shipID +
                '}';
    }
}
