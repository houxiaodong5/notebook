package com.cetc54.zkb.ky.controller.output.event;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("事件统计输出类")
public class EventStatisticOutput {
    @ApiModelProperty("事件总数")
    private Integer eventSum;
    @ApiModelProperty("当天事件总数")
    private Integer eventSumToday;
    @ApiModelProperty("实时推送事件数量")
    private Integer eventRealTime;

    public Integer getEventSum() {
        return this.eventSum;
    }

    public void setEventSum(Integer eventSum) {
        this.eventSum = eventSum;
    }

    public Integer getEventSumToday() {
        return this.eventSumToday;
    }

    public void setEventSumToday(Integer eventSumToday) {
        this.eventSumToday = eventSumToday;
    }

    public Integer getEventRealTime() {
        return this.eventRealTime;
    }

    public void setEventRealTime(Integer eventRealTime) {
        this.eventRealTime = eventRealTime;
    }
}
