package com.cetc54.zkb.ky.controller.input.event;

public class ExtraMessageQueryInput {
    private String uuid;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @Override
    public String toString() {
        return "ExtraMessageQueryInput{" +
                "uuid='" + uuid + '\'' +
                '}';
    }
}
